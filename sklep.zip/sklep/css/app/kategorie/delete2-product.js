
$(document).ready(function(){

	$(document).on('click', '#delete2-kategorie-button', function(){

	var id = $(this).attr('data-id');
	var url_json= "http://"+url+"/index.php/kategorie/UsunKategorie/id/"+id;
	
	$.getJSON(url_json, function(data){
			
	var id_kategoria = $("#kateglowna1a").val();
	var json_url2= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+id_kategoria;
	createProductsTemplatex(json_url2);
					
	})
	});
	
	
	
});
