$(document).ready(function(){

$('#view-plus1').on('show.bs.modal', function (event) {	
	
read_products_html="";
read_products_html+="<form id='plus-kategorie-form' action='#' method='post' border='0'>";

read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td>Nazwa kategorii</td>";
read_products_html+="<td><input type='text' name='nazwa' value='' class='form-control' required></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td></td>";
read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj kategorię";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";

read_products_html+="</form>";
					
$("#tresc1").html(read_products_html);
	
});
	
$(document).on('submit', '#plus-kategorie-form', function(){
var form_data=JSON.stringify($(this).serializeObject());


$.ajax({
    	url: "http://"+url+"/index.php/kategorie/DodajKategorie",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
			$("#view-plus1").modal("hide");

			var json_url= "http://"+url+"/index.php/kategorie/ListaKategorii";
			readProductsTemplate(json_url);
			}
			});
		return false;
});

$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};		
	

});

	
	
 	   


