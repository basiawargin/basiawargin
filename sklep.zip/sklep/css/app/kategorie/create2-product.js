
$(document).ready(function(){
	
$(document).on('click', '#update2-kategorie-button', function(){
	var id_kategoria = $(this).attr('data-id');
	var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+id_kategoria;
	$("#view-update2").modal("show");
	createProductsTemplatex(json_url);
			
});
	
function createProductsTemplatex(json_url){

$.getJSON(json_url, function(data){

$("#tresc3").html("");
				
read_products_html="";
			
$.each(data.dane[0].records, function(key, val){
read_products_html+="<div>Dodaj nową podkategorię dla: <h3>"+val.nazwa+"</h3></div>";				
});
				
read_products_html+="<form id='update2-kategorie-form' action='#' method='post' border='0'>";
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td>Nazwa podkategorii</td>";
read_products_html+="<td colspan='2'><input type='text' name='nazwa' value='' class='form-control' required></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td></td>";
read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj nową podkategorię";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";
$.each(data.dane[0].records, function(key, val){
read_products_html+="<input type='hidden' name='kateglowna' id='kateglowna1a' value='"+val.id+"'>";	
});
read_products_html+="</form>";


read_products_html+="<div><h4>Lista podkategorii</h4></div>";
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<th>ID</th>";
read_products_html+="<th>Nazwa</th>";
read_products_html+="<th>Usuń</th>";
read_products_html+="<th>Zmień</th>";
read_products_html+="<th>Usuń</th>";
read_products_html+="</tr>";
			
$.each(data.dane[0].records, function(key, val){
					var x = val.podkategorie;
					if(typeof x ==="undefined")
					
					{} else
					{
					
					$.each(x.records, function(key2, val2){	
					
					var xc = val2.id;
read_products_html+="<tr>";
read_products_html+="<td>"+ xc+"</td>";
read_products_html+="<td>"+val2.nazwa+"</td>";
read_products_html+="<td><button class='btn btn-outline-warning' id='plus3-kategorie-button' data-id='" + xc + "'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj podkategorię";
read_products_html+="</button></td>";
read_products_html+="<td><button class='btn btn-outline-danger' id='delete2-kategorie-button' data-id='" + xc + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń";
read_products_html+="</button></td>";
read_products_html+="<td><button class='btn btn-outline-primary'  id='update3-kategorie-button' data-id='" + xc + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Edytuj";
read_products_html+="</button></td>";
					
					
read_products_html+="</tr>";
					
					var xx = val2.podkategorie;  
					if(typeof xx ==="undefined")
					
					{} else
					{
$.each(xx.records, function(key3, val3){	
					
var xcc = val3.id;
read_products_html+="<tr>";
read_products_html+="<td >"+ xcc+"</td>";
read_products_html+="<td colspan=2 >"+val3.nazwa+"</td>";
read_products_html+="<td><button class='btn btn-outline-danger'  id='delete2-kategorie-button' data-id='" + xcc + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń";
read_products_html+="</button></td>";
read_products_html+="<td><button class='btn btn-outline-primary'  id='update3-kategorie-button' data-id='" + xcc + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Edytuj";
read_products_html+="</button></td>";
				
read_products_html+="</tr>";
			
});
}
			
});
		
}
		
});
				
read_products_html+="</table></div></form>";
$("#tresc3").html(read_products_html);	
});


}
	


$(document).on('submit', '#update2-kategorie-form', function(){
var form_data=JSON.stringify($(this).serializeObject());
	$.ajax({
			url: "http://"+url+"/index.php/kategorie/DodajPodkategorie",
			type : "POST",
			dataType : 'json',
			data : {"form_data":form_data},
			success : function(data) {				
				
				var id_kategoria = $("#kateglowna1a").val();
				var json_url2= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+id_kategoria;

				createProductsTemplatex(json_url2);
		
						
			}
			});
		return false;
});



	
$(document).on('click', '#update3-kategorie-button', function(){
var id = $(this).attr('data-id');
var kateglowna = $("#kateglowna1a").val();
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+kateglowna;				
updateProductsTemplatex2(json_url, id);
return false;
		
});


function updateProductsTemplatex2(json_url, id){
	
$.getJSON(json_url, function(data){			
$('tresc3').html('');
read_products_html="";
read_products_html+="<form id='update3-kategorie-form' action='#' method='post' border='0'>";
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td>Nowa nazwa dla podkategorii</td>";
read_products_html+="<td colspan='2'>";
			
read_products_html+="<div><h3><input type='hidden' name='id' value='"+id+"' class='form-control' required><input type='text' name='nazwa' value=' ' class='form-control' required></h3></div>";				
				
							
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="<tr><td></td>";
read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> modyfikuj nazwę";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";
				
				
read_products_html+="</form>";


$.each(data.dane[0].records, function(key, val){
read_products_html+="<input type='hidden' name='kateglowna' id='kateglowna1a' value='"+val.id+"' >";	
});
read_products_html+="<div><h4>Lista podkategorii</h4></div>";
read_products_html+="<div><table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<th>ID</th>";
read_products_html+="<th>Nazwa</th>";
read_products_html+="<th>Usuń</th>";
read_products_html+="<th>Zmień</th>";
read_products_html+="<th>Usuń</th>";
read_products_html+="</tr>";
			
				
$.each(data.dane[0].records, function(key, val){
					var x = val.podkategorie;
					
					
$.each(x.records, function(key2, val2){	
					
			var xc = val2.id;
read_products_html+="<tr>";
read_products_html+="<td>"+ xc+"</td>";
read_products_html+="<td>"+val2.nazwa+"</td>";
read_products_html+="<td><button class='btn btn-outline-warning' id='plus3-kategorie-button' data-id='" + xc + "'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj podkategorie";
read_products_html+="</button></td>";
read_products_html+="<td><button class='btn btn-outline-danger' id='delete2-kategorie-button' data-id='" + xc + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń";
read_products_html+="</button></td>";
read_products_html+="<td><button class='btn btn-outline-primary' id='update3-kategorie-button' data-id='" + xc + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Edytuj";
read_products_html+="</button></td>";
					
					
read_products_html+="</tr>";
					
					var xx = val2.podkategorie;
				
					$.each(xx.records, function(key3, val3){	
					
					var xcc = val3.id;
read_products_html+="<tr>";
read_products_html+="<td >"+ xcc+"</td>";
read_products_html+="<td colspan=2 >"+val3.nazwa+"</td>";
read_products_html+="<td><button class='btn btn-outline-danger' id='delete2-kategorie-button' data-id='" + xcc + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń";
read_products_html+="</button></td>";
read_products_html+="<td><button class='btn btn-outline-primary' id=update3-kategorie-button' data-id='" + xcc + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Edytuj";
read_products_html+="</button></td>";
read_products_html+="</tr>";
			
});
});
});
read_products_html+="</table></div></form>";
	
$(".przetwarzaniepopup").html('');
$('#tresc3').html(read_products_html);
	
});				
}	
	

	
$(document).on('submit', '#update3-kategorie-form', function(){
	var form_data=JSON.stringify($(this).serializeObject());
	$.ajax({
			url: "http://"+url+"/index.php/kategorie/ZmienKategorie",
			type : "POST",
			dataType : 'json',
			data : {"form_data":form_data},
			success : function(data) {				
				
				var id_kategoria = $("#kateglowna1a").val();
				var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+id_kategoria;
				
				createProductsTemplatex(json_url);
				
				}
			});
		return false;
});
	
	
	
	

$(document).on('click', '#plus3-kategorie-button', function(){
var id = $(this).attr('data-id');
var kateglowna = $("#kateglowna1a").val();
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+kateglowna;				

updateProductsTemplatex3(json_url, id);
return false;
		
});
	


function updateProductsTemplatex3(json_url, id){
	
$.getJSON(json_url, function(data){			
				$('#tresc3').html('');
				read_products_html="";
				read_products_html+="<form id='plus3-kategorie-form' action='#' method='post' border='0'>";
				read_products_html+="<div>";
				read_products_html+="<table class='table table-bordered'>";
				read_products_html+="<tr>";
				read_products_html+="<th></th>";
				read_products_html+="<th></th>";
				read_products_html+="</tr>";
				read_products_html+="<tr>";
				read_products_html+="<td>Nazwe rozgałęzienie dla podkategorii</td>";
				read_products_html+="<td>";	
				read_products_html+="<input type='text' name='nazwa' value=' ' class='form-control' required>";				
				read_products_html+="</td>";
				read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
				read_products_html+="<span class='glyphicon glyphicon-plus'></span> Dodaj";
				read_products_html+="</button>";
				read_products_html+="<input type='hidden' name='kateglowna' id='kateglowna1' value='"+id+"'>";
				read_products_html+="</td></tr></table></div>";
				read_products_html+="</form>";
				$.each(data.dane[0].records, function(key, val){
				read_products_html+="<input type='hidden' name='kateglowna' id='kateglowna1a' value='"+val.id+"'>";	
				});
				read_products_html+="<div><h4>Lista podkategorii</h4></div>";
				read_products_html+="<div><table class='table table-bordered'>";
				read_products_html+="<tr>";
				read_products_html+="<th>ID</th>";
				read_products_html+="<th>Nazwa</th>";
				read_products_html+="<th>Usuń</th>";
				read_products_html+="<th>Zmień</th>";
				read_products_html+="</tr>";
			
				
				$.each(data.dane[0].records, function(key, val){
					var x = val.podkategorie;
					
					
					$.each(x.records, function(key2, val2){	
					
					var xc = val2.id;
					read_products_html+="<tr>";
					read_products_html+="<td>"+ xc+"</td>";
					read_products_html+="<td>"+val2.nazwa+"</td>";
					read_products_html+="<td><button class='btn btn-outline-warning' id='plus3-kategorie-button' data-id='" + xc + "'>";
					read_products_html+="<span class='glyphicon glyphicon-edit'></span> Dodaj podkategorie";
					read_products_html+="</button></td>";
					read_products_html+="<td><button class='btn btn-outline-danger' id='delete2-kategorie-button' data-id='" + xc + "'>";
					read_products_html+="<span class='glyphicon glyphicon-trash'></span> Usuń";
					read_products_html+="</button></td>";
					read_products_html+="<td><button class='btn btn-outline-primary' id='update3-kategorie-button' data-id='" + xc + "'>";
					read_products_html+="<span class='glyphicon glyphicon-edit'></span> Edytuj";
					read_products_html+="</button></td>";
					
					
					read_products_html+="</tr>";
					
									
					var xx = val2.podkategorie;
				
					$.each(xx.records, function(key3, val3){	
					
					var xcc = val3.id;
					read_products_html+="<tr>";
					
					read_products_html+="<td >"+ xcc+"</td>";
					read_products_html+="<td colspan=2>"+val3.nazwa+"</td>";
					read_products_html+="<td><button class='btn btn-outline-danger' id='delete2-kategorie-button' data-id='" + xcc + "'>";
					read_products_html+="<span class='glyphicon glyphicon-trash'></span> Usuń";
					read_products_html+="</button></td>";
					read_products_html+="<td><button class='btn btn-outline-primary' id='update3-kategorie-button' data-id='" + xcc + "'>";
					read_products_html+="<span class='glyphicon glyphicon-edit'></span> Edytuj";
					read_products_html+="</button></td>";
						
					read_products_html+="</tr>";

			
					});
					
			
					});
		
		
		
				});
				read_products_html+="</table></div></for>";
	
				$(".przetwarzaniepopup").html('');
				$('#tresc3').html(read_products_html);
});	
				
			}	
	


$(document).on('submit', '#plus3-kategorie-form', function(){
	var form_data=JSON.stringify($(this).serializeObject());
	$.ajax({
			url: "http://"+url+"/index.php/kategorie/DodajPodkategorie",
			type : "POST",
			dataType : 'json',
			data : {"form_data":form_data},
			success : function(data) {				
				
				var id_kategoria = $("#kateglowna1a").val();
				var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+id_kategoria;
								
				
					createProductsTemplatex(json_url);
				
						
				}
			});
		return false;
	});	
	
	$(document).on('click', '#delete2-kategorie-button', function(){

	var id = $(this).attr('data-id');
	var url_json= "http://"+url+"/index.php/kategorie/UsunKategorie/id/"+id;
	
	$.getJSON(url_json, function(data){
			
	var id_kategoria = $("#kateglowna1a").val();
	var json_url2= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+id_kategoria;
	createProductsTemplatex(json_url2);
		

		
	})
	});

$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	
	
	
	
	
	
	
});



