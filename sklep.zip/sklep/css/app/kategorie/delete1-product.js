
$(document).ready(function(){

	$(document).on('click', '#delete-kategorie-button', function(){

	var id = $(this).attr('data-id');
	var url_json= "http://"+url+"/index.php/kategorie/UsunKategorie/id/"+id;
	$.getJSON(url_json, function(data){
				var json_url2= "http://"+url+"/index.php/kategorie/ListaKategorii";
				readProductsTemplate(json_url2);
			
					
		})
	
		
	});
});