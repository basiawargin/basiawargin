
$(document).ready(function(){

	var json_url= "http://"+url+"/index.php/kategorie/ListaKategorii";
	
	read_products_html="<nav class='navbar navbar-expand-lg navbar-light bg-light'>";

	read_products_html+="<button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarSupportedContent2' aria-controls='navbarSupportedContent2' aria-expanded='false' aria-label='Toggle navigation'>";
	read_products_html+="<span class='navbar-toggler-icon'></span>";
	read_products_html+="</button>";

	read_products_html+="<div class='collapse navbar-collapse' id='navbarSupportedContent2'>";
    	read_products_html+="<ul class='navbar navbar-nav mr-auto'>";
	read_products_html+="<li class='nav-item'>";
	read_products_html+="<div class='btn btn-outline-warning' id='plus-kategorie-button' data-toggle='modal' data-target='#view-plus1'>";
	read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Doda nową kategorię";
	read_products_html+="</div>";
	read_products_html+="</li>";
	read_products_html+="</ul>";
	read_products_html+="</div>";
	read_products_html+="</nav>";


	$(".czolowka").html(read_products_html);

	readProductsTemplate(json_url);	
});


	

	
	
	
function readProductsTemplate(json_url){
			

				
$.getJSON(json_url, function(data){
$(".lista").html('');				
				
read_products_html="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tbody>";
				
$.each(data.dane[0].records, function(key, val) {
				
		
read_products_html+="<tr>";
read_products_html+="<td>"+val.id+"</td>";
read_products_html+="<td>"+val.nazwa+"</td>";
				
read_products_html+="<td><button class='btn btn-outline-info' id='update1-kategorie-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Edytuj dane";
read_products_html+="</button></td>";
				
read_products_html+="<td><button class='btn btn-outline-success'  id='update2-kategorie-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Podkategorie";
read_products_html+="</button></td>";
											
read_products_html+="<td><button class='btn btn-outline-danger'  id='delete-kategorie-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń kategorię";
read_products_html+="</button></td>";
				
read_products_html+="</tr>";
});	
read_products_html+="</tbody>";
read_products_html+="</table>";
read_products_html+="</div>";
										
				
$(".lista").html(read_products_html);

				
});				
				
}
			
	
			