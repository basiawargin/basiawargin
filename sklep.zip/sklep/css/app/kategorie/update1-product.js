
$(document).ready(function(){
	
	$(document).on('click', '#update1-kategorie-button', function(){
		var id = $(this).attr('data-id');
		$("#view-update1").modal("show");
		var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+id;
		update1(json_url);
	});
	
	$(document).on('submit', '#update1-kategorie-form', function(){
	var form_data=JSON.stringify($(this).serializeObject());

	$.ajax({
    	url: "http://"+url+"/index.php/kategorie/ZmienKategorie",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
				$("#view-update1").modal("hide");

				var json_url= "http://"+url+"/index.php/kategorie/ListaKategorii";
				readProductsTemplate(json_url);
				}
			});
		return false;
	});
	
});	
		
function update1(json_url){

$.getJSON(json_url, function(data){
$("#tresc2").html('');		
		
read_products_html="";
read_products_html+="<form id='update1-kategorie-form' action='#' method='post' border='0'>";
$.each(data.dane[0].records, function(key, val){
read_products_html+="<div>Zniana dla: <h3>"+val.nazwa+"</h3><input type='hidden' name='id' value='"+val.id+"' class='form-control' required></div>";				
});
				
								
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered table-hover'>";
read_products_html+="<tr>";
read_products_html+="<td>Nowa nazwa kategorii</td>";
read_products_html+="<td colspan='2'><input type='text' name='nazwa' value='' class='form-control' required></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td></td>";
read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Modyfikuj ";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";
					
read_products_html+="</form>";
$("#tresc2").html(read_products_html);
});	
				
}	
	

	
		


$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	
	
	
	


