var url = 'kontakt1.vot.pl';
