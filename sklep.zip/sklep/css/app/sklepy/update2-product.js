
$(document).ready(function(){
	
$(document).on('click', '#update2-sklepy-button', function(){
var id = $(this).attr('data-id');
var json_url= "http://"+url+"/index.php/sklepy/ListaNiepracujace/id/"+id;
$("#view-update2").modal("show");
update2(json_url, id);
		
});
	
function update2(json_url, id){

$.getJSON(json_url, function(data){			
$('#tresc4').html('');

read_products_html="";
read_products_html+="<form  action='#' method='post' border='0'>";
				
read_products_html+="<div class='p-3'><div class='btn btn-outline-primary pull-right' id='create2-sklepy-button'>";
read_products_html+="<span class='glyphicon glyphicon-plus'></span> Dodaj dzień niepracujący";
read_products_html+="</div></div>";
read_products_html+="<input type='hidden' name='idsklep' id='idsklep' value='"+id+"'>";
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";

$.each(data.dane[0].records, function(key, val){						
read_products_html+="<tr>";
read_products_html+="<td><span class='text-primary'>"+val.dzien2+"</span></td>";
read_products_html+="<td><button class='btn btn-outline-danger' id='delete2-sklepy-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span>  Usuń";
read_products_html+="</button></td>";	
read_products_html+="</tr>";	
});		
read_products_html+="</table>";
read_products_html+="</div>";
read_products_html+="<div id='pretwaraniepopup'></div>";

read_products_html+="</form>";
$('#tresc4').html(read_products_html);
$(".przetwarzaniepopup").html('');
});				
			
}	


	
$(document).on('click', '#delete2-sklepy-button', function(){
var id = $(this).attr('data-id');
var json_url= "http://"+url+"/index.php/sklepy/UsunNiepracujacy/id/"+id;
$(".przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');	
$.getJSON(json_url, function(data){
		
var wartosc= document.getElementById('idsklep');
var idsklep = wartosc.value;	
var json_url2= "http://"+url+"/index.php/sklepy/ListaNiepracujace/id/"+idsklep;

update2(json_url2, idsklep);
});
return false;
});

$(document).on('click', '#create2-sklepy-button', function(){
		
var wartosc= document.getElementById('idsklep');

var idsklep = wartosc.value;

var url_json= "http://"+url+"/index.php/sklepy/ListaNiepracujace/id/"+idsklep;

$.getJSON(url_json, function(data){
		
$('#tresc4').html('');
read_products_html="";

				
read_products_html+="<form id='update4-sklepy-form' action='#' method='post' border='0'>";
read_products_html+="<input type='hidden' name='idsklep' id='idsklep' value='"+idsklep+"'>";

read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr><td>";
read_products_html+="<input type='date' name='dzien' id='dzien'></td>";
read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='glyphicon glyphicon-plus'></span> Dodaj  ";
read_products_html+="</button></td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";

read_products_html+="</form>";
read_products_html+="<form  action='#' method='post' border='0'>";
read_products_html+="<div class='p-3'><div class='btn btn-outline-primary pull-right' id='create2-sklepy-button'>";
read_products_html+="<span class='glyphicon glyphicon-plus'></span> Dodaj dzień niepracujący";
read_products_html+="</div></div>";

read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";

$.each(data.dane[0].records, function(key, val){						
read_products_html+="<tr>";
read_products_html+="<td><span class='text-primary'>"+val.dzien2+"</span></td>";
read_products_html+="<td><button class='btn btn-outline-danger delete2-sklepy-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń";
read_products_html+="</button></td>";	
read_products_html+="</tr>";	
});		
read_products_html+="</table>";
read_products_html+="</div>";

read_products_html+="<div class='przetwarzaniepopup'></div>";
read_products_html+="</form>";



$('#tresc4').html(read_products_html);
});	
		

		
});

	

	
$(document).on('submit', '#update4-sklepy-form', function(){

var form_data=JSON.stringify($(this).serializeObject());

$(".przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');
$.ajax({
    	url: "http://"+url+"/index.php/sklepy/DodajNiepracujacy",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
							
				var wartosc= document.getElementById('idsklep');
				var id = wartosc.value;	
				var json_url= "http://"+url+"/index.php/sklepy/ListaNiepracujace/id/"+id;
				update2(json_url, id);
				
	}
});
return false;
	
});
		



$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	
	
	
	









	

		
		
});

	

