
$(document).ready(function(){

	var json_url1= "http://"+url+"/index.php/sklepy/PobierzUzytkownikowDoSelect";
	var json_url2= "http://"+url+"/index.php/markety/ListaMarketowDoSelect";
	var json_url3= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser//idmarket//";
	

	read_products_html="<nav class='navbar navbar-expand-lg navbar-light bg-light'>";

	read_products_html+="<button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarSupportedContent2' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>";
	read_products_html+="<span class='navbar-toggler-icon'></span>";
	read_products_html+="</button>";

	read_products_html+="<div class='collapse navbar-collapse' id='navbarSupportedContent2'>";
    read_products_html+="<ul class='navbar navbar-nav mr-auto'>";
	read_products_html+="<li class='nav-item'>";
	read_products_html+="<div class='btn btn-outline-warning' id='plus1-sklepy-button' data-toggle='modal' data-target='#view-plus1'>";
	read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj nowy sklep";
	read_products_html+="</div>";
	read_products_html+="</li>";

	read_products_html+="<li class='nav-item'>";
	read_products_html+="<div class='btn btn-outline-success' id='plus2-sklepy-button' data-toggle='modal' data-target='#view-plus2'>";
	read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Dodaj nowy market";
	read_products_html+="</div>";
	read_products_html+="</li>";

	read_products_html+="<li class='nav-item'>";
	read_products_html+="<div class='btn selectmarket'>";
	read_products_html+="</div>";
	read_products_html+="</li>";
	
	read_products_html+="</ul>";
	read_products_html+="</div>";
	read_products_html+="</nav>";
	
	read_products_html+="<form id='zmienne-sklepy-form' action='#' method='post'>";
	read_products_html+="<input type='hidden' name='iduser2' id='iduser2' value=''>";
	read_products_html+="<input type='hidden' name='idmarket2' id='idmarket2' value=''>";
	read_products_html+="</form>";

	read_products_html+="<div id='przetwarzanie'></div>";
	$(".czolowka").html(read_products_html);

	show1(json_url1);
	show2(json_url2);
	readProductsTemplate(json_url3);	
	
$(document).on('click', '#pagination1 li', function(){		
var json_url=$(this).find('a').attr('data-page');

readProductsTemplate(json_url);
	
});
	

		
		
$(document).on('change', '#iduser', function(){
		
var iduser = $("#iduser").val();
document.forms["zmienne-sklepy-form"]["iduser2"].value = iduser;
var idmarket = document.forms["zmienne-sklepy-form"]["idmarket2"].value;
if(iduser ==='y')
{
if(idmarket ==='y')
{  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/y/idmarket/y/"; } 
else {  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/y/idmarket/"+idmarket+"/";}
} else {
if(idmarket ==='y')
{  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/"+iduser+"/idmarket//";	 } 
else {  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/"+iduser+"/idmarket/"+idmarket+"/";}
}

readProductsTemplate(json_url);

});

	

$(document).on('change', '#idmarket', function(){
		
var idmarket = $("#idmarket").val();
document.forms["zmienne-sklepy-form"]["idmarket2"].value = idmarket;
var iduser = document.forms["zmienne-sklepy-form"]["iduser2"].value;
if(iduser ==='y')
{
if(idmarket ==='y')
{  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/y/idmarket/y/";} 
else {  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/y/idmarket/"+idmarket+"/"; }
} else {
if(idmarket ==='y')
{  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/"+iduser+"/idmarket//";} 
else {  var json_url= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/1/iduser/"+iduser+"/idmarket/"+idmarket+"/"; }
}

readProductsTemplate(json_url);

				
});
	
});


	
function show1(json_url1){
$.getJSON(json_url1, function(data){
						
$(".selectuser").html('');
read_products_html1="<select name='iduser' id='iduser' class='form-control'>";	
read_products_html1+= "<option value=''>bez filtra</option>";
$.each(data.dane[0].records, function(keyx, valx) {
read_products_html1+= "<option value='"+valx.id+"'>"+valx.username+"</option>";
});
read_products_html1+="</select>";
$(".selectuser").html(read_products_html1);
});
}

	
function show2(json_url2){
$.getJSON(json_url2, function(data){
$(".selectmarket").html('');
read_products_html1="<select name='idmarket' id='idmarket' class='form-control'>";	
read_products_html1+= "<option value=''>bez filtra</option>";
$.each(data.dane[0].records, function(keyx, valx) {
read_products_html1+= "<option value='"+valx.id+"'>"+valx.nazwa+"</option>";
});
read_products_html1+="</select>";
$(".selectmarket").html(read_products_html1);
});
		 
}


	
	
	
	
function readProductsTemplate(json_url){

$(".paginationblok").html('');
$(".lista").html('');
$("#przetwarzanie").html('<div id="loading"></div>');


$.getJSON(json_url, function(data){
			
if(data.dane[1].paging.liczba_rekordow !== null)
{var li = data.dane[1].paging.liczba_rekordow;} else { var li = 0 ;}

read_products_html2="<div class='col-lg-12'>";

read_products_html2+="<form id='lista-produkty-form' action='#' method='post' border='0'>";

if(data.dane[1].paging.first!=="x"){ 
read_products_html2+="<div class='pt-1'><span class='text-success'>Liczba wyników: "+li+"</span></div><hr />";
read_products_html2+="<input type='hidden' name='page' id='page' value='"+data.dane[1].paging.page+"'>";
}
if(data.dane[1].paging.first!=="x"){
read_products_html2+="<ul id='pagination1' class='pagination'>";
if(data.dane[1].paging.first!==""){
read_products_html2+="<li><a data-page='" + data.dane[1].paging.first + "'> << </a></li>";
}
$.each(data.dane[1].paging.pages, function(key, val){
var active_page=val.current_page=="yes" ? "class='active'" : "";
read_products_html2+="<li " + active_page + "><a data-page='" + val.url + "'>" + val.page + "</a></li>";
});
if(data.dane[1].paging.last!==""){
read_products_html2+="<li><a data-page='" + data.dane[1].paging.last + "'> >> </a></li>";
}
read_products_html2+="</ul>";
} 
read_products_html2+="</div>";
				
				
				
read_products_html="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tbody>";
$.each(data.dane[0].records, function(key, val) {

read_products_html+="<tr>";
read_products_html+="<td>"+val.id+"</td>";
read_products_html+="<td>"+val.nazwa+" - "+val.miasto+"</td>";
read_products_html+="<td>"+val.market+"</td>";
			
read_products_html+="<td><button class='btn btn-outline-info' id='update1-sklepy-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Edytuj dane";
read_products_html+="</button></td>";
				
read_products_html+="<td><button class='btn btn-outline-primary' id='update2-sklepy-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Dni niepracujące ";
read_products_html+="</button></td>";
									
read_products_html+="<td><button class='btn btn-outline-danger' id='delete-sklepy-button' data-id='" + val.id + "'>";
read_products_html+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń sklep";
read_products_html+="</button></td>";
				
read_products_html+="</tr>";
});	
read_products_html+="</tbody>";
read_products_html+="</table>";
read_products_html+="</div>";
read_products_html+="</form>";
read_products_html+="</div>";	

			
$("#przetwarzanie").html('');				
$(".paginationblok").html(read_products_html2);
$(".lista").html(read_products_html);

setTimeout(removeLoader, 1000);	

});


}
			
function removeLoader(){
$( "#loading" ).fadeOut(100, function() {
$( "#loading" ).remove(); 
});  
}			
			