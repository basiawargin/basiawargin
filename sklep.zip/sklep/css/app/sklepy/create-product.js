$(document).ready(function(){

$('#view-plus1').on('show.bs.modal', function (event) {	

var jednostka = new Array();

jednostka[0] = '00:00';
jednostka[1800] = '00:30';
jednostka[3600] = '01:00';
jednostka[5400] = '01:30';
jednostka[7200] = '02:00';
jednostka[9000]='02:30';
jednostka[10800]='03:00';
jednostka[12600]='03:30';
jednostka[14400]='04:00';
jednostka[16200]='04:30';
jednostka[18000]='05:00';
jednostka[19800]='05:30';
jednostka[21600]='06:00';
jednostka[23400]='06:30';
jednostka[25200]='07:00';
jednostka[27000]='07:30';
jednostka[28800]='08:00';
jednostka[30600]='08:30';
jednostka[32400]='09:00';
jednostka[34200]='09:30';
jednostka[36000]='10:00';
jednostka[37800]='10:30';
jednostka[39600]='11:00';
jednostka[41400]='11:30';
jednostka[43200]='12:00';
jednostka[45000]='12:30';
jednostka[46800]='13:00';
jednostka[48600]='13:30';
jednostka[50400]='14:00';
jednostka[52200]='14:30';
jednostka[54000]='15:00';
jednostka[55800]='15:30';
jednostka[57600]='16:00';
jednostka[59400]='16:30';
jednostka[61200]='17:00';
jednostka[63000]='17:30';
jednostka[64800]='18:00';
jednostka[66600]='18:30';
jednostka[68400]='19:00';
jednostka[70200]='19:30';
jednostka[72000]='20:00';
jednostka[73800]='20:30';
jednostka[75600]='21:00';
jednostka[77400]='21:30';
jednostka[79200]='22:00';
jednostka[81000]='22:30';
jednostka[82800]='23:00';
jednostka[84600]='23:30';
jednostka[86400]='24:00';

var json_url= "http://"+url+"/index.php/markety/ListaMarketowDoSelect";


$.getJSON(json_url, function(data){
	
$("#tresc1").html('');

read_products_html="";
read_products_html+="<form id='plus1-sklepy-form' action='#' method='post' border='0'>";

read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";

read_products_html+="<tr>";
read_products_html+="<td>Nazwa marketu</td>";
read_products_html+="<td><select name='idmarket' id='idmarket' class='form-control'>";	
read_products_html+= "<option value=''> market</option>";
$.each(data.dane[0].records, function(keyx, valx) {
read_products_html+= "<option value='"+valx.id+"'>"+valx.nazwa+"</option>";
});
read_products_html+="</select></td>";
read_products_html+="</tr>";


read_products_html+="<tr>";
read_products_html+="<td>Nazwa punktu</td>";
read_products_html+="<td><input type='text' name='nazwa' value='' class='form-control' required></td>";
read_products_html+="</tr>";
							
read_products_html+="<tr>";
read_products_html+="<td>Ulica</td>";
read_products_html+="<td><input type='text' name='ulica'  value='' class='form-control' required></td>";
read_products_html+="</tr>";
							
read_products_html+="<tr>";
read_products_html+="<td>Numer</td>";
read_products_html+="<td><input type='text' name='numer'  value='' class='form-control' required></td>";
read_products_html+="</tr>";
							
read_products_html+="<tr>";
read_products_html+="<td>Miasto</td>";
read_products_html+="<td><input type='text' name='miasto' value='' class='form-control' required></td>";
read_products_html+="</tr>";
							
read_products_html+="<tr>";
read_products_html+="<td>Kod</td>";
read_products_html+="<td><input type='text' name='kod' value='' class='form-control' required></td>";
read_products_html+="</tr>";			
		
read_products_html+="<tr>";
read_products_html+="<td>Kraj</td><td><select name='kraj' class='form-control'>";
						
						var kraj = new Array();
						kraj['Polska']= "Polska";
						
						var kraj;
						krajx = "";
						
						krajx += '<option value="Polska">Polska</option>';
						
read_products_html+= krajx;
read_products_html+= "</select></td></tr>";
						
				
read_products_html+="<tr>";
read_products_html+="<td>Aktualność</td><td><select name='is_actual' class='form-control'>";
						
						var actual = new Array();
						actual[0]= "TAK";
						actual[1]= "NIE";
						
						var text1;
						text1 = "";
						for (i = 0; i < actual.length; i++) {
						text1 += '<option value="' +actual[i]+ '">' + actual[i] + '</option>';
						} 
read_products_html+= text1;
read_products_html+="</select>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";						
			

read_products_html+="<div>";			
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<th colspan='3'>Godziny pracy </th>";
read_products_html+="</tr>";
						
read_products_html+="<tr>";
read_products_html+="<td>Poniedziałek - Piątek (od-do)</td>";
read_products_html+="<td><select name='godziny1' class='form-control'>";
						
						var text2;
						text2 = "";
						text2 += '<option value="1">Nie pracuję/ nie wybieram</option>';
						for (i = 0; i < jednostka.length; ) {
						text2 += '<option value="'+i+'">' + jednostka[i] + '</option>';
						i = i + 1800;
						} 
read_products_html+= text2;
						
read_products_html+="</select></td>";
read_products_html+="<td><select name='godziny2' class='form-control'>";
						
						var text3;
						text3 = "";
						text3 += '<option value="1">Nie pracuję/ nie wybieram</option>';
						for (i = 0; i < jednostka.length; ) {
						text3 += '<option value="'+i+'">' + jednostka[i] + '</option>';
						i = i + 1800;
						} 
read_products_html+= text3;
						
read_products_html+="</select></td>";
read_products_html+="</tr>";
							
						
read_products_html+="<tr>";
read_products_html+="<td>Sobota (od-do)</td>";
read_products_html+="<td><select name='godziny3' class='form-control'>";
						
						var text4;
						text4 = "";
						text4 += '<option value="1">Nie pracuję/ nie wybieram</option>';
						for (i = 0; i < jednostka.length; ) {
						text4 += '<option value="'+i+'">' + jednostka[i] + '</option>';
						i = i + 1800;
						} 
read_products_html+= text2;
						
read_products_html+="</select></td>";
						
read_products_html+="<td><select name='godziny4' class='form-control'>";
						
						var text5;
						text5 = "";
						text5 += '<option value="1">Nie pracuję/ nie wybieram</option>';
						for (i = 0; i < jednostka.length; ) {
						text5 += '<option value="'+i+'">' + jednostka[i] + '</option>';
						i = i + 1800;
						} 
read_products_html+= text5;
						
read_products_html+="</select></td>";
read_products_html+="</tr>";
				
						
read_products_html+="<tr>";
read_products_html+="<td>Niedziela (od-do)</td>";
read_products_html+="<td><select name='godziny5' class='form-control'>";
						
						var text6;
						text6 = "";
						text6 += '<option value="1">Nie pracuję/ nie wybieram</option>';
						for (i = 0; i < jednostka.length; ) {
						text6 += '<option value="'+i+'">' + jednostka[i] + '</option>';
						i = i + 1800;
						} 
read_products_html+= text6;
						
read_products_html+="</select></td>";
			
read_products_html+="<td><select name='godziny6' class='form-control'>";
						
						var text7;
						text7 = "";
						text7 += '<option value="1">Nie pracuję/ nie wybieram</option>';
						for (i = 0; i < jednostka.length; ) {
						text7 += '<option value="'+i+'">' + jednostka[i] + '</option>';
						i = i + 1800;
						} 
read_products_html+= text7;
						
read_products_html+="</select></td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";							
						
			
read_products_html+="<div>";									
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td></td>";
read_products_html+="<td colspan='2'>";
read_products_html+="<button type='submit'  class='btn btn-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span>  Dodaj sklep ";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";	

read_products_html+="<div id='komunikat'></div>";
read_products_html+="<div id='przetwarzaniepopup'></div>";
read_products_html+="</form>";
					
$("#tresc1").html(read_products_html);						
});
	
});



$(document).on('submit', '#plus1-sklepy-form', function(){
var form_data=JSON.stringify($(this).serializeObject()); 
$("#przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');

$.ajax({
    	url: "http://"+url+"/index.php/sklepy/DodajSklep",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
				if(data.dane[0].komunikat == 'OK'){
					
				$("#view-plus1").modal("hide");				
				var wartosc= document.getElementById('page');
				var page = wartosc.value;	
				var json_url2= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/"+page;
				readProductsTemplate(json_url2);
			
				}else {
					$("#komunikat").html('<p> Niepoprawne wpisane dane czasu pracy sklepu.</p>');

				}
							
				
				}
			});
		return false;
});
	
	
	
$('#view-plus2').on('shown.bs.modal', function (e) {
 	
$("#tresc2").html('');										
read_products_html="";
read_products_html+="<form id='plus2-sklepy-form' action='#' method='post' border='0'>";

read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td>Nazwa punktu</td>";
read_products_html+="<td><input type='text' name='nazwa' value='' class='form-control' required></td>";
read_products_html+="</tr>";
															
read_products_html+="<tr>";
read_products_html+="<td colspan='2'>";
read_products_html+="<button type='submit'  class='btn btn-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj market ";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";

read_products_html+="<div id='komunikat'></div>";
read_products_html+="<div id='przetwarzaniepopup'></div>";

read_products_html+="</form>";
					
$("#tresc2").html(read_products_html);
							
});

	
		
$(document).on('submit', '#plus2-sklepy-form', function(){

var form_data=JSON.stringify($(this).serializeObject()); 

$(".przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');

$.ajax({
    	url: "http://"+url+"/index.php/markety/DodajMarket",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
			$("#view-plus2").modal("hide");									
				
	}
	});
	return false;	
});
	




$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	
	
	
 	
});
	   


