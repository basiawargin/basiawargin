
$(document).ready(function(){

$(document).on('click', '#delete-sklepy-button', function(){

var id = $(this).attr('data-id');
var url_json= "http://"+url+"/index.php/sklepy/UsunSklep/id/"+id;
$.getJSON(url_json, function(data){
								
var wartosc= document.getElementById('page');
var page = wartosc.value;	
var json_url2= "http://"+url+"/index.php/sklepy/PobierzSklepy/page/"+page;
readProductsTemplate(json_url2);
				
});
	
});

});