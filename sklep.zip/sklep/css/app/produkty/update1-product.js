
$(document).ready(function(){

$(document).on('click', '#update1-produkty-button', function(){

$('#view-update1').modal('show');
var id = $(this).attr('data-id'); 

var json_url= "http://"+url+"/index.php/produkty/PobierzProdukt/id/"+id;
update1(json_url);
})
					
$(document).on('change', '#kategoria', function(){

var idkategoria = $("#kategoria").val();
if(idkategoria ==='y')
{} else {
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+idkategoria;
}
$.getJSON(json_url, function(data){
$('#podkategoria1').html('');
$('#podkategoria2').html('');
var read="";
$.each(data.dane[0].records, function(key2, val2){
	$.each(val2.podkategorie.records, function(key2, val2){
		read+="<option value='" + val2.id+ "'>" + val2.nazwa+ "</option>";
		});
});
$('#podkategoria1').html(read);		
});
});

$(document).on('change', '#podkategoria1', function(){
var idpodkategoria1 = $("#podkategoria1").val();
if(idpodkategoria1 ==='y')
{} else {
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+idpodkategoria1;
}
$.getJSON(json_url, function(data){
$('#podkategoria2').html('');
var read="";
$.each(data.dane[0].records, function(key2, val2){
	$.each(val2.podkategorie.records, function(key3, val3){
	read+="<option value='" + val3.id+ "'>" + val3.nazwa+ "</option>";
	});
});
$('#podkategoria2').html(read);
});
});


$(document).on('submit', '#update1-produkty-form', function(){
var form_data=JSON.stringify($(this).serializeObject());
$("#przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');

$.ajax({
    	url: "http://"+url+"/index.php/produkty/ZmienProdukt",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				$("#przetwarzaniepopup").html('');
				$("#view-update1").modal('hide');
				var wartosc= document.getElementById('page');
				var page = wartosc.value;	
				var idmarket = $("#idmarket2").val();
				var idkategoria = $("#idkategoria2").val();
				var idpodkategoria1 = $("#idpodkategoria1n2").val();
				var idpodkategoria2 = $("#idpodkategoria2n2").val();

				var json_url= "http://"+url+"/index.php/produkty/ListaProduktow/page/"+page+"/idmarket/"+idmarket+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria1+"/idpodkategoria2/"+idpodkategoria2;
				readProductsTemplate(json_url);
				}
	});
	return false;
});
	
	
$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	
		
});

	
function update1(json_url){
			
$("#tresc3").html('');


$.getJSON(json_url, function(data){

read_products_html="<form id='update1-produkty-form' action='#' method='post' border='0'>";
				
$.each(data.dane[0].records, function(key, val) {
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td>Market</td>";
read_products_html+="<td><select name='idmarket' name='idmarket' class='form-control'>";
						
$.each(data.dane[4].records, function(key1, val1){
read_products_html+="<option value='" + val1.id+ "' ";
if( val.idmarket === val1.id) {  read_products_html+= " selected='selected'"; }
read_products_html+=">" + val1.nazwa +"</option>";
});
						
read_products_html+="</select></td>";
read_products_html+="</tr>";
										
read_products_html+="<tr>";
read_products_html+="<td>Nazwa <input type='hidden' name='id' id='"+val.id+"' value='"+val.id+"' class='form-control' required></td>";
read_products_html+="<td><input type='text' name='nazwa' value='"+val.nazwa+"' class='form-control' required></td>";
read_products_html+="</tr>";
							
read_products_html+="<tr>";
read_products_html+="<td>Producent</td>";
read_products_html+="<td><input type='text' name='producent' ";
if(typeof val.producent === "String")
{
read_products_html+="	value='"+val.producent+"' ";
}
read_products_html+=" class='form-control'></td>";
read_products_html+="</tr>";
							
read_products_html+="<tr>";
read_products_html+="<td>Opis</td>";
read_products_html+="<td><input type='text' name='opis' ";
read_products_html+=" value='"+val.opis+"' ";
read_products_html+=" class='form-control'></td>";
read_products_html+="</tr>";
						
						
read_products_html+="<tr>";
read_products_html+="<td>Kategoria</td>";
read_products_html+="<td><select name='kategoria' id='kategoria' class='form-control'>";
						
$.each(data.dane[1].records, function(key1, val1){
read_products_html+="<option value='" + val1.id+ "' ";
if( val.kategoria === val1.id) {  read_products_html+= " selected='selected'"; }
read_products_html+=">" + val1.nazwa +"</option>";
});
						
read_products_html+="</select></td>";
read_products_html+="</tr>";
						
read_products_html+="<tr>";
read_products_html+="<td>Podkategoria 1</td>";
read_products_html+="<td><select name='podkategoria1' id='podkategoria1' class='form-control'>";
						
$.each(data.dane[2].records, function(key1, val1){
read_products_html+="<option value='" + val1.id+ "' ";
if( val.podkategoria1 === val1.id) {  read_products_html+= " selected='selected'"; }
read_products_html+=">" + val1.nazwa +"</option>";
						
});
						
read_products_html+="</select></td>";
read_products_html+="</tr>";
						
read_products_html+="<tr>";
read_products_html+="<td>Podkategoria 2</td>";
read_products_html+="<td><select name='podkategoria2' id='podkategoria2' class='form-control'>";
$.each(data.dane[3].records, function(key1, val1){
if(typeof val1 ==="Number")
{
read_products_html+="<option value='" + val1.id+ "' ";
if( val.podkategoria2 === val1.id) {  read_products_html+= " selected='selected'"; }
read_products_html+=">" + val1.nazwa +"</option>";
} else {}
						
});
read_products_html+="</select></td>";
read_products_html+="</tr>";
						
read_products_html+="</table>";
read_products_html+="</div>";

read_products_html+="<div>";						
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td></td>";
read_products_html+="<td colspan='2'>";
read_products_html+="<button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span>  Zmień dane";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr></table>";
read_products_html+="</div>";

read_products_html+="<div id='komunikat'></div>";
read_products_html+="<div id='przetwarzaniepopup'></div>";

						
});
read_products_html+="</form>";



$("#tresc3").html(read_products_html);
					
});			
	
				
}


