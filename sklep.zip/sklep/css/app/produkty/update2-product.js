
$(document).ready(function(){


$(document).on('click', '#update2-produkty-button', function(){

$('#view-update2').modal('show');
var id = $(this).attr('data-id'); 

var json_url= "http://"+url+"/index.php/rozmiary/ListaRozmiarow/id/"+id;
update2x(json_url,id);
})

	
function update2x(json_url, id){

$("#tresc4").html('');

$.getJSON(json_url, function(data){

read_products_html1="";

read_products_html1+="<form  action='#' method='post' border='0'>";

read_products_html1+="<div class='p-3'>";
read_products_html1+="<button type='button' class='btn btn-outline-warning' id='plus2-produkty-button'  data-id='" + id + "'>";
read_products_html1+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj nowy rozmiar/typ i ustal cenę";
read_products_html1+="</button>";
read_products_html1+="</div>";

read_products_html1+="<input type='hidden' name='idprodukt' id='idprodukt' value='"+id+"'>";

read_products_html1+="<div>";
read_products_html1+="<table class='table table-bordered'>";
read_products_html1+="<tr><th>Nazwa</th>";
read_products_html1+="<th>Cena</th>";
read_products_html1+="<th>Upust</th>";
read_products_html1+="<th></th>";
read_products_html1+="<th></th>";
read_products_html1+="<th></th>";
read_products_html1+="</tr>";

$.each(data.dane[0].records, function(key, val){
		
read_products_html1+="<tr>";
read_products_html1+="<td>"+val.rozmiar+" "+val.jednostka+" "+val.datawpr+"</td>";
read_products_html1+="<td>brutto: "+val.cena+" "+val.waluta+" vat - "+val.vat+" %</td>";
read_products_html1+="<td>upust: "+val.upust+" %</td>";
				
read_products_html1+="<td><button class='btn btn-outline-primary' id='fileform-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span>  Obraz";
read_products_html1+="</button></td>";
read_products_html1+="<td><button class='btn btn-outline-info' id='update3-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Zmień dane";
read_products_html1+="</button></td>";	
read_products_html1+="<td><button class='btn btn-outline-danger' id='delete2-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń";
read_products_html1+="</button></td>";	
read_products_html1+="</tr>";	
});		
read_products_html1+="</table>";
read_products_html1+="</div>";
read_products_html1+="<div id='przetwarzaniepopup'></div>";

read_products_html1+="</form>";



$("#tresc4").html(read_products_html1);				
			
});
			
}	





$(document).on('click', '#plus2-produkty-button', function(){
$('#view-plus2').modal('show');
$("#tresc6").html('');

var id = $(this).attr('data-id');

var json_url= "http://"+url+"/index.php/rozmiary/ListaRozmiarow/id/"+id;
var read_products_html="";

read_products_html="";

read_products_html+="<form id='plus2-produkty-form' action='#' method='post' border='0'>";
read_products_html+="<input type='hidden' name='idprodukt' id='idprodukt' value='"+id+"'>";

read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr><td>Rozmiar</td>";
read_products_html+="<td><input type='text' name='rozmiar' id='rozmiarx' value='' class='form-control' required></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td>Jednostka</td>";
read_products_html+="<td><select name='jednostka' id='jednostka' class='form-control'>";
read_products_html+="<option value='sztuka'>sztuka</option>";
read_products_html+="<option value='g'>g</option>";
read_products_html+="<option value='g'> kg</option>";
read_products_html+="<option value='ml'> ml</option>";
read_products_html+="<option value='l'> l</option>";
read_products_html+="</select></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td>Cena</td>";
read_products_html+="<td><input type='text' name='cena' id='cena' value=' ' class='form-control' required></td></tr>";
read_products_html+="<tr><td>Waluta</td>";
read_products_html+="<td><input type='text' name='waluta' id='waluta' value='PLN' class='form-control' required></td></tr>";
read_products_html+="<tr><td>Upust %</td><td><select name='upust' id='upust' class='form-control'>";
read_products_html+="<option value='0'>0</option>";
read_products_html+="<option value='10'>10</option>";
read_products_html+="<option value='20'>20</option>";
read_products_html+="<option value='30'>30</option>";
read_products_html+="<option value='40'>40</option>";
read_products_html+="<option value='40'>50</option>";
read_products_html+="<option value='40'>60</option>";
read_products_html+="<option value='40'>70</option>";
read_products_html+="<option value='40'>80</option>";
read_products_html+="<option value='40'>90</option>";
read_products_html+="<option value='40'>100</option>";
read_products_html+="</select></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td>Vat</td>";
read_products_html+="<td><select name='vat' id='vat' class='form-control'>";
read_products_html+="<option value='23'>23 %</option>";
read_products_html+="<option value=''></option>";
read_products_html+="</select></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td></td>";
read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj nowy rozmiar ";
read_products_html+="</button></td></tr>";
read_products_html+="</table>";
read_products_html+="</div>";
read_products_html+="</form>";
read_products_html+="<div id='przetwarzaniepopup'></div>";
	
$("#tresc6").html(read_products_html);				
});

	
$(document).on('submit', '#plus2-produkty-form', function(){

var form_data=JSON.stringify($(this).serializeObject());
$("#przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');
$.ajax({
    	url: "http://"+url+"/index.php/rozmiary/DodajRozmiar",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
			$("#view-plus2").modal('hide');
	
			var wartosc= document.getElementById('idprodukt');
			var idprodukt = wartosc.value;	
			var json_url2= "http://"+url+"/index.php/rozmiary/ListaRozmiarow/id/"+idprodukt;
			update2x(json_url2, idprodukt);
	}
	});
return false;
		
});


$(document).on('click', '#delete2-produkty-button', function(){

	var id = $(this).attr('data-id');
	var url_json= "http://"+url+"/index.php/rozmiary/UsunRozmiar/id/"+id;
	$.getJSON(url_json, function(data){
				
			
				var wartosc= document.getElementById('idprodukt');
				var idprodukt = wartosc.value;	
				var url_json2= "http://"+url+"/index.php/rozmiary/ListaRozmiarow/id/"+idprodukt;
				
				update2x(url_json2, idprodukt);

		});
	return false;
});






$(document).on('click', '#update3-produkty-button', function(){
				
var id = $(this).attr('data-id');

$('#view-update3').modal('show');
$("#tresc7").html("");
var url_json= "http://"+url+"/index.php/rozmiary/PobierzRozmiar/id/"+id;

$.getJSON(url_json, function(data){
				
$.each(data.dane[0].records, function(key, val) {

read_products_html="";

read_products_html+="<form id='update3-produkty-form' action='#' method='post' border='0'>";
read_products_html+="<input type='hidden' name='id' id='id' value='"+id+"' />";
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr><td>Rozmiar</td>";
read_products_html+="<td><input type='text' name='rozmiar' id='rozmiarx' value='"+val.rozmiar+"' class='form-control'></td></tr>";
read_products_html+="<td>Jednostka</td>";
read_products_html+="<td><select name='jednostka' id='jednostka' value='"+val.jednostka+"' class='form-control'>";
read_products_html+="<option value='sztuka'";
if(val.jednostka == "sztuka") { read_products_html+=" selected='selected' "; } 
read_products_html+=">sztuka</option>";
read_products_html+="<option value='g'>";
if(val.jednostka == "g") { read_products_html+=" selected='selected' "; } 
read_products_html+=">g</option>";
read_products_html+="<option value='g'";
if(val.jednostka == "kg") { read_products_html+=" selected='selected' "; } 
read_products_html+="> kg</option>";
read_products_html+="<option value='ml'";
if(val.jednostka == "ml") { read_products_html+=" selected='selected' "; } 
read_products_html+="> ml</option>";
read_products_html+="<option value='l'";
if(val.jednostka == "l") { read_products_html+=" selected='selected' "; } 
read_products_html+="> l</option>";
read_products_html+="</select></td>";
read_products_html+="</tr>";
			
read_products_html+="<tr><td>Cena</td>";

read_products_html+="<td><input type='text' name='cena' id='cena' value='"+val.cena+"' class='form-control'></td></tr>";
read_products_html+="<tr><td>Waluta</td>";
read_products_html+="<td><input type='text' name='waluta' id='waluta' value='PLN' class='form-control'></td></tr>";
read_products_html+="<td>Upust %</td>";
read_products_html+="<td><select name='upust' id='upust' class='form-control'>";
read_products_html+="<option value='0'";
if(val.upust == "0") { read_products_html+=" selected='selected' "; } 
read_products_html+=">0</option>";
read_products_html+="<option value='10'";
if(val.upust == "l0") { read_products_html+=" selected='selected' "; } 
read_products_html+=">10</option>";
read_products_html+="<option value='20'";
if(val.upust == "20") { read_products_html+=" selected='selected' "; } 
read_products_html+=">20</option>";
read_products_html+="<option value='30'";
if(val.upust == "30") { read_products_html+=" selected='selected' "; } 
read_products_html+=">30</option>";
read_products_html+="<option value='40'";
if(val.upust == "40") { read_products_html+=" selected='selected' "; } 
read_products_html+=">40</option>";
read_products_html+="<option value='40'";
if(val.upust == "50") { read_products_html+=" selected='selected' "; } 
read_products_html+=">50</option>";
read_products_html+="<option value='40'";
if(val.upust == "60") { read_products_html+=" selected='selected' "; } 
read_products_html+=">60</option>";
read_products_html+="<option value='40'";
if(val.upust == "70") { read_products_html+=" selected='selected' "; } 
read_products_html+=">70</option>";
read_products_html+="<option value='40'";
if(val.upust == "80") { read_products_html+=" selected='selected' "; } 
read_products_html+=">80</option>";
read_products_html+="<option value='40'";
if(val.upust == "90") { read_products_html+=" selected='selected' "; } 
read_products_html+=">90</option>";
read_products_html+="<option value='40'";
if(val.upust == "l00") { read_products_html+=" selected='selected' "; } 
read_products_html+=">100</option>";
read_products_html+="</select></td>";
read_products_html+="</tr>";
				
		
read_products_html+="<tr><td>Vat</td>";
read_products_html+="<td><select name='vat' id='vat' class='form-control'>";
read_products_html+="<option value='23'";
if(val.vat == "23") { read_products_html+=" selected='selected' "; } 
read_products_html+=">23 %</option>";
read_products_html+="<option value=''></option>";
read_products_html+="</select></td>";
read_products_html+="</tr>";
read_products_html+="<tr><td></td>";
read_products_html+="<td><button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Modyfikuj  ";
read_products_html+="</button></td></tr>";
read_products_html+="</table>";
read_products_html+="</div>";
read_products_html+="</form>";
read_products_html+="<div id='przetwarzaniepopup'></div>";

$("#tresc7").html(read_products_html);

});
});

return false;	

		
});


	
$(document).on('submit', '#update3-produkty-form', function(){

	var form_data=JSON.stringify($(this).serializeObject());

	$("#przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');
	$.ajax({
    	url: "http://"+url+"/index.php/rozmiary/ZmienRozmiar",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
				$("#view-update3").modal('hide');
						
				var wartosc= document.getElementById('idprodukt');
				var idprodukt = wartosc.value;	
				var url_json2= "http://"+url+"/index.php/rozmiary/ListaRozmiarow/id/"+idprodukt;
		
				update2x(url_json2, idprodukt);
				
				
				}
			});
		return false;
		
})


		
		
$(document).on('submit', '#fileform', function(){
	
		var id = $('#fileform input[name="id"]').val();	
	
		$.ajax({
		url: "http://"+url+"/index.php/rozmiary/SprawdzenieLiczby",
		type : "POST",
		data: {"id":id},
		dataType: 'json',
		success : function(data) {
			
			$(".przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');	
			
			var kom = data.liczba;
			var form = document.getElementById('fileform');
			var fileSelect = document.getElementById('myfile');
			var idform = $('#fileform input[name="id"]').val();
			var uploadButton = document.getElementById('submit');
			var statusDiv = document.getElementById('status');
			statusDiv.innerHTML = '';

	
			var files = fileSelect.files;
			var formData = new FormData();
			var file = files[0]; 

			if (!file.type.match('image.*')) {
	
           		 statusDiv.innerHTML = 'Plik nie jest zdjęciem.';
          		  return;
			}


			var box = document.querySelector('fileSelect');
			


			if (file.size >= 2000000 ) { alert('ffff');
            		statusDiv.innerHTML = 'Rozmiar zdjęcia jest większy niż 2MB. Nie może zostać pobrane.';
            		return;
			}
		
			if (kom >=2) {
           		 statusDiv.innerHTML = 'Sklep posiada już przypisane zdjęcie.';
           		 return;
			}
			
			
			
			formData.append('myfile', file, file.name);
			formData.append('id',  $('#fileform input[name="id"]').val());
			var xhr = new XMLHttpRequest();

			xhr.open('POST','/index.php/rozmiary/DodajZdjecieRozmiar' , false);
  
			xhr.onload = function () {
		
			if (xhr.status === 200) {
           		 statusDiv.innerHTML = 'Plik przesłano.......';
			} else {
            		statusDiv.innerHTML = 'Błąd z przesłaniem pliku. Spróbuj ponownie.';
			}
			};

       
        xhr.send(formData);
		$("#view-fileform").modal("hide");
			}
		});		
		
		return false;

	});
	
	
	
 	
	function show_productsy(id, data)
{	

read_products_html="<form  id='fileform'  action='#' name='' method='post' enctype='multipart/form-data'><input type='file' id='myfile' name='myfile'><p>Poprawny i zalecany rozmiar grafiki: 550mm (szerokość) X 325mm (wysokość).</p><input type='hidden' name='id' id='id' value='"+id+"' /><button type='submit'  class='btn btn-outline-primary'><span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span> Dodaj obraz</button></form>";
read_products_html+="<p id='status'></p>";
read_products_html+="<div id='przetwarzaniepopup'></div>";
			
read_products_html+="<table>";
			var zmienna;
					
			$.each(data.dane[0].records, function(key, val) {
		
				var statusx = val.numer;	
				if(statusx == 0 || statusx == 'x') {  zmienna = 0;	var usun = 'gd';}
					if(zmienna != 0) {
						var str = val.img;
						var find = '/';
						var re = new RegExp(find, 'g');
						c5 = str.replace(re, 'x');
						var c6 =  c5.replace('//','xx');
						var c7 =  c6.replace('_','xxX');
						var c8 =  c7.replace('.','xxXX');
						var usun = 'gd-'+val.id+'-'+c8+'-'+val.numer;	
						var idx = val.id;	
			
						read_products_html+="<tr><td><a target='_blanck' href='http://www."+url+"/index.php/rozmiary/ZdjecieRozmiar/zdjecie/"+usun+"' ><img class='img-thumbnail'  src="+val.img+"  alt='' /></a></td><td><button type='submit' data-id='" + val.numer + "' id='"+usun+"' class='btn btn-outline-success'><span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń obraz </button></td></tr>";		
					}
		
								
					$(document).on('click', '#'+usun+'', function(){
						$.ajax({
						url: "http://"+url+"/index.php/rozmiary/UsunZdjecieRozmiar",
						type : "POST",
						data: {"usun":usun},
						dataType: 'json',
						success : function(data) {
							$.ajax({
								url: "http://"+url+"/index.php/rozmiary/ListaZdjecRozmiar",
								type : "POST",
								data: {"id":id},
								dataType: 'json',
								success : function(data2) {
									show_productsy(id, data2);
								
									$("#tresc5").html(read_products_html);
									
								}
							});
							}
						});		
					});
			
				});			
				
				read_products_html+="</table>";
			
				return read_products_html;
}
	
	
	
$(document).on('click', '#fileform-produkty-button', function(){
var id = $(this).attr('data-id');
$('#view-fileform').modal('show');
$("#tresc5").html('');
	$.ajax({
	
		url: "http://"+url+"/index.php/rozmiary/ListaZdjecRozmiar",
		type : "POST",
		data: {"id":id},
		dataType: 'json',
		success : function(data) {

				show_productsy(id, data);

				var tytul =data.dane[0].records[0].nazwa;
				$("#tresc5").html(read_products_html);
					
		}
		});	
		return false;
});	
	





$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

});



























