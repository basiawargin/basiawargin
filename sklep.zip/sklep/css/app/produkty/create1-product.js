$(document).ready(function(){

$('#view-plus1').on('show.bs.modal', function (event) {
var json_url= "http://"+url+"/index.php/produkty/ListaParametrow";
create1(json_url);
})

$(document).on('change', '#idkategoria', function(){
var idkategoria = $("#idkategoria").val();

if(idkategoria ==='y')
{} else {
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+idkategoria;
}
$.getJSON(json_url, function(data){
	$('#idpodkategoria1').html('');
	$('#idpodkategoria2').html('');
	var read="";
	$.each(data.dane[0].records, function(key2, val2){
	$.each(val2.podkategorie.records, function(key2, val2){
	read+="<option value='" + val2.id+ "'>" + val2.nazwa+ "</option>";
	});
	});
	$('#idpodkategoria1').html(read);		
});
			
});

$(document).on('change', '#idpodkategoria1', function(){
		
var idpodkategoria1 = $("#idpodkategoria1").val();
if(idpodkategoria1 ==='y')
{} else {
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+idpodkategoria1;
}
$.getJSON(json_url, function(data){
$('#idpodkategoria2').html('');
var read="";
$.each(data.dane[0].records, function(key2, val2){
	$.each(val2.podkategorie.records, function(key3, val3){
	read+="<option value='" + val3.id+ "'>" + val3.nazwa+ "</option>"
	});
});
$('#idpodkategoria2').html(read);
});
				
});


	
$(document).on('submit', '#plus1-produkty-form', function(){

var form_data=JSON.stringify($(this).serializeObject()); 
$.ajax({
    	url: "http://"+url+"/index.php/produkty/DodajProdukt",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
		if(data.dane[0].komunikat == 'OK'){
			
				
					var wartosc= document.getElementById('page');
					var page = wartosc.value;	
					var idmarket = $("#idmarket2").val();
					var idkategoria = $("#idkategoria2").val();
					var idpodkategoria1 = $("#idpodkategoria1n2").val();
					var idpodkategoria2 = $("#idpodkategoria2n2").val();

					var json_url= "http://"+url+"/index.php/produkty/ListaProduktow/page/"+page+"/idmarket/"+idmarket+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria1+"/idpodkategoria2/"+idpodkategoria2;
											
					readProductsTemplate(json_url);
					$('#view-plus1').modal('hide');
				}
				else {
					$(".komunikat").html('<p> Niepoprawnie wpisane dane.</p>');
				}
							
				
				}
			});
		return false;
});
	

$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	
});



function create1(json_url){				
				
				
$("#tresc1").html('');
$.getJSON(json_url, function(data){
					
     
read_products_html="<form id='plus1-produkty-form' action='#' method='post' border='0'>";
read_products_html+="<div>";
read_products_html+="<table class='table table-bordered'>";
				
read_products_html+="<tr><td>Market</td><td><select name='idmarket' id='idmarket' class='form-control'>";	
read_products_html+= "<option value=''> market</option>";
$.each(data.dane[0].records, function(keyx, valx) {
read_products_html+= "<option value='"+valx.id+"'>"+valx.nazwa+"</option>";
});
read_products_html+="</select></td></tr>";
				
												
read_products_html+="<tr>";
read_products_html+="<td>Nazwa produktu</td>";
read_products_html+="<td><input type='text' name='nazwa' value='' class='form-control' required></td>";
read_products_html+="</tr>";
				
read_products_html+="<tr>";
read_products_html+="<td>Producent</td>";
read_products_html+="<td><input type='text' name='producent' value='' class='form-control'></td>";
read_products_html+="</tr>";
				
read_products_html+="<tr>";
read_products_html+="<td>Opis</td>";
read_products_html+="<td><input type='text' name='opis' value='' class='form-control'></td>";
read_products_html+="</tr>";
							
read_products_html+="<tr>";
read_products_html+="<td>Kategoria główna</td>";
read_products_html+="<td><select name='idkategoria' id='idkategoria' class='form-control'>";
read_products_html+= "<option value='y'> wybierz kategorię</option>";
$.each(data.dane[1].records, function(keyx, valx) {
read_products_html+= "<option value='"+valx.id+"'>"+valx.nazwa+"</option>";
});
read_products_html+="</select></td></tr>";
			
read_products_html+="<tr>";
read_products_html+="<td>Podkategoria 1</td>";
read_products_html+="<td><select name='idpodkategoria1' id='idpodkategoria1' class='form-control'></select></td>";
read_products_html+="</tr>";

read_products_html+="<tr>";
read_products_html+="<td>Podkategoria 2</td>";
read_products_html+="<td><select name='idpodkategoria2' id='idpodkategoria2' class='form-control'></select></td>";
read_products_html+="</tr>";				
read_products_html+="</table>";
read_products_html+="</div>";		

read_products_html+="<div>";		
read_products_html+="<table class='table table-bordered'>";
read_products_html+="<tr>";
read_products_html+="<td></td>";
read_products_html+="<td colspan='2'>";
read_products_html+="<button type='submit'  class='btn btn-outline-primary'>";
read_products_html+="<span class='oi' data-glyph='plus' title='plus' aria-hidden='true'></span>  Dodaj produkt ";
read_products_html+="</button>";
read_products_html+="</td>";
read_products_html+="</tr>";
read_products_html+="</table>";
read_products_html+="</div>";

read_products_html+="<div class='komunikat'></div>";
read_products_html+="</form>";

					

$("#tresc1").html(read_products_html);
});
				
					
}
		
	
 	   


