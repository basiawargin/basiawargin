$(document).ready(function(){

$('#view-search').on('show.bs.modal', function (event) {
var json_url= "http://"+url+"/index.php/produkty/ListaParametrow";
search(json_url);

})

		
$(document).on('change', '#idkategoria', function(){

var idkategoria = $("#idkategoria").val();
if(idkategoria ==='y')
{} else {
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+idkategoria;
}
document.forms["zmienne-produkty-form"]["idkategoria2"].value = idkategoria;

			
$.getJSON(json_url, function(data){
$('#idpodkategoria1').html('');
$('#idpodkategoria2').html('');
var read="";
$.each(data.dane[0].records, function(key2, val2){
$.each(val2.podkategorie.records, function(key2, val2){
read+="<option value='" + val2.id+ "'>" + val2.nazwa+ "</option>";
});
});
$('#idpodkategoria1').html(read);

var wartosc= document.getElementById('page');
var page = wartosc.value;	
var idmarket = $("#idmarket2").val();
var idkategoria = $("#idkategoria2").val();
var idpodkategoria1 = $("#idpodkategoria1n2").val();
var idpodkategoria2 = $("#idpodkategoria2n2").val();
var json_url= "http://"+url+"/index.php/produkty/ListaProduktow/page/"+page+"/idmarket/"+idmarket+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria1+"/idpodkategoria2/"+idpodkategoria2;
readProductsTemplate(json_url);					
});
});

$(document).on('change', '#idpodkategoria1', function(){
		
var idpodkategoria1 = $("#idpodkategoria1").val();
if(idpodkategoria1 ==='y')
{} else {
var json_url= "http://"+url+"/index.php/kategorie/ListaKategoriiId/id/"+idpodkategoria1;
}
document.forms["zmienne-produkty-form"]["idpodkategoria1n2"].value = idpodkategoria1;
			
$.getJSON(json_url, function(data){
$('#idpodkategoria2').html('');
var read="";
$.each(data.dane[0].records, function(key2, val2){
$.each(val2.podkategorie.records, function(key3, val3){
read+="<option value='" + val3.id+ "'>" + val3.nazwa+ "</option>";
});
});
$('#idpodkategoria2').html(read);
				
var wartosc= document.getElementById('page');
var page = wartosc.value;	
var idmarket = $("#idmarket2").val();
var idkategoria = $("#idkategoria2").val();
var idpodkategoria1 = $("#idpodkategoria1n2").val();
var idpodkategoria2 = $("#idpodkategoria2n2").val();
							
var json_url= "http://"+url+"/index.php/produkty/ListaProduktow/page/"+page+"/idmarket/"+idmarket+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria1+"/idpodkategoria2/"+idpodkategoria2;
readProductsTemplate(json_url);
				
});
				
});

$(document).on('change', '#idpodkategoria2', function(){
		
var idpodkategoria1 = $("#idpodkategoria1").val();
document.forms["zmienne-produkty-form"]["idpodkategoria2n2"].value = idpodkategoria2;		
			
var wartosc= document.getElementById('page');
var page = wartosc.value;	
				
var idmarket = $("#idmarket2").val();
var idkategoria = $("#idkategoria2").val();
var idpodkategoria1 = $("#idpodkategoria1n2").val();
var idpodkategoria2 = $("#idpodkategoria2n2").val();
							
var json_url= "http://"+url+"/index.php/produkty/ListaProduktow/page/"+page+"/idmarket/"+idmarket+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria1+"/idpodkategoria2/"+idpodkategoria2;
readProductsTemplate(json_url);
});


$(document).on('change', '#idmarket', function(){
		
var idmarket = $("#idmarket").val();
document.forms["zmienne-produkty-form"]["idmarket2"].value = idmarket;		
			
var wartosc= document.getElementById('page');
var page = wartosc.value;	
			
var idmarket = $("#idmarket2").val();
var idkategoria = $("#idkategoria2").val();
var idpodkategoria1 = $("#idpodkategoria1n2").val();
var idpodkategoria2 = $("#idpodkategoria2n2").val();
							
var json_url= "http://"+url+"/index.php/produkty/ListaProduktow/page/"+page+"/idmarket/"+idmarket+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria1+"/idpodkategoria2/"+idpodkategoria2;
readProductsTemplate(json_url);
});







});


function search(json_url){

				
				
$("#tresc2").html('');
$.getJSON(json_url, function(data){

read_products_html="<div>";
read_products_html+="<table>";
				
read_products_html+="<tr><td>Market</td><td><select name='idmarket' id='idmarket' class='form-control'>";	
read_products_html+= "<option value=''> market</option>";
$.each(data.dane[0].records, function(keyx, valx) {
read_products_html+= "<option value='"+valx.id+"'>"+valx.nazwa+"</option>";
});
read_products_html+="</select></td></tr>";
				
read_products_html+="<tr>";
read_products_html+="<td>Kategoria główna</td>";
read_products_html+="<td><select name='idkategoria' id='idkategoria' class='form-control'>";
read_products_html+= "<option value='y'> wybierz kategorię</option>";
$.each(data.dane[1].records, function(keyx, valx) {
read_products_html+= "<option value='"+valx.id+"'>"+valx.nazwa+"</option>";
});
read_products_html+="</select></td></tr>";
			
read_products_html+="<tr>";
read_products_html+="<td>Podkategoria 1</td>";
read_products_html+="<td><select name='idpodkategoria1' id='idpodkategoria1' class='form-control'></select></td>";
read_products_html+="</tr>";

read_products_html+="<tr>";
read_products_html+="<td>Podkategoria 2</td>";
read_products_html+="<td><select name='idpodkategoria2' id='idpodkategoria2' class='form-control'></select></td>";
read_products_html+="</tr>";				
read_products_html+="</table>";
read_products_html+="</div>";
			
$("#tresc2").html(read_products_html);	
							
});

}		

	
	
function readProductsTemplate(json_url){
						
$(".paginationblok").html('');
$(".lista").html('');
$("#przetwarzanie").html('<div id="loading"></div>');

	
$.getJSON(json_url, function(data){

if(data.dane[1].paging.liczba_rekordow !== null)
{var li = data.dane[1].paging.liczba_rekordow;} else { var li = 0 ;}

read_products_html2="<div class='col-lg-12'>";

read_products_html2+="<form id='lista-produkty-form' action='#' method='post' border='0'>";

if(data.dane[1].paging.first!=="x"){ 
read_products_html2+="<div class='pt-1'><span class='text-success'>Liczba wyników: "+li+"</span></div><hr />";
read_products_html2+="<input type='hidden' name='page' id='page' value='"+data.dane[1].paging.page+"'>";
}
if(data.dane[1].paging.first!=="x"){
read_products_html2+="<ul id='pagination1' class='pagination'>";
if(data.dane[1].paging.first!==""){
read_products_html2+="<li><a data-page='" + data.dane[1].paging.first + "'> << </a></li>";
}
$.each(data.dane[1].paging.pages, function(key, val){
var active_page=val.current_page=="yes" ? "class='active'" : "";
read_products_html2+="<li " + active_page + "><a data-page='" + val.url + "'>" + val.page + "</a></li>";
});
if(data.dane[1].paging.last!==""){
read_products_html2+="<li><a data-page='" + data.dane[1].paging.last + "'> >> </a></li>";
}
read_products_html2+="</ul>";
} 
read_products_html2+="</div>";	

			

read_products_html1="<div>";
read_products_html1+="<table class='table table-bordered'>";
read_products_html1+="<tbody>";
read_products_html1+="<tr>";
read_products_html1+="<th>ID</th>";
read_products_html1+="<th>Nazwa towaru - identyfikacja</th>";
read_products_html1+="<th colspan=4></th>";
read_products_html1+="</tr>";
				
$.each(data.dane[0].records, function(key, val) {
							
read_products_html1+="<tr>";
read_products_html1+="<td>"+val.id+"</td>";
read_products_html1+="<td>"+val.market+" - ";
read_products_html1+= val.nazwa;
				
				
read_products_html1+="<br />"+val.opis; 
if(typeof val.producent ==='String')
				{ read_products_html1+="<br />"+val.producent; }
read_products_html1+="<br />";
				
read_products_html1+="<i>"+val.kategoria+"<br />";
read_products_html1+= val.podkategoria1+"<br />";
read_products_html1+= val.podkategoria2+"</i></td>";
				
read_products_html1+="<td><button class='btn btn-outline-primary' id='update2-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Dostępne ilości i ceny ";
read_products_html1+="</button></td>";
				
read_products_html1+="<td><button class='btn btn-outline-success' id='update1-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='glyphicon glyphicon-edit'></span> Zmiana danych ";
read_products_html1+="</button></td>";
												
read_products_html1+="<td><button class='btn btn-outline-danger' id='delete1-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń produkt";
read_products_html1+="</button></td>";
				
read_products_html1+="</tr>";
});	
				
read_products_html1+="</tbody>";
read_products_html1+="</table>";
read_products_html1+="</div>";
read_products_html1+="</form>";
read_products_html1+="</div>";

$("#przetwarzanie").html('');						
$(".paginationblok").html(read_products_html2);
$(".lista").html(read_products_html1);
setTimeout(removeLoader, 1000);	
				
});
				
}
			
function removeLoader(){
   	 $( "#loading" ).fadeOut(100, function() {
   	 $( "#loading" ).remove(); 
	});  
}	

	
