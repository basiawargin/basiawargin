
$(document).ready(function(){

	$(document).on('click', '#delete1-produkty-button', function(){

	var id = $(this).attr('data-id');
	var url_json= "http://"+url+"/index.php/produkty/UsunProdukt/id/"+id;
	$.getJSON(url_json, function(data){

	var wartosc= document.getElementById('page');
	var page = wartosc.value;	
	var idmarket = $("#idmarket2").val();
	var idkategoria = $("#idkategoria2").val();
	var idpodkategoria1 = $("#idpodkategoria1n2").val();
	var idpodkategoria2 = $("#idpodkategoria2n2").val();
	var json_url= "http://"+url+"/index.php/produkty/ListaProduktow/page/"+page+"/idmarket/"+idmarket+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria1+"/idpodkategoria2/"+idpodkategoria2;
												
	readProductsTemplate(json_url);
						
		});
	returne false;
	});
});
	

	
	
function readProductsTemplate(json_url){
						
$(".paginationblok").html('');
$(".lista").html('');
$("#przetwarzanie").html('<div id="loading"></div>');

	
$.getJSON(json_url, function(data){

if(data.dane[1].paging.liczba_rekordow !== null)
{var li = data.dane[1].paging.liczba_rekordow;} else { var li = 0 ;}

read_products_html2="<div class='col-lg-12'>";

read_products_html2+="<form id='lista-produkty-form' action='#' method='post' border='0'>";

read_products_html2="<div class='col-lg-12'>";
if(data.dane[1].paging.first!=="x"){ 
read_products_html2+="<div class='pt-1'><span class='text-success'>Liczba wyników: "+li+"</span></div><hr />";
read_products_html2+="<input type='hidden' name='page' id='page' value='"+data.dane[1].paging.page+"'>";
}
if(data.dane[1].paging.first!=="x"){
read_products_html2+="<ul id='pagination1' class='pagination'>";
if(data.dane[1].paging.first!==""){
read_products_html2+="<li><a data-page='" + data.dane[1].paging.first + "'> << </a></li>";
}
$.each(data.dane[1].paging.pages, function(key, val){
var active_page=val.current_page=="yes" ? "class='active'" : "";
read_products_html2+="<li " + active_page + "><a data-page='" + val.url + "'>" + val.page + "</a></li>";
});
if(data.dane[1].paging.last!==""){
read_products_html2+="<li><a data-page='" + data.dane[1].paging.last + "'> >> </a></li>";
}
read_products_html2+="</ul>";
} 
read_products_html2+="</div>";	

			

read_products_html1="<div>";
read_products_html1+="<table class='table table-bordered'>";
read_products_html1+="<tbody>";
read_products_html1+="<tr>";
read_products_html1+="<th>ID</th>";
read_products_html1+="<th>Nazwa towaru - identyfikacja</th>";
read_products_html1+="<th colspan='3'></th>";
read_products_html1+="</tr>";
				
$.each(data.dane[0].records, function(key, val) {
							
read_products_html1+="<tr>";
read_products_html1+="<td>"+val.id+"</td>";
read_products_html1+="<td>"+val.market+" - ";
read_products_html1+= val.nazwa;
				
				
read_products_html1+="<br />"+val.opis; 
if(typeof val.producent ==='String')
				{ read_products_html1+="<br />"+val.producent; }
read_products_html1+="<br />";
				
read_products_html1+="<i>"+val.kategoria+"<br />";
read_products_html1+= val.podkategoria1+"<br />";
read_products_html1+= val.podkategoria2+"</i></td>";
				
read_products_html1+="<td><button class='btn btn-outline-primary' id='update2-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Dostępne ilości i ceny ";
read_products_html1+="</button></td>";
				
read_products_html1+="<td><button class='btn btn-outline-success' id='update1-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span> Zmiana danych ";
read_products_html1+="</button></td>";
												
read_products_html1+="<td><button class='btn btn-outline-danger' id='delete1-produkty-button' data-id='" + val.id + "'>";
read_products_html1+="<span class='oi' data-glyph='trash' title='trash' aria-hidden='true'></span> Usuń produkt";
read_products_html1+="</button></td>";
				
read_products_html1+="</tr>";
});	
				
read_products_html1+="</tbody>";
read_products_html1+="</table>";
read_products_html1+="</div>";
read_products_html1+="</form>";
read_products_html1+="</div>";

$("#przetwarzanie").html('');						
$(".paginationblok").html(read_products_html2);
$(".lista").html(read_products_html1);
setTimeout(removeLoader, 1000);	
				
});
				
}
			
function removeLoader(){
   	 $( "#loading" ).fadeOut(100, function() {
   	 $( "#loading" ).remove(); 
	});  
}			