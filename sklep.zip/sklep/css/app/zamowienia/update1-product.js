$(document).ready(function(){

$('#view-update1').on('show.bs.modal', function (event) {
var id = $(event.relatedTarget).attr('data-id');
var json_url1= "http://"+url+"/index.php/zamowienia/PobierzUzytkownikowDoSelectNadzor";
update1(json_url1, id);
})
	
$(document).on('submit', '#update1-zamowienia-form', function(){

var form_data=JSON.stringify($(this).serializeObject());
$("#przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');
$.ajax({
    	url: "http://"+url+"/index.php/zamowienia/UstalZadanie",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
			$("#view-update1").modal('hide');
			
	}
	});
return false;
		
});

	
$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	
		

});


	
function update1(json_url1, id){

					
$.getJSON(json_url1, function(data){

$("#tresc2").html("");

read_products_html1="<div>";	

read_products_html1+="<form id='update1-zamowienia-form' action='#' method='post' border='0'>";					
read_products_html1+="<select name='iduser' id='iduser' class='form-control'>";	
read_products_html1+="<option value=''>wybierz użytkownika do zadania</option>";
$.each(data.dane[0].records, function(keyx, valx) {
read_products_html1+= "<option value='"+valx.id+"'>"+valx.username+"</option>";
});
read_products_html1+="</select>";
read_products_html1+="<input type='hidden' name='id' value='"+id+"' >";


read_products_html1+="<div class='p-2'>";
read_products_html1+="<button type='submit'  class='btn btn-outline-primary'>";
read_products_html1+="<span class='oi' data-glyph='task' title='task' aria-hidden='true'></span>  Ustal zadanie";
read_products_html1+="</button>";
read_products_html1+="</div>";
read_products_html1+="</form>";

read_products_html1+="</div>";
read_products_html1+="<div id='przetwarzaniepopup'></div>";	
$("#tresc2").html(read_products_html1);
});
				
}
		
