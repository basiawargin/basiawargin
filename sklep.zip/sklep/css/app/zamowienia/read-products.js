
$(document).ready(function(){

	var json_url= "http://"+url+"/index.php/zamowienia/PobierzZamowienia/page/1/";
	readProductsTemplate(json_url);
	
	
	$(document).on('click', '#pagination1 li', function(){		
	var json_url=$(this).find('a').attr('data-page');

	readProductsTemplate(json_url);
	});



});
	

	
	
function readProductsTemplate(json_url){
						
		
	
				$.getJSON(json_url, function(data){

				$(".paginationblok").html('');
				$(".lista").html('');
				
				if(data.dane[1].paging.liczba_rekordow !== null)
				{var li = data.dane[1].paging.liczba_rekordow;} else { var li = 0 ;}
				
				read_products_html2="<form id='lista-zamowienia-form' action='#' method='post' border='0'>"
				if(data.dane[1].paging.first!=="x"){
				read_products_html2+="<div class='panel-body pull-right'><h4><span class='text-success'>Liczba zleceń: "+li+"</span></h4>";
				read_products_html2+="<input type='hidden' name='page' id='page' value='"+data.dane[1].paging.page+"' />";
				}
				if(data.dane[1].paging.first!=="x"){
					
					read_products_html2+="<ul id='pagination1' class='pagination'>";
						if(data.dane[1].paging.first!==""){
						read_products_html2+="<li><a data-page='" + data.dane[1].paging.first + "'> << </a></li>";
						}
						$.each(data.dane[1].paging.pages, function(key, val){
						var active_page=val.current_page=="yes" ? "class='active'" : "";
						read_products_html2+="<li " + active_page + "><a data-page='" + val.url + "'>" + val.page + "</a></li>";
						});
						if(data.dane[1].paging.last!==""){
						read_products_html2+="<li><a data-page='" + data.dane[1].paging.last + "'> >> </a></li>";
						}
					read_products_html2+="</ul>";
				} 
				
				read_products_html2+="</div>";

				read_products_html1="<div><table class='table table-bordered table-hover'>";
				read_products_html1+="<tbody>";
				read_products_html1+="<tr>";
				read_products_html1+="<th>ID</th>";
				read_products_html1+="<th>Data zamówienia</th>";
				read_products_html1+="<th>Adres dostawy</th>";
				read_products_html1+="<th>Data dostawy</th>";
				read_products_html1+="<th></th>";
				read_products_html1+="<th></th>";
				read_products_html1+="<th></th>";
				read_products_html1+="<th></th>";
				read_products_html1+="</tr>";
				
				$.each(data.dane[0].records, function(key, val) {
					
				read_products_html1+="<tr>";
				read_products_html1+="<td>"+val.id+"</td>";
				read_products_html1+="<td>"+val.datawpr+"</td>";
				read_products_html1+="<td>"+val.adres+" "+val.kod+" "+val.miasto+"<br />"+val.telefon+"</td>";
				read_products_html1+="<td>"+val.datadostawy+"</td>";
				
				read_products_html1+="<td><button class='btn btn-outline-warning' id='update1-zamowienia-button' data-toggle='modal' data-target='#view-update1' data-id='" + val.id + "'>";
                read_products_html1+="<span class='glyphicon glyphicon-edit'></span> Zadanie ";
				read_products_html1+="</button></td>";
								
				read_products_html1+="<td><button class='btn btn-outline-success' id='read-zamowienia-button' data-toggle='modal' data-target='#view-read1' data-id='" + val.id + "'>";
                read_products_html1+="<span class='glyphicon glyphicon-edit'></span> Szczegóły ";
				read_products_html1+="</button></td>";
					
				read_products_html1+="<td><button class='btn btn-outline-info' id='update2-zamowienia-button' data-id='" + val.id + "'>";
                read_products_html1+="<span class='glyphicon glyphicon-edit'></span> Zrealizowano ";
				read_products_html1+="</button></td>";
				
				read_products_html1+="<td><button class='btn btn-outline-info' id='print-zamowienia-button' data-id='" + val.id + "'>";
                read_products_html1+="<span class='glyphicon glyphicon-edit'></span> Drukuj ";
				read_products_html1+="</button></td>";
					
				read_products_html1+="</tr>";
				});	
				
				read_products_html1+="</tbody>";
				read_products_html1+="</table></div>";
				read_products_html1+="</form>";
				
										
				$(".paginationblok").html(read_products_html2);
				$(".lista").html(read_products_html1);
				setTimeout(removeLoader, 1000);	
				
				});
				
}
			
	function removeLoader(){
    $( "#loading" ).fadeOut(100, function() {
    $( "#loading" ).remove(); 
	});  
	}			
			