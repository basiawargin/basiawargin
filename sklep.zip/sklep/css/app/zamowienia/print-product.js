$(document).ready(function(){

$(document).on('click', '#print-zamowienia-button', function(){

var id = $(this).attr('data-id');

var json_url= "http://"+url+"/index.php/zamowienia/PobierzZamowienie/id/"+id;

$.getJSON(json_url, function(data){

var externalDataRetrievedFromServer = [];	
var externalDataRetrievedFromServer2 = [];	

	
$.each(data.dane[0].records, function(key, val) {
		
externalDataRetrievedFromServer.push({'Dane': 'ID:'+val.id+', data dostawy: '+val.datadostawy+', data zgloszenia: '+val.datawpr+', adres: '+val.adres+' '+val.miasto+' '+val.kod+', odbiorca: '+val.imie+' '+val.nazwisko+', zadanie:'+val.zadanie});
	
});


$.each(data.dane[0].records, function(key, val) {
	
var s = val.produkty;
var total;	
$.each(s.records, function(key2, val2) {
							
var suma =  val2.cena * val2.ilosc;

externalDataRetrievedFromServer2.push({'Lista towarow': val2.nazwa+' '+val2.ilosc+' ('+val2.jednostka+') '+val2.vat+'%- '+suma+'PLN'});

total +=suma;	

});
});

		
	var dd = {
		content: [
        { text: 'Zamowienie', style: 'header' },
        table(externalDataRetrievedFromServer, ['Dane']),
		table(externalDataRetrievedFromServer2, ['Lista towarow']),
	
		],
		styles: {
		header: {
			fontSize: 16,
			bold: true,
			margin: [0, 0, 0, 10]
		},
		subheader: {
			fontSize: 14,
			bold: true,
			margin: [0, 10, 0, 5]
		},
		tableExample: {
			margin: [0, 5, 0, 15]
		},
		tableHeader: {
			bold: true,
			fontSize: 13,
			color: 'black'
		}
		},
			defaultStyle: {
		// alignment: 'justify'
		}
	}
	pdfMake.createPdf(dd).download('testdoc.pdf');	
				
});
		return false;
});

	
	
		 
});





 
function buildTableBody(data, columns) {
    var body = [];

    body.push(columns);

    data.forEach(function(row) {
        var dataRow = [];

        columns.forEach(function(column) {
            dataRow.push(row[column].toString());
        })

        body.push(dataRow);
    });

    return body;
}
function table(data, columns) {
    return {
        table: {
			widths: ['*'],
            headerRows:1 ,
				heights: 60,
            body: buildTableBody(data, columns)
        },
		
    };
}
	 
   

	






	
function read(json_url){
$("#przetwarzaniepopup").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');	
					
$.getJSON(json_url, function(data){

$("#tresc1").html("");

read_products_html1="<div>";

var total;
total =0;

$.each(data.dane[0].records, function(key, val) {
					
read_products_html1+="<table class='table table-bordered'>";
read_products_html1+="<tbody>";
					
read_products_html1+="<tr>";
read_products_html1+="<td>Data zamówienia</td>";
read_products_html1+="<td>"+val.datawpr+"</td></tr>";
					
read_products_html1+="<tr>";
read_products_html1+="<td>Data dostawy</td>";
read_products_html1+="<td>"+val.datadostawy+"</td></tr>";
				
read_products_html1+="<tr>";
read_products_html1+="<td>Adres</td>";
read_products_html1+="<td>"+val.adres+"</td></tr>";
				
read_products_html1+="<tr>";
read_products_html1+="<td>Dane </td>";
read_products_html1+="<td>"+val.imie+" "+val.nazwisko+"</td></tr>";
				
read_products_html1+="<tr>";
read_products_html1+="<td>Kod - miasto </td>";
read_products_html1+="<td>"+val.kod+" "+val.miasto+"</td></tr>";

read_products_html1+="<tr>";
read_products_html1+="<td>Zadanie dla </td>";
read_products_html1+="<td>"+val.zadanie+"</td></tr>";

read_products_html1+="<tr>";
read_products_html1+="<td>Zadanie przekazano </td>";
read_products_html1+="<td>"+val.datazadania+"</td></tr>";

read_products_html1+="<tr>";
read_products_html1+="<td>Zrealizowano </td>";
read_products_html1+="<td>"+val.zrealizowano+"</td></tr>";

read_products_html1+="</table>";
read_products_html1+="</div>";

read_products_html1+="<div>";				
read_products_html1+="<table class='table table-bordered'>";
read_products_html1+="<tbody>";
	
var s = val.produkty;
			
$.each(s.records, function(key2, val2) {
							
var suma =  val2.cena * val2.ilosc;
								
read_products_html1+="<tr>";
read_products_html1+="<td>ID "+val2.id+"</td>";
read_products_html1+="<td>"+val2.nazwa+"</td>";
read_products_html1+="<td>"+val2.ilosc+" ("+val2.jednostka+") </td>";
read_products_html1+="<td>"+val2.vat+"  %</td>";
read_products_html1+="<td></td>";
read_products_html1+="<td>suma "+suma+" PLN </td>";
read_products_html1+="</tr>";		
						
total +=suma;	

});
				
				
read_products_html1+="<tr>";
read_products_html1+="<td colspan='5'>Razem koszt zamówienia</td>";
read_products_html1+="<td>"+total+" PLN</td>";
read_products_html1+="</tr>";
				
read_products_html1+="<table>";
	
});	
				
read_products_html1+="</div>";
	
$("#tresc1").html(read_products_html1);
$("#przetwarzaniepopup").html('');
				
});
				
}
		
