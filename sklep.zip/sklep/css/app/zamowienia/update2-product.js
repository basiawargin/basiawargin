$(document).ready(function(){


$(document).on('click', '#update2-zamowienia-button', function(){
var id = $(this).attr('data-id'); 

var json_url1= "http://"+url+"/index.php/zamowienia/Zrealizowano/id/"+id;
					
$.getJSON(json_url1, function(data){});

return false;
});

});

