
$(document).ready(function(){
  


$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	

    $(document).on('click', '.create-user-button', function(){
    						
	var create_product_html3="";
	create_product_html3+="<form id='create-user-form' action='#' method='post' border='0'>";
	create_product_html3+="<table class='table table-hover table-responsive table-bordered'>";
 
	create_product_html3+="<tr>";
        create_product_html3+="<td>Nazwa użytkownika (min 4 znaki, min jedna duża litera, min jedna liczba)</td>";
        create_product_html3+="<td><input type='text' name='username' class='form-control' required></td>";
        create_product_html3+="</tr>";
		
	create_product_html3+="<tr>";
        create_product_html3+="<td>Hasło</td>";
        create_product_html3+="<td><input type='password' name='password' class='form-control' required></td>";
        create_product_html3+="</tr>";
	   
	create_product_html3+="<tr>";
        create_product_html3+="<td>Email</td>";
        create_product_html3+="<td><input type='email' name='email' class='form-control' required></td>";
        create_product_html3+="</tr>";
				
	create_product_html3+="<tr>";
 	create_product_html3+="<td>Status</td><td><select name='status' class='form-control'>";				
						
						var status = new Array();
						status[0]= "Banned";
						status[1]= "Aktywny";
						
						var text1;
						text1 = "";
						for (i = 0; i < status.length; i++) {
						text1 += '<option value="' +i+ '">' + status[i] + '</option>';
						} 
	create_product_html3+= text1;
	create_product_html3+= "</select></td></tr>";
	
	create_product_html3+="<tr>";
 	create_product_html3+="<td>Funkcje konta</td><td><select name='superuser'id='superuser' class='form-control'>";				
		var text2;
		text2 += '<option value="2">Uprwaniony do tworzenia konta</option>';
	create_product_html3+= text2;
	create_product_html3+= "</select></td></tr>";
	create_product_html3+="</table>";

	create_product_html3+="<button type='submit'  class='btn btn-primary'>";
        create_product_html3+="<span class='glyphicon glyphicon-plus'></span> Utwórz użytkownika";
       	create_product_html3+="</button>";
	create_product_html3+="</form>";
			
				var dialog = bootbox.dialog({
				title: '<div class="page-header"><h4 id="page-title">Dodanie nowego użytkownika</h4></div>',
				message: '<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>'
				});
				
				dialog.init(function(){
				setTimeout(function(){
				dialog.find('.bootbox-body').html(create_product_html3);
	
				}, 3000);
				});
		
	});

	
		

	
	$(document).on('submit', '#create-user-form', function(){
	var form_data=JSON.stringify($(this).serializeObject());

	$.ajax({
   		 url: "http://"+url+"/index.php/poczta1/CreateUserP",
   		 type : "POST",
  		 dataType : 'json',
 		 data : {"form_data":form_data},
 		 success : function(data) {
		
		 	window.setTimeout(function(){
					bootbox.hideAll();
					}, 100);
		
			var liczba2 = data.liczba2;
		
			var url2 = "http://"+url+"/index.php/poczta1/ListaUsersP";
			ListaUzytkownikow(url2,liczba2);
			}
		});
 
	return false;
	});

		
	
});





