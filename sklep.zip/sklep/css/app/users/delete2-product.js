
$(document).ready(function(){
 
    $(document).on('click', '.delete2-user-button', function(){
	var id = $(this).attr('data-id');	

	$.ajax({
		 url: "http://"+url+"/index.php/poczta1/DeleteUserP",
   		 type : "POST",
		 data:{"id":id},
   		 dataType: 'json',
    		success : function(data) {
				var url2 ="http://"+url+"/index.php/poczta1/ListaUsersP";
				ListaUzytkownikow(url2);
			}
		});
	return false;
	});
});
