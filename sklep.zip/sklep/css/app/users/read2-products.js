

$(document).ready(function(){
	var url2 ="http://"+url+"/index.php/poczta1/ListaUsersP";
	ListaUzytkownikow(url2);
});


function ListaUzytkownikow(json_url)
{

	
	$.getJSON(json_url, function(data){
				
				$(".lista").html('');
				
				read_products_html="<div class='panel-body'>><button class='btn btn-primary create2-user-button'>";
               	read_products_html+="<span class='glyphicon glyphicon-plus'></span> Dodaj nowego użytkownika";
				read_products_html+="</button></div>";
								
				read_products_html+="<div class='panel-body'><table class='table table-bordered table-hover'>";
				read_products_html+="<tr>";
				read_products_html+="<th>Nazwa</th>";
				read_products_html+="<th>Status</th>";
				read_products_html+="<th>Wprowadzenie</th>";
				read_products_html+="<th></th>";
				read_products_html+="<th></th>";
				read_products_html+="</tr>";
				

				$.each(data.records, function(key, val) {
				if(val.superuser==3)
				{					
				var st;
				if(val.status == 1) { st = 'AKTYWNY';}
				if(val.status == 0) { st = 'NIEAKTYWNY';}
								
				read_products_html+="<tr>";
				read_products_html+="<td>";
				read_products_html+="" + val.username + "</td>";
				read_products_html+="<td>"+st+"</td>";
				read_products_html+="<td>"+val.createtime+"</td>";	
				read_products_html+="<td><button class='btn btn-info update2-user-button' data-id='" + val.id + "'>";
               			 read_products_html+="<span class='glyphicon glyphicon-edit'></span> Zmień";
				read_products_html+="</button>";
				read_products_html+="</td>";

					
		
				read_products_html+="<td><button class='btn btn-danger delete2-user-button' data-id='" + val.id + "'>";
                		read_products_html+="<span class='glyphicon glyphicon-remove'></span> Usuń";
				read_products_html+="</button>";
				read_products_html+="</td>";
 				read_products_html+="</tr>";
					
				}
				
				});
				read_products_html+="</table></div>";
				
				
				
				$(".lista").html(read_products_html);
				
		
	});
}
