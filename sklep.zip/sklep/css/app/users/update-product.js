
$(document).ready(function(){

    $(document).on('click', '.update-user-button', function(){
		
	var id = $(this).attr('data-id');	

	$.ajax({
		
  	url: "http://"+url+"/index.php/poczta1/ReadOneUserP",
    	type : "POST",
	data:{"id":id},
    	dataType: 'json',
    	success : function(data) {
		
		var create_product_html3="";
		create_product_html3+="<form id='update-user-form' action='#' method='post' border='0'>";
		create_product_html3+="<table class='table table-hover table-responsive table-bordered'>";
		
		$.each(data.records, function(key, val) {
		create_product_html3+="<tr>";
        	create_product_html3+="<td>Nazwa użytkownika (min 4 znaki, min jedna duża litera, min jedna liczba)<input type='hidden' name='id' id='id' value='"+val.id+"' class='form-control' required></td>";
        	create_product_html3+="<td><input type='text' name='username' class='form-control' value='"+val.username+"' readonly></td>";
        	create_product_html3+="</tr>";
		
		create_product_html3+="<tr>";
        	create_product_html3+="<td>Hasło</td>";
        	create_product_html3+="<td><input type='password' name='password' value=''  class='form-control' required></td>";
        	create_product_html3+="</tr>";
	   
	   	create_product_html3+="<tr>";
        	create_product_html3+="<td>Email</td>";
        	create_product_html3+="<td><input type='email' name='email' value='"+val.email+"'  class='form-control' required></td>";
        	create_product_html3+="</tr>";
				
		create_product_html3+="<tr>";
 		create_product_html3+="<td>Status</td><td><select name='status' class='form-control'>";				
						
						var status = new Array();
						status[0]= "Banned";
						status[1]= "Aktywny";
						
						var text1;
						text1 = "";
						for (i = 0; i < status.length; i++) {
						text1 += '<option value="' +i+ '">' + status[i] + '</option>';
						} 
		create_product_html3+= text1;
		create_product_html3+= "</select></td></tr>";
	
		create_product_html3+="<tr>";
 		create_product_html3+="<td>Funkcje konta</td><td><select name='superuser' id='superuser2' class='form-control'>";				
						
						
						var text2;
						text2 += '<option value="2">Uprwaniony do tworzenia konta</option>';
						
		create_product_html3+= text2;
		create_product_html3+= "</select></td></tr>";
	        
	});
	  	create_product_html3+="</table>";
		create_product_html3+="<button type='submit'  class='btn btn-primary'>";
        	create_product_html3+="<span class='glyphicon glyphicon-plus'></span> Zmień dane użytkownika";
        	create_product_html3+="</button>";
	         create_product_html3+="</form>";
	
			var dialog = bootbox.dialog({
				title: '<div class="page-header"><h4 id="page-title">Zmiana danych użytkownika</h4></div>',
				message: '<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>'
				});
				
				dialog.init(function(){
				setTimeout(function(){
				dialog.find('.bootbox-body').html(create_product_html3);
	
				}, 3000);
				});
	
	
	}
	
	});		
	
});


	
	
	
	
	$(document).on('submit', '#update-user-form', function(){

	var form_data=JSON.stringify($(this).serializeObject());
	$.ajax({
   	 url: "http://"+url+"/index.php/poczta1/UpdateUserP",
  		  type : "POST",
   		  dataType : 'json',
    		  data : {"form_data":form_data},
    		  success : function(data) {

					window.setTimeout(function(){
					bootbox.hideAll();
					}, 100);
		
					var liczba2 = data.liczba2;
					var url2 = "http://"+url+"/index.php/poczta1/ListaUsersP";
					ListaUzytkownikow(url2,liczba2);
		}

	});
		return false;
	});

});


