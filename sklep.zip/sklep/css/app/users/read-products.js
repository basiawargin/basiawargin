

$(document).ready(function(){

	var json_url = "http://"+url+"/index.php/poczta1/ListaUsersP";
	var liczba2=0;
	ListaUzytkownikow(json_url, liczba2);
});


function ListaUzytkownikow(json_url,liczba2)
{

$(".przetwarzanie").html('<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>');	

	$.getJSON(json_url, function(data){
				
				$(".lista").html('');
				
				var html1="";
				if(liczba2 !== 0)
				{
				html1+="<dic class='panel-body text-center'><h4><span class='text-danger'>Istnieje już użytkownik o takiej nazwie lub adresie email</span></h4></div>";
				}
				
				html1+="<div class='panel-body'><button class='btn btn-primary create-user-button'>";
                html1+="<span class='glyphicon glyphicon-plus'></span> Dodaj nowego użytkownika/punkt sprzedaży";
				html1+="</button></div>";
			
								
				html1+="<div class='panel-body'><table class='table table-bordered table-hover'>";
				html1+="<tr>";
				html1+="<th>SZEF</th>";
				html1+="<th>Status</th>";
				html1+="<th>Data wprowadzenia</th>";
				html1+="<th></th>";
					html1+="<th></th>";
				html1+="</tr>";
				
				$.each(data.records, function(key, val) {
				if(val.superuser==2)
				{
				var st;
				if(val.status == 1) { st = 'AKTYWNY';}
				if(val.status == 0) { st = 'NIEAKTYWNY';}
					
				html1+="<tr>";
				html1+="<td>";
				html1+="" + val.username + "</td>";
				html1+="<td>"+st+"</td>";
				html1+="<td>"+val.createtime+"</td>";
				html1+="<td><button class='btn btn-info update-user-button' data-id='" + val.id + "'>";
                		html1+="<span class='glyphicon glyphicon-edit'></span> Hasło";
				html1+="</button></td>";
				
				html1+="<td><button class='btn btn-danger delete-user-button' data-id='" + val.id + "'>";
                		html1+="<span class='glyphicon glyphicon-remove'></span> Usuń";
				html1+="</button>";
				html1+="</td>";
 				html1+="</tr>";
				}
				});
				html1+="</table>";
				
				html1+="<table class='table table-bordered table-hover'>";
				html1+="<tr>";
				html1+="<th>SZEF</th>";
				html1+="<th>Nazwa user</th>";
				html1+="<th>Status</th>";
				html1+="<th>Data wprowadzenia</th>";
				html1+="</tr>";
				

				$.each(data.records, function(key, val) {
				if(val.superuser==3)
				{
							
				var st;
				if(val.status == 1) { st = 'AKTYWNY';}
				if(val.status == 0) { st = 'NIEAKTYWNY';}
				
				
				html1+="<tr>";
				html1+="<td>"+val.wprowadzil+"</td>";
				html1+="<td>" + val.username + "</td>";
				html1+="<td>"+st+"</td>";
				html1+="<td>"+val.createtime+"</td>";
		
 				html1+="</tr>";
					
				}
				});
				html1+="</table></div>";
				$(".lista").html(html1);
				$(".przetwarzanie").html('');			
	});
	
	
}

