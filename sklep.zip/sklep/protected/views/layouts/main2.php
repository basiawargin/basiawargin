<?php session_start();	$_SESSION['cartx']=isset($_SESSION['cartx']) ? $_SESSION['cartx'] : array(); ?>
<!DOCTYPE HTML>
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
    <meta name="author" content="Ceary">
    <title>zakupydoreki.pl</title>
    <!-- Custom Theme files -->
    <link href="<?php echo Yii::app()->request->baseUrl; ?>/css/css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <!-- Owl-Carousel-CSS -->
    <link href="<?php echo Yii::app()->request->baseUrl; ?>/css/css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="<?php echo Yii::app()->request->baseUrl; ?>/css/css/fontawesome-all.min.css" rel="stylesheet">
    <!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="//fonts.googleapis.com/css?family=Elsie+Swash+Caps:400,900" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <!-- //online-fonts -->
    <!-- Icons -->
    <link href="<?php echo Yii::app()->request->baseUrl; ?>/css/css/iconic/font/css/open-iconic.css" rel="stylesheet">
	
	<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/css/css/demo.css?ver=6.1.1">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/hc-offcanvas-nav.js?ver=6.1.1"></script>

</head>
<html>

<body class="theme-default">

    <div id="container">

<!-- header -->
<header>
    <div class="container">
        <nav class="d-flex pt-3 pb-1">
		<h1>
        	<a class="navbar-brand" href="http://kontakt1.vot.pl/index.php">Zr
        	</a>
		</h1>
		<div class="d-flex">
			<div class="d-flex">
        			<a class="align-self-center mx-3" href="http://kontakt1.vot.pl/index.php/user/login">
            				<span class='oi' data-glyph='login' title='login' aria-hidden='true'></span>
             			</a>
            </div>
          	<div class="d-flex">
				<a class="align-self-center mx-3" href="#cart" data-toggle="modal" data-target="#cart">
				<span class='oi' data-glyph='cart' title='cart' aria-hidden='true'></span>		
				</a>
            </div>
        </div>
		</nav>
    </div>
</header>
  </div> 


<?php echo $content ?>

<!-- footer -->
<footer>
	<div class="container">
		<div>
			<div>
				<div>
				<h4></h4>
					<ul>
						<li>
						<a href="#">Regulamin</a>
						</li>
						<li>
						<a href="#">Kontakt</a>
						</li>
						<li>
						<a href="#">Cookie</a>
						</li>
						<li>
						<a href="#">Ochrona danych osobowych</a>
						</li>
  	
					</ul>
				</div>
			</div>
		</div>
	</div>       
</footer>
	
<!-- //footer -->
	
	
	
<!-- cart  -->
    <div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="cart" aria-hidden="true">
        <div class="agilemodal-dialog modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> Zakupy</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body pt-3 pb-5 px-sm-5">
                    <div class="row">
                        <div class="col-md-12">  
                            <div id="zakupy"></div>
			    <p class="load"></p>								      
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- js -->
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/jquery-2.2.3.min.js"></script>
    <!-- //js -->
    <!-- smooth dropdown -->
    <script>
        $(document).ready(function () {
            $('ul li.dropdown').hover(function () {
                $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(200);
            }, function () {
                $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(200);
            });
        });
    </script>
    <!-- //smooth dropdown -->
   
 <!-- start-smooth-scrolling -->
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/move-top.js"></script>
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/easing.js"></script>
    <script>
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();

                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>
    <!-- //end-smooth-scrolling -->
    <!-- smooth-scrolling-of-move-up -->
    <script>
        $(document).ready(function () {
            /*
            var defaults = {
                containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
            };
            */

            $().UItoTop({
                easingType: 'easeOutQuart'
            });

        });
    </script>
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/SmoothScroll.min.js"></script>
    <!-- //smooth-scrolling-of-move-up -->
    <!-- Bootstrap core JavaScript
================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/bootstrap.js"></script>


<script>
 
$(document).ready(function(){

$(document).on('click', '.market li', function(){
var idmarket = $(this).find('a').attr('data-id');
var kod= $("#kod2").val();
document.forms["search"]["idmarket2"].value= idmarket;
		
var json_url = "http://kontakt1.vot.pl/index.php/produkty/ListaProduktow2/page/1/idmarket/"+idmarket+"/kod/"+kod+"/idkategoria//idpodkategoria1//";	

$.getJSON(json_url, function(data){
read_products_html1 ="<ul class='navbar-nav mx-auto text-center'>";		
$.each(data.dane[2].records, function(key, val) {

read_products_html1+="<li class='kategoria1C'><a  class='dropdown-item' data-id='"+val.id+"' href='#'>"+val.nazwa+"</a></li>";
		 
});
read_products_html1+="</ul>";	
						
$(".kategorie1").html(read_products_html1);
ListaProduktow(json_url);
});
return false;

});
  	
	

$(document).on('change', '#market', function(){
var idmarket= $("#market").val();
var kod= $("#kod2").val();
document.forms["search"]["idmarket2"].value= idmarket;
		
var json_url = "http://kontakt1.vot.pl/index.php/produkty/ListaProduktow2/page/1/idmarket/"+idmarket+"/kod/"+kod+"/idkategoria//idpodkategoria1//";	
$.getJSON(json_url, function(data){
read_products_html1 ="<ul class='navbar-nav mx-auto text-center'>";		
$.each(data.dane[2].records, function(key, val) {

read_products_html1+="<li class='kategoria1C'><a  class='dropdown-item' data-id='"+val.id+"' href='#'>"+val.nazwa+"</a></li>";
		 
});
read_products_html1+="</ul>";								
$(".kategorie1").html(read_products_html1);
ListaProduktow(json_url);
});
return false;
});
  


$(document).on('click', '.kategoria1C', function(){
var idkategoria = $(this).find('a').attr('data-id');
document.forms["search"]["idkategoria2"].value= idkategoria;
var idmarket= $("#idmarket2").val();
var kod= $("#kod2").val();
var json_url = "http://kontakt1.vot.pl/index.php/produkty/ListaProduktow2/page/1/idmarket/"+idmarket+"/kod/"+kod+"/idkategoria/"+idkategoria+"/idpodkategoria1//";	

$.getJSON(json_url, function(data){
read_products_html1="<ul class='navbar-nav mx-auto text-center'>";		
$.each(data.dane[3].records, function(key, val) {
 read_products_html1+="<li class='kategoria2C'><a data-id='"+val.id+"' class='dropdown-item' href='#'>"+val.nazwa+"</a></li>";
});
read_products_html1+="</ul>";								
$(".kategorie2").html(read_products_html1);
ListaProduktow(json_url);
});
return false;
});
  
  

$(document).on('click', '.kategoria2C', function(){

var idpodkategoria = $(this).find('a').attr('data-id');
document.forms["search"]["idpodkategoria2"].value= idpodkategoria;
var idkategoria= $("#idkategoria2").val();
var idmarket= $("#idmarket2").val();
var kod= $("#kod2").val();
var json_url = "http://kontakt1.vot.pl/index.php/produkty/ListaProduktow2/page/1/idmarket/"+idmarket+"/kod/"+kod+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria;	

$.getJSON(json_url, function(data){
		
read_products_html1="<ul class='navbar-nav mx-auto text-center'>";		
$.each(data.dane[3].records, function(key, val) {
read_products_html1+="<li class='kategoria2C'><a data-id='"+val.id+"' class='dropdown-item' href='#'>"+val.nazwa+"</a></li>";
});
read_products_html1+="</ul>";								
$(".kategorie2").html(read_products_html1);
ListaProduktow(json_url);
});
return false;
});
  

function ListaProduktow(json_url)
{

$("#przetwarzanie").html('<div id="loading"><p></p></div>');
$("#produkty").html('');
$("#paginationdiv").html('');


$.getJSON(json_url, function(data){

if(data.dane[1].paging.liczba_rekordow !== null)
{var li = data.dane[1].paging.liczba_rekordow;} else { var li = 0 ;}
				
read_products_html2="";
if(data.dane[1].paging.first!=="x"){
read_products_html2+="<div class='col-lg-8 mt-lg-0 m-2 justify-content-right'><span class='text-success'>Liczba produktów: "+li+"</span>";
read_products_html2+="<input type='hidden' name='page' id='page' value='"+data.dane[1].paging.page+"' />";
}

if(data.dane[1].paging.first!=="x"){
read_products_html2+="<ul id='pagination1' class='pagination mt-2 justify-content-left'>";
if(data.dane[1].paging.first!==""){
read_products_html2+="<li  class='page-item disabled'><a class='page-link' data-page='" + data.dane[1].paging.first + "'> << </a></li>";
}
$.each(data.dane[1].paging.pages, function(key, val){
var active_page=val.current_page=="yes" ? "class='active'" : "";
read_products_html2+="<li class='page-item' " + active_page + "><a class='page-link' data-page='" + val.url + "'>" + val.page + "</a></li>";
});
if(data.dane[1].paging.last!==""){
read_products_html2+="<li class='page-item'><a class='page-link' data-page='" + data.dane[1].paging.last + "'> >> </a></li>";
}
read_products_html2+="</ul>";
} 
read_products_html2+="</div>";


read_products_html1="<div class='justify-content-right'>";
$.each(data.dane[0].records, function(key, val) {

read_products_html1+="<p class='float-right text-capitalize col-lg-1'>";
read_products_html1+="<ul class='dodajdokoszyka float-right'><li><a href='#' data-id='"+val.id+"' class='btn btn-outline-warning btn-sm'>dodaj</a></li></ul>";
read_products_html1+="</p>";
read_products_html1+="<p class='col-lg-8 text-capitalize'>"+val.nazwa+" ("+val.rozmiar+" "+val.jednostka+") </p>";
read_products_html1+="<p class='text-capitalize col-lg-3'>"+val.cena+" PLN   </p>";

read_products_html1+="<div class='product-id d-none clearfix' >"+val.id+"</div>";
read_products_html1+="<hr />";
});
read_products_html1+="</div>";

				
										
$("#paginationdiv").html(read_products_html2);
$("#produkty").html(read_products_html1);
setTimeout(removeLoader, 100);	
				
});
			
	
}

$(document).on('click', '#pagination1 li', function(){		
var json_url=$(this).find('a').attr('data-page');
ListaProduktow(json_url);
		
});
 
$('#cart').on('show.bs.modal', function (event) { 

var json_url = "http://kontakt1.vot.pl/index.php/produkty/DisplayCart";

pokazKoszyk(json_url);
})

 $(document).on('click', '#realizuj', function(){
location.href = "http://kontakt1.vot.pl/index.php/user/checkout";
return false;
});
   
 $(document).on('click', '#powrot', function(){
location.href = "http://kontakt1.vot.pl";
return false;
})


  
 $(document).on('click', '.dodajdokoszyka', function(){

		var id=$(this).find('a').attr('data-id');
      		var json_url = "http://kontakt1.vot.pl/index.php/produkty/AddToCart/id/"+id+"/quantity/1";	
		alert(json_url);
		$.getJSON(json_url, function(data){
		});
		return false;
});

	
});
  
function pokazKoszyk(json_url)
{
			
		$.getJSON(json_url, function(data){
			
			$(".load").html('<i class="fa fa-spin fa-spinner"></i> Przetwarzanie...');
			$('.koszyk').html('');
			
			var read_products_html="";
			if(data.dane[2].paging.id === "N")
			{
				
				
				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Należy się zalogować lub zarejestrować, jeśli nie masz konta.</p>";
				read_products_html+="</div>";

			} else {
			

				if(data.dane[0] === null)
				{
				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Brak produktow w koszyku.</p>";
				read_products_html+="</div>";
				} 
				else {	
					var total ="";
					var produkty = '';
			
					read_products_html+="<div class='py-5 text-center'>";
					read_products_html+="";
					read_products_html+="<h2>Twoje zamówienie</h2>";
					read_products_html+="<p class='lead'>Szczegóły</p>";
					read_products_html+="</div>";	
					read_products_html+="<div class='justify-content-center'><div class='col-md-12 order-md-1'>";
					read_products_html+="<h4 class='mb-3'></h4>";
					read_products_html+="<form action='#' name='koszyk-form1' id='koszyk-form1' method='pos'>";
				
					$.each(data.dane[0].records, function(keyx, valx) {
							
					read_products_html+="<div class='row'>";
					read_products_html+="<div class='col-md-9 mb-3'>";
					read_products_html+="<div class='float-left'>"+valx.nazwa+"  "+valx.rozmiar+"  "+valx.jednostka+"  -   "+valx.cena+"  "+valx.waluta+" </div>";
					read_products_html+="<div class='float-right'> Razem: "+valx.subtotal+"  "+valx.waluta+"</div>";
					read_products_html+="</div>";
				
					read_products_html+="</div><br />";
					
					});		
				
					read_products_html+="<div class='justify-content-center px-2 px-sm-2 px-md-2'>";
					read_products_html+="<div> Razem: "+data.dane[1].paging.cenatotal+" PLN</div>";
					read_products_html+="</div>";
									
					read_products_html+="<hr class='mb-4 '>";
					read_products_html+="<div class='col-lg-5 float-left px-sm-2 px-md-2'>";
					read_products_html+="<input type='submit' id='realizuj' name='realizuj' class='form-control col-lg-12 col-md-3 col-sm-3 col-6' value=' Realizuj zakupy' />";
					read_products_html+="</div>";
					read_products_html+="<div class='col-lg-5 float-left px-sm-2 px-md-2'>";
					read_products_html+="<input type='submit' id='powrot' name='powrot' class='form-control col-lg-12 col-md-3 col-sm-3 col-6' value=' Powrót do listy zakupów' />";
					read_products_html+="</div>";
					read_products_html+="</form>";
					read_products_html+="</div></div>";
				}
						
			}
			$(".load").html('');	
			$('.koszyk').html(read_products_html);
		});	
			
	
}		
  	
function removeLoader(){
$( "#loading" ).fadeOut(100, function() {
$( "#loading" ).remove(); 
});  
}
</script>

  


 <script>
        (function($) {
          'use strict';

          // call our plugin
          var Nav = new hcOffcanvasNav('#main-nav', {
            disableAt: false,
            customToggle: '.toggle',
            levelSpacing: 40,
            navTitle: 'All Categories',
            levelTitles: true,
            levelTitleAsBack: true,
            pushContent: '#container',
            labelClose: false
          });

          // add new items to original nav
          $('#main-nav').find('li.add').children('a').on('click', function() {
            var $this = $(this);
            var $li = $this.parent();
            var items = eval('(' + $this.attr('data-add') + ')');

            $li.before('<li class="new"><a href="#">'+items[0]+'</a></li>');

            items.shift();

            if (!items.length) {
              $li.remove();
            }
            else {
              $this.attr('data-add', JSON.stringify(items));
            }

            Nav.update(true); // update DOM
          });

          // demo settings update

          const update = function(settings) {
            if (Nav.isOpen()) {
              Nav.on('close.once', function() {
                Nav.update(settings);
                Nav.open();
              });

              Nav.close();
            }
            else {
              Nav.update(settings);
            }
          };

          $('.actions').find('a').on('click', function(e) {
            e.preventDefault();

            var $this = $(this).addClass('active');
            var $siblings = $this.parent().siblings().children('a').removeClass('active');
            var settings = eval('(' + $this.data('demo') + ')');

            if ('theme' in settings) {
              $('body').removeClass().addClass('theme-' + settings['theme']);
            }
            else {
              update(settings);
            }
          });

          $('.actions').find('input').on('change', function() {
            var $this = $(this);
            var settings = eval('(' + $this.data('demo') + ')');

            if ($this.is(':checked')) {
              update(settings);
            }
            else {
              var removeData = {};
              $.each(settings, function(index, value) {
                removeData[index] = false;
              });

              update(removeData);
            }
          });
        })(jQuery);
      </script>


 
</body>
</html>
