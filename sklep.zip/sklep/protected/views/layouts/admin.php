﻿<?php $this->beginContent('//layouts/main'); ?>
<?php $id_user=Yii::app()->user->id; $dane = User::model()->findbyPk($id_user); 
if(isset($dane))
{ $powitanie ='<a  class="nav-link" href="'.Yii::app()->request->baseUrl.'/index.php/user/login">Zalogowany: '.$dane->username.'</a>';}
else { $powitanie = '<a class="nav-link" href="'.Yii::app()->request->baseUrl.'/index.php/user/login">Zaloguj się</a>'; }
?>
 


<div class="container">
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			<li class="nav-item"><?php echo $powitanie; ?></li>
			<?php if($dane->superuser !='')  {
			?>
			<?php if($dane->superuser == 1)  { ?>
			<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/kategorie" class="nav-link">Kategorie</a></li>
			
           		<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/sklepy" class="nav-link">Sklepy</a></li>
			<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/produkty" class="nav-link" >Oferta</a></li>
	
			<?php } ?>
			<?php if($dane->superuser == 1 or $dane->superuser == 2)  { ?>
			<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/zamowienia" class="nav-link">Realizacja ofert</a></li>
			<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/user/logout" class="nav-link">Wyloguj</a></li>
			<?php }
			}?>
			</ul>
		</div>
	</nav>
</div>                                           
 

<div class="row">
	<div class="container">
       	<?php echo $content; ?>
	</div>
</div>
	
 
<?php $this->endContent(); ?>	


