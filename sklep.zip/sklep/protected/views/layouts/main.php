<?php session_start();	$_SESSION['cartx']=isset($_SESSION['cartx']) ? $_SESSION['cartx'] : array(); ?>
<!DOCTYPE HTML>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
    <meta name="author" content="Ceary">
    <title>zakupydoreki.pl</title>

<!-- Icons -->
    <link href="<?php echo Yii::app()->request->baseUrl; ?>/css/css/iconic/font/css/open-iconic.css" rel="stylesheet">
	
	<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/css/css/demo.css?ver=6.1.1">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/hc-offcanvas-nav.js?ver=6.1.1"></script>



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<html>



<body class="theme-default">

<div id="container">
<nav class="d-flex pt-3 pb-1">
<div class="d-flex">
<a class="align-self-center mx-3" href="http://kontakt1.vot.pl/index.php/user/login">
<span class='oi' data-glyph='person' title='logowanie' aria-hidden='true'></span>
</a>
</div>
<div class="d-flex">
<a class="align-self-center mx-3" href="#cart" data-toggle="modal" data-target="#cart">
<span class='oi' data-glyph='cart' title='kosyk na akupy' aria-hidden='true'></span>		
</a>
</div>
<div class="d-flex">
<a class="align-self-center mx-3" href="/index.php">
<span class='oi' data-glyph='action-undo' title='start' aria-hidden='true'></span>		
</a>
</div>

</nav>


<main>
<?php echo $content ?>
</main>




</div>
	
<!-- cart  -->
    <div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="cart" aria-hidden="true">
        <div class="agilemodal-dialog modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> Zakupy</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body pt-3 pb-5 px-sm-5">
                    <div class="row">
                        <div class="col-md-12">  
                            <div id="zakupy"></div>
			    <p class="load"></p>								      
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- js -->
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/jquery-2.2.3.min.js"></script>
    <!-- //js -->
    
    <!-- Bootstrap core JavaScript
================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/css/js/bootstrap.js"></script>


<script>
 
$(document).ready(function(){

$(document).on('click', '.market li', function(){

var idmarket = $(this).find('a').attr('data-id');
var kod= $("#kod2").val();
document.forms["search"]["idmarket2"].value= idmarket;
var json_url = "http://kontakt1.vot.pl/index.php/produkty/ListaProduktow2/page/1/idmarket/"+idmarket+"/kod/"+kod+"/idkategoria//idpodkategoria1//";	
ListaProduktow(json_url);
return false;

});
  	
	
$(document).on('click', '.k1 li', function(){

var idkategoria = $(this).find('a').attr('data-id');
document.forms["search"]["idkategoria2"].value= idkategoria;
var idmarket= $("#idmarket2").val();
var kod= $("#kod2").val();

var json_url = "http://kontakt1.vot.pl/index.php/produkty/ListaProduktow2/page/1/idmarket/"+idmarket+"/kod/"+kod+"/idkategoria/"+idkategoria+"/idpodkategoria1//";	
ListaProduktow(json_url);
return false;
});
  
  

$(document).on('click', '#kategoria2C li', function(){

var idpodkategoria = $(this).find('a').attr('data-id');
document.forms["search"]["idpodkategoria2"].value= idpodkategoria;
var idkategoria= $("#idkategoria2").val();
var idmarket= $("#idmarket2").val();
var kod= $("#kod2").val();
var json_url = "http://kontakt1.vot.pl/index.php/produkty/ListaProduktow2/page/1/idmarket/"+idmarket+"/kod/"+kod+"/idkategoria/"+idkategoria+"/idpodkategoria1/"+idpodkategoria;	
ListaProduktow(json_url);
return false;
});
  




function ListaProduktow(json_url)
{

$("#przetwarzanie").html('<div id="loading"><p></p></div>');
$("#produkty").html('');
$("#paginationdiv").html('');


$.getJSON(json_url, function(data){


read_products_html2="<div class='col-lg-8 mt-lg-0 m-2 justify-content-right'>";
if(data.dane[1].paging.liczba_rekordow !== null)
{var li = data.dane[1].paging.liczba_rekordow;} else { var li = 0 ;}
				
read_products_html2="";
if(data.dane[1].paging.first!=="x"){
read_products_html2+="<span class='text-success'>Liczba produktów: "+li+"</span>";
read_products_html2+="<input type='hidden' name='page' id='page' value='"+data.dane[1].paging.page+"' />";
}

if(data.dane[1].paging.first!=="x"){
read_products_html2+="<ul id='pagination1' class='pagination mt-2 justify-content-left'>";
if(data.dane[1].paging.first!==""){
read_products_html2+="<li  class='page-item disabled'><a class='page-link' data-page='" + data.dane[1].paging.first + "'> << </a></li>";
}
$.each(data.dane[1].paging.pages, function(key, val){
var active_page=val.current_page=="yes" ? "class='active'" : "";
read_products_html2+="<li class='page-item' " + active_page + "><a class='page-link' data-page='" + val.url + "'>" + val.page + "</a></li>";
});
if(data.dane[1].paging.last!==""){
read_products_html2+="<li class='page-item'><a class='page-link' data-page='" + data.dane[1].paging.last + "'> >> </a></li>";
}
read_products_html2+="</ul>";
} 
read_products_html2+="</div>";


read_products_html1="<div class='justify-content-right'>";
$.each(data.dane[0].records, function(key, val) {

read_products_html1+="<p class=''>";
read_products_html1+="<ul class='dodajdokoszyka float-right'><li class='col-lx-5'><a href='#' data-id='"+val.id+"' ><span class='oi' data-glyph='tags' title='logowanie' aria-hidden='true'></span></a></li></ul>";
read_products_html1+="</p>";
read_products_html1+="<p>"+val.nazwa+" ("+val.rozmiar+" "+val.jednostka+") "+val.cena+" PLN   </p>";


read_products_html1+="<div class='product-id d-none clearfix' >"+val.id+"</div>";
read_products_html1+="<hr />";
});
read_products_html1+="</div>";

				
										

$("#produkty").html(read_products_html1);
setTimeout(removeLoader, 100);	
				
});
			
	
}
 	
function removeLoader(){
$( "#loading" ).fadeOut(100, function() {
$( "#loading" ).remove(); 
});  
}








$(document).on('click', '#pagination1 li', function(){		
var json_url=$(this).find('a').attr('data-page');
ListaProduktow(json_url);
	
});
 
$('#cart').on('show.bs.modal', function (event) { 
var json_url = "http://kontakt1.vot.pl/index.php/produkty/DisplayCart";
pokazKoszyk(json_url);
})

 $(document).on('click', '#realizuj', function(){
location.href = "http://kontakt1.vot.pl/index.php/user/checkout";
return false;
});
   
 $(document).on('click', '#powrot', function(){
location.href = "http://kontakt1.vot.pl";
return false;
})


  
$(document).on('click', '.dodajdokoszyka', function(){

		var id=$(this).find('a').attr('data-id');
      		var json_url = "http://kontakt1.vot.pl/index.php/produkty/AddToCart/id/"+id+"/quantity/1";	
		$.getJSON(json_url, function(data){
		});
		return false;
});

	
});
  
function pokazKoszyk(json_url)
{
			
		$.getJSON(json_url, function(data){
			
			$(".load").html('<i class="fa fa-spin fa-spinner"></i> Przetwarzanie...');
			$('.koszyk').html('');
			
			var read_products_html="";
			if(data.dane[2].paging.id === "N")
			{
				
				
				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Należy się zalogować lub zarejestrować, jeśli nie masz konta.</p>";
				read_products_html+="</div>";

			} else {
			

				if(data.dane[0] === null)
				{
				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Brak produktow w koszyku.</p>";
				read_products_html+="</div>";
				} 
				else {	
					var total ="";
					var produkty = '';
			
					read_products_html+="<div class='py-5 text-center'>";
					read_products_html+="";
					read_products_html+="<h2>Twoje zamówienie</h2>";
					read_products_html+="<p class='lead'>Szczegóły</p>";
					read_products_html+="</div>";	
					read_products_html+="<div class='justify-content-center'><div class='col-md-12 order-md-1'>";
					read_products_html+="<h4 class='mb-3'></h4>";
					read_products_html+="<form action='#' name='koszyk-form1' id='koszyk-form1' method='pos'>";
				
					$.each(data.dane[0].records, function(keyx, valx) {
							
					read_products_html+="<div class='row'>";
					read_products_html+="<div class='col-md-9 mb-3'>";
					read_products_html+="<div class='float-left'>"+valx.nazwa+"  "+valx.rozmiar+"  "+valx.jednostka+"  -   "+valx.cena+"  "+valx.waluta+" </div>";
					read_products_html+="<div class='float-right'> Razem: "+valx.subtotal+"  "+valx.waluta+"</div>";
					read_products_html+="</div>";
				
					read_products_html+="</div><br />";
					
					});		
				
					read_products_html+="<div class='justify-content-center px-2 px-sm-2 px-md-2'>";
					read_products_html+="<div> Razem: "+data.dane[1].paging.cenatotal+" PLN</div>";
					read_products_html+="</div>";
									
					read_products_html+="<hr class='mb-4 '>";
					read_products_html+="<div class='col-lg-5 float-left px-sm-2 px-md-2'>";
					read_products_html+="<input type='submit' id='realizuj' name='realizuj' class='form-control col-lg-12 col-md-3 col-sm-3 col-6' value=' Realizuj zakupy' />";
					read_products_html+="</div>";
					read_products_html+="<div class='col-lg-5 float-left px-sm-2 px-md-2'>";
					read_products_html+="<input type='submit' id='powrot' name='powrot' class='form-control col-lg-12 col-md-3 col-sm-3 col-6' value=' Powrót do listy zakupów' />";
					read_products_html+="</div>";
					read_products_html+="</form>";
					read_products_html+="</div></div>";
				}
						
			}
			$(".load").html('');	
			$('.koszyk').html(read_products_html);
		});	
			
	
}		
 
</script>

  


 <script>
        (function($) {
          'use strict';

          // call our plugin
          var Nav = new hcOffcanvasNav('#main-nav', {
            disableAt: false,
            customToggle: '.toggle',
            levelSpacing: 40,
            navTitle: 'Wszystkie kategorie',
            levelTitles: true,
            levelTitleAsBack: true,
            pushContent: '#container',
            labelClose: false
          });

          // add new items to original nav
          $('#main-nav').find('li.add').children('a').on('click', function() {
            var $this = $(this);
            var $li = $this.parent();
            var items = eval('(' + $this.attr('data-add') + ')');

            $li.before('<li class="new"><a href="#">'+items[0]+'</a></li>');

            items.shift();

            if (!items.length) {
              $li.remove();
            }
            else {
              $this.attr('data-add', JSON.stringify(items));
            }

            Nav.update(true); // update DOM
          });

          // demo settings update

          const update = function(settings) {
            if (Nav.isOpen()) {
              Nav.on('close.once', function() {
                Nav.update(settings);
                Nav.open();
              });

              Nav.close();
            }
            else {
              Nav.update(settings);
            }
          };

          $('.actions').find('a').on('click', function(e) {
            e.preventDefault();

            var $this = $(this).addClass('active');
            var $siblings = $this.parent().siblings().children('a').removeClass('active');
            var settings = eval('(' + $this.data('demo') + ')');

            if ('theme' in settings) {
              $('body').removeClass().addClass('theme-' + settings['theme']);
            }
            else {
              update(settings);
            }
			
			
			
			
			
			
			
          });
		  
		  
		  $('.k1').find('a').on('click', function(e) {
          });
		  
		  

          $('.actions').find('input').on('change', function() {
            var $this = $(this);
            var settings = eval('(' + $this.data('demo') + ')');

            if ($this.is(':checked')) {
              update(settings);
            }
            else {
              var removeData = {};
              $.each(settings, function(index, value) {
                removeData[index] = false;
              });

              update(removeData);
            }
          });
        })(jQuery);
      </script>


 
</body>
</html>
