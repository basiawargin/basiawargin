

<header>
<div class="wrapper cf">
<form id="search" action="<?php echo $_SERVER['PHP_SELF'] ?>"  method="POST">
   
<div class="input-group col-xl-7 col-lg-4  mb-3 sm-12 justify-content-center">
<span class='oi toggle p-2' data-glyph='menu' title='menu' aria-hidden='true'></span>
<input type="text" name="kod" class="form-control" placeholder="wprowadź kod pocztowy" >
<input type="submit" class="btn btn-outline-secondary dropdown-toggle"  value="szukaj">


</div>




<input type="hidden" name="kod2" id="kod2" value="<?php echo $kod ?>">
<input type="hidden" name="idmarket2" id="idmarket2" value="">
<input type="hidden" name="idkategoria2" id="idkategoria2" value="">
<input type="hidden" name="idpodkategoria2" id="idpodkategoria2" value="">

</form>

<nav id="main-nav">
<ul class="first-nav k1">
              
			  
<li><a  class='dropdown-item' data-id='1' href='#'>Pieczywo i ciasto</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='2' href='#'>Chleby</a></li>
<li><a  class='dropdown-item' data-id='3' href='#'>Bagietki</a></li>
<li><a  class='dropdown-item' data-id='4' href='#'>Bułki</a></li>
<li><a  class='dropdown-item' data-id='5' href='#'>Pieczywo słodkie</a></li>
<li><a  class='dropdown-item' data-id='6' href='#'>Pieczywo słone</a></li>
<li><a  class='dropdown-item' data-id='61' href='#'>Ciasto</a></li>
<li><a  class='dropdown-item' data-id='62' href='#'>Wypieki</a></li>
<li><a  class='dropdown-item' data-id='63' href='#'>Bułka tarta</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='7' href='#'>Nabiał</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='8' href='#'>Masło, margaryna</a></li>
<li><a  class='dropdown-item' data-id='9' href='#'>Maślanki, kefiry, mleko, napoje mleczne</a></li>
<li><a  class='dropdown-item' data-id='10' href='#'>Sery</a></li>
<li><a  class='dropdown-item' data-id='11' href='#'>Śmietana</a></li>
<li><a  class='dropdown-item' data-id='12' href='#'>Desery</a></li>
<li><a  class='dropdown-item' data-id='13' href='#'>Jaja</a></li>
<li><a  class='dropdown-item' data-id='14' href='#'>Drożdże</a></li>
<li><a  class='dropdown-item' data-id='35' href='#'>Jogurty</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='15' href='#'>Owoce i warzywa</a>
<ul class='k2'>
<li><a  class='dropdown-item' data-id='16' href='#'>Owoce</a></li>
<li><a  class='dropdown-item' data-id='17' href='#'>Warzywa</a></li>
<li><a  class='dropdown-item' data-id='18' href='#'>Surórwki, kiszonki</a></li>
<li><a  class='dropdown-item' data-id='19' href='#'>BIO</a></li>
<li><a  class='dropdown-item' data-id='27' href='#'>Mrożonki warzywne</a></li>
<li><a  class='dropdown-item' data-id='36' href='#'>Mrożonki owocowe</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='20' href='#'>Kasza, Makaron, Mąka, Ryż</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='37' href='#'>Kasze</a></li>
<li><a  class='dropdown-item' data-id='38' href='#'>Makarony</a></li>
<li><a  class='dropdown-item' data-id='39' href='#'>Mąka</a></li>
<li><a  class='dropdown-item' data-id='40' href='#'>Ryż</a></li>
</ul>
</li>



<li><a  class='dropdown-item' data-id='21' href='#'>Ryby i owoce morza</a>
<ul class="k2" >
<li><a class='dropdown-item' data-id='28' href='#'>Mrożonki rybne</a></li>
<li><a class='dropdown-item' data-id='41' href='#'>Mrożonki owoce morza</a></li>
<li><a class='dropdown-item' data-id='42' href='#'>Ryby przetworzone w opakowaniach</a></li>
<li><a class='dropdown-item' data-id='70' href='#'>Konserwy rybne</a></li>
</ul>
</li>




<li class='k2'><a  class='dropdown-item' data-id='22' href='#'>Mięso</a>
<ul>
<li><a  class='dropdown-item' data-id='23' href='#'>Wędliny</a></li>
<li><a  class='dropdown-item' data-id='24' href='#'>Mięso surowe, przetworzone</a></li>
<li><a  class='dropdown-item' data-id='25' href='#'>Mięso przetworzone, pakowane</a></li>
<li><a  class='dropdown-item' data-id='26' href='#'>Mrożonki mięso</a></li>
<li><a  class='dropdown-item' data-id='43' href='#'>Kiełbasy</a></li>
<li><a  class='dropdown-item' data-id='64' href='#'>Konserwy mięsne</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='22' href='#'>Mięso</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='23' href='#'>Wędliny</a></li>
<li><a  class='dropdown-item' data-id='24' href='#'>Mięso surowe, przetworzone</a></li>
<li><a  class='dropdown-item' data-id='25' href='#'>Mięso przetworzone, pakowane</a></li>
<li><a  class='dropdown-item' data-id='26' href='#'>Mrożonki mięso</a></li>
<li><a  class='dropdown-item' data-id='43' href='#'>Kiełbasy</a></li>
<li><a  class='dropdown-item' data-id='64' href='#'>Konserwy mięsne</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='29' href='#'>Oleje, ocet</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='71' href='#'>Oleje</a></li>
<li><a  class='dropdown-item' data-id='72' href='#'>Ocet</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='22' href='#'>Przyprawy, Sosy, Grzyby</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='65' href='#'>Sosy</a></li>
<li><a  class='dropdown-item' data-id='67' href='#'>Grzyby</a></li>
<li><a  class='dropdown-item' data-id='68' href='#'>Przyprawy</a></li>
<li><a  class='dropdown-item' data-id='98' href='#'>Zupy</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='31' href='#'>Przetwory w słoikach, Puszki, Paszetety, kartony</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='73' href='#'>Słoiki</a></li>
<li><a  class='dropdown-item' data-id='74' href='#'>Kartony</a></li>
<li><a  class='dropdown-item' data-id='75' href='#'>Puszki</a></li>
<li><a  class='dropdown-item' data-id='76' href='#'>Pasztety</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='32' href='#'>Kawa, Herbata</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='115' href='#'>Kawa</a></li>
<li><a  class='dropdown-item' data-id='116' href='#'>Herbata</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='33' href='#'>Słodkości</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='82' href='#'>Czekolady</a></li>
<li><a  class='dropdown-item' data-id='83' href='#'>Cukierki</a></li>
<li><a  class='dropdown-item' data-id='84' href='#'>Ciastka</a></li>
<li><a  class='dropdown-item' data-id='85' href='#'>Wafelki</a></li>
<li><a  class='dropdown-item' data-id='86' href='#'>Batony</a></li>
<li><a  class='dropdown-item' data-id='87' href='#'>Galarteki i żelki</a></li>
<li><a  class='dropdown-item' data-id='88' href='#'>Gumy do żucia</a></li>
<li><a  class='dropdown-item' data-id='89' href='#'>Lody</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='34' href='#'>Napoje i soki</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='90' href='#'>Soki owocowe</a></li>
<ul class="k2">
<li><a  class='dropdown-item' data-id='92' href='#'>Soki bezpośrednio tłoczone</a></li>
<li><a  class='dropdown-item' data-id='93' href='#'>Jednodniowe</a></li>
<li><a  class='dropdown-item' data-id='88' href='#'>Soki z koncentratu</a></li>
<li><a  class='dropdown-item' data-id='89' href='#'>SMOOTHE</a></li>
</ul>
<li><a  class='dropdown-item' data-id='83' href='#'>Soki warzywne</a></li>
<li><a  class='dropdown-item' data-id='84' href='#'>Woda mineralna</a></li>
<li><a  class='dropdown-item' data-id='85' href='#'>Izotoniki</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='77' href='#'>Garmażerka, Pasty, Pizza, Zapiekanki</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='78' href='#'>Zapiekanki, pizza</a></li>
<li><a  class='dropdown-item' data-id='79' href='#'>Zupy</a></li>
<li><a  class='dropdown-item' data-id='80' href='#'>Wyroby mączne</a></li>
<li><a  class='dropdown-item' data-id='81' href='#'>Sałatki, surówki, pasty</a></li>
<li><a  class='dropdown-item' data-id='99' href='#'>Pozostałe</a></li>
</ul>
</li>


<li><a  class='dropdown-item' data-id='101' href='#'>Dziecięce</a>
<ul class="k2">
<li><a  class='dropdown-item' data-id='102' href='#'>Mleko</a></li>
<li><a  class='dropdown-item' data-id='103' href='#'>Owocowo/warzywne musy</a></li>
<li><a  class='dropdown-item' data-id='104' href='#'>Kaszki</a></li>
<li><a  class='dropdown-item' data-id='105' href='#'>Obiadki</a></li>
<li><a  class='dropdown-item' data-id='106' href='#'>Desery</a></li>
<li><a  class='dropdown-item' data-id='107' href='#'>Chusteczki</a></li>
<li><a  class='dropdown-item' data-id='108' href='#'>Szampony</a></li>
<li><a  class='dropdown-item' data-id='109' href='#'>Pileęgnacja</a></li>

</ul>
</li>
     


</ul>
</nav>





<h2>Wykonujemy zlecenia w najpopularniejszych marketach takich jak Biedronka, Netto, Lidl. Sprawadź czy istniejemy w Twojej okolicy.</h2>


</div>
<!---wrapper cf--> 
</header>









<div class="wrapper">


<?php if($dane)  
{ ?>
<div class="content">
<h4>Sklepy</h4>
<ul class="navabr navbar-left market">

<?php	foreach($dane as $name) { 
echo "<li class='actions position'>";
echo "<a href='#'  data-id='".$name->idmarket."' class='button active'>".$name->nazwa."</a>"; 
echo "</li>";
} ?>

</ul>
</div>
<!--//content-->
<?php } ?>










<div class="content">
<div id="przetwarzanie"></div>
<div class="py-sm-5">
<div id="paginationdiv"></div>
<div id="produkty"></div>
</div>
</div>
<!--//content-->

</div>
<!--//wrapper-->
