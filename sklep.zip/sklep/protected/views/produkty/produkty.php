<?php session_start();

if(!isset($_SESSION['cart'])){
    $_SESSION['cart']=array();
}


$action = isset ( $_GET ['action'] ) ? $_GET ['action'] : "";

echo "<div class='col-md-12'>";
if ($action == 'removed') {
	echo "<div class='alert alert-info'>";
	echo "Produkt usunięto z koszyka!";
	echo "</div>";
} 

else if ($action == 'quantity_updated') {
	echo "<div class='alert alert-info'>";
	echo "Produkt dodano do koszyka!";
	echo "</div>";
}
echo "</div>";

echo "<div class='col-md-12'>";
if ($action == 'added') {
	echo "<div class='alert alert-info'>";
	echo "Dodano do koszyka!";
	echo "</div>";
}

if ($action == 'exists') {
	echo "<div class='alert alert-info'>";
	echo "Już istnieje w koszyku potrawa!";
	echo "</div>";
}
echo "</div>";

?>						






<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>

<script type="text/javascript" src="//code.jquery.com/jquery-2.2.3.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.20/pdfmake.js"></script>


<!-- Hero Section Begin -->
<section class="hero">
        <div class="container">
			 <?php
			if($danex)
			{ ?>
			<div class="row">			
			<?php
			foreach($danex as $name)
			{
			?>  
                <div class="col-lg-3">
                    <div class="">
                       <a href="http:kontakt1.vot.pl/index.php?kod=<?php echo $kod ?>&idmarket=<?php echo $name->idmarket ?>"><?php echo $name->nazwa ?></a>
                    </div>
                 </div>
      		 <?php 
			} ?>
			
			</div>
			<?php } ?>
		
		
            <div class="row">
             	<?php
						if($danex) { ?>
							 
						<?php
			
						for($x=0; $x< count($kategoriex["records"]); $x++)
						{ ?>
						
						<div  class="col-lg-3">
						<a href="http:kontakt1.vot.pl/index.php/Produkty/ListaProduktow2/kod/<?php echo $kod ?>/idkategoria/<?php echo $kategoriex["records"][$x]["id"] ?>/page/1/idmarket/<?php echo $idmarket ?>/idpodkategoria1//" > <?php echo $kategoriex["records"][$x]["nazwa"] ?>  </a> 
						</div>
						<?php } ?>
					
						<?php } ?>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->
		
			
	
	
<!-- Featured Section Begin -->
    <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                                          
						<?php
						if($danex) { ?>
							 
						<?php
			
						for($x=0; $x< count($kategorie2x["records"]); $x++)
						{ ?>
						
						<div  class="col-lg-3">
						<a href="http:kontakt1.vot.pl/index.php/Produkty/ListaProduktow2/kod/<?php echo $kod ?>/idkategoria/<?php echo $kategorie2x["records"][$x]["id"] ?>/page/1/idmarket/<?php echo $idmarket ?>/idpodkategoria1//" > <?php echo $kategorie2x["records"][$x]["nazwa"] ?>  </a> 
						</div>
						<?php } ?>
					
						<?php } ?>
                   
                </div>
            </div>
			<?php
			if($products) {

			?>
		
		    <div class="row">		 
			<?php
			
			for($x=0; $x<count($products["records"]); $x++)
			{ ?>
				<div class='col-lg-3 col-md-4 col-sm-6 mix vegetables fresh-meat'>  <div class='product-id' style='display:none;'><?php echo $products['records'][$x]['id'] ?></div>
                    <div class='featured__item  product-id='a1'>
                        <div class='featured__item__pic set-bg' data-setbg='<?php echo $products['records'][$x]['img'] ?>'>
                            <ul class='dodajdokoszyka featured__item__pic__hover'>
                                <li><a href='#'><i class='fa fa-heart'></i></a></li>
                                <li><a href='#'><i class='fa fa-retweet'></i></a></li>
                               
								 <?php
								 if(array_key_exists($id, $_SESSION['cart'])){
									echo "<li><a href='cart.php' class=' btn btn-success w-100-pct'>";
									echo "<i class='fa fa-shopping-cart'></i>";
									echo "</a></li>";
									}
									else{
									echo "<li><a href='#' data-id='".$products['records'][$x]['id']."' data-quantity='".$products['records'][$x]['quantity']."' class='add_to_cart btn btn-primary w-100-pct'><i class='fa fa-shopping-cart'></i></a></li>";
									}
								?>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#"><?php echo $products["records"][$x]["nazwa"] ?></a></h6>
                            <h5>$30.00</h5>
                        </div>
                    </div>
                </div> 
		  	<?php } ?>
			</div>
			
			
			<?php 
			} ?>

    
        </div>
    </section>
    <!-- Featured Section End -->	


<script>


$(document).ready(function(){
  
function pokazKoszyk(json_url)
{

			$.getJSON(json_url, function(data){
			
			if(data.dane[0] === "")
			{
				read_products_html="<div class='clearfix'>Brak produktów w koszyku</div>";
			} 
			else {	
				var total ="";
				read_products_html="<div class='panel-body clearfix'>";
				
				$.each(data.dane[0].records, function(keyx, valx) {
					
				read_products_html+="<div class='row'>";
				read_products_html+="<div class='pull-left'>"+valx.nazwa+"  "+valx.rozmiar+"  "+valx.jednostka+"  "+valx.cena+"  "+valx.waluta+"</div>";
				read_products_html+="<div class='pull-right'> Razem: "+valx.subcena+"  "+valx.waluta+"</div>";
				read_products_html+="</div>";

				read_products_html+="<div class='row'>";
				read_products_html+="<div class='produkt' class='col-lg-8' style='margin-top:-0.5em;'>";
				read_products_html+="<div class='product-id' style='display:none;'>"+valx.id+"</div>";
				read_products_html+="<div style='margin-top:8px' class='input-group  usun'>";
				read_products_html+="<a href='#' data-id='"+valx.id+"' class='btn btn-default'> Usuń</a>";	
				read_products_html+="</div>";	
					
				read_products_html+="<div class='input-group' >";
                        	read_products_html+="<input type='number' name='quantity' value='"+valx.ilosc+"' class='form-control col-lg-3 cart-quantity' min='1' />";
				read_products_html+="</div>";
						
				read_products_html+="</div>";	
				read_products_html+="</div>";
				
				total = Math.round(valx.subcena + total);
				});				
				
				read_products_html+="</div>";
			}
	
	
			read_products_html+="<div class='cart-row'>";
            read_products_html+="<h4 class='m-b-10px'>Razem kwota: "+ total +" PLN</h4>";
            read_products_html+="<a href='checkout.php' class='btn btn-success m-b-10px'>";
            read_products_html+="<span class='glyphicon glyphicon-shopping-cart'></span> Przejdź do realiacji zakupów";
			read_products_html+="</a>";
			read_products_html+="</div>";
		
								
			$('.bootbox-body').html(read_products_html);
		
		});
	
}		

  
 $(document).on('click', '.dodajdokoszyka li', function(){

		var id=$(this).find('a').attr('data-id');
		var kod ="76-200";
		var quantity = $(this).find('a').attr('data-quantity');
       		var json_url = "http://kontakt1.vot.pl/index.php/produkty/AddToCart/id/"+id+"/quantity/"+quantity;	

		$.getJSON(json_url, function(data){
			
		});
		return false;
	});
  
 
  $(document).on('click', '.koszyk li', function(){
	
		var dialog = bootbox.dialog({
		title: '<div class="page-header"><h4 id="page-title">Koszyk na zakupy </h4></div>',
		message: '<p><i class="fa fa-spin fa-spinner"></i> Przetwarzanie...</p>'
		});
				
		dialog.init(function(){
		setTimeout(function(){
		dialog.find('.bootbox-body').html();
		}, 100);
		});

       		var json_url = "http://kontakt1.vot.pl/index.php/produkty/DispalyCart";
		pokazKoszyk(json_url);
	});

 $(document).on('click', '.usun', function(){
		
		var id=$(this).find('a').attr('data-id');
		var json_url = "http://kontakt1.vot.pl/index.php/produkty/RemoveFromCart/id/"+id;

		$.getJSON(json_url, function(data){
		var json_url2 = "http://kontakt1.vot.pl/index.php/produkty/DispalyCart";
		pokazKoszyk(json_url2);

		});
		return false;
	});


 $(document).on('click', '.produkt', function(){

		var id = $(this).find('.product-id').text();
    		var quantity = $(this).find('.cart-quantity').val();
		var json_url = "http://kontakt1.vot.pl/index.php/produkty/UpdateCart/id/"+id+"/quantity/"+quantity;

   		$.getJSON(json_url, function(data){
		var json_url2 = "http://kontakt1.vot.pl/index.php/produkty/DispalyCart";
		pokazKoszyk(json_url2);

		});
		return false;
	});

});

</script>

