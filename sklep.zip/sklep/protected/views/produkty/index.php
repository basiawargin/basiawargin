<script type="text/javascript" src="//code.jquery.com/jquery-2.2.3.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.20/pdfmake.js"></script>

<script src="<?php echo Yii::app()->request->baseUrl; ?>/css/app/app.js"></script>



	
<div class="container">
    <div class="row justify-content-left">
        <div class="col-md-12 col-md-offset-4">
	    <h3 class="h3 mb-3 font-weight-normal">Produkty</h3>

		<div class="czolowka"></div>
		<div class="panel">
		   <div class="paginationblok"></div>
		   <div class="lista"></div>
	        </div>

	</div>
    </div>
</div>

<script src="<?php echo Yii::app()->request->baseUrl; ?>/css/app/produkty/read-products.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/css/app/produkty/create1-product.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/css/app/produkty/update1-product.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/css/app/produkty/update2-product.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/css/app/produkty/delete1-product.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/css/app/produkty/search-product.js"></script>


 


<div class="modal fade" id="view-plus1" tabindex="-1" role="dialog" aria-labelledby="view-plus1" aria-hidden="true">
<div class="agilemodal-dialog modal-dialog" role="document">
<div class="modal-content">
<div class='modal-header'>
<h5 class='modal-title'> Dodanie produktu</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class='modal-body pt-3 pb-5 px-sm-5' id='tresc1'>
</div> 
</div>
</div>
</div>

<div class="modal fade" id="view-search" tabindex="-1" role="dialog" aria-labelledby="view-search" aria-hidden="true">
<div class="agilemodal-dialog modal-dialog" role="document">
<div class="modal-content">
<div class='modal-header'>
<h5 class='modal-title'> Wyszukaj produkt</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class='modal-body pt-3 pb-5 px-sm-5' id='tresc2'>
</div> 
</div>
</div>
</div>






<div class="modal fade" id="view-update1" tabindex="-1" role="dialog" aria-labelledby="view-update1" aria-hidden="true">
<div class="agilemodal-dialog modal-dialog" role="document">
<div class="modal-content">
<div class='modal-header'>
<h5 class='modal-title'> Zmiana danych</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class='modal-body pt-3 pb-5 px-sm-5' id='tresc3'>
</div> 
</div>
</div>
</div>

<div class="modal fade" id="view-update2" tabindex="-1" role="dialog" aria-labelledby="view-update2" aria-hidden="true">
<div class="agilemodal-dialog modal-dialog" role="document">
<div class="modal-content">
<div class='modal-header'>
<h5 class='modal-title'> Dostępne ilości i ceny</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class='modal-body pt-3 pb-5 px-sm-5' id='tresc4'>
</div> 
</div>
</div>
</div>

<div class="modal fade" id="view-fileform" tabindex="-1" role="dialog" aria-labelledby="view-fileform" aria-hidden="true">
<div class="agilemodal-dialog modal-dialog" role="document">
<div class="modal-content">
<div class='modal-header'>
<h5 class='modal-title'> Zdjęcie</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class='modal-body pt-3 pb-5 px-sm-5' id='tresc5'>
</div> 
</div>
</div>
</div>

<div class="modal fade" id="view-plus2" tabindex="-1" role="dialog" aria-labelledby="view-plus2" aria-hidden="true">
<div class="agilemodal-dialog modal-dialog" role="document">
<div class="modal-content">
<div class='modal-header'>
<h5 class='modal-title'> Dodanie nowego rozmiaru</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class='modal-body pt-3 pb-5 px-sm-5' id='tresc6'>
</div> 
</div>
</div>
</div>








<div class="modal fade" id="view-update3" tabindex="-1" role="dialog" aria-labelledby="view-update3" aria-hidden="true">
<div class="agilemodal-dialog modal-dialog" role="document">
<div class="modal-content">
<div class='modal-header'>
<h5 class='modal-title'> Zmiana danych</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class='modal-body pt-3 pb-5 px-sm-5' id='tresc7'>
</div> 
</div>
</div>
</div>







