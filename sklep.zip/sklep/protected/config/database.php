<?php


return array (
		'class' => 'CDbConnection',
		'connectionString' => 'mysql:host=localhost;dbname=kontakt1_sklep',
		'username' => 'kontakt1_sklep',
		'password' => 'Czm3a4Zxum@',
		'charset' => 'utf8',
		'emulatePrepare' => true 
);