<?php

return array (
		'basePath' => dirname ( __FILE__ ) . DIRECTORY_SEPARATOR . '..',
		'name' => 'kontakt1.vot.pl',
		'preload' => array (
				'log'
		),
		'params' => array (
				// this is used in contact page
				'adminEmail' => 'gosiawator3@gmail.com',
				'url' => 'kontakt1.vot.pl',
				'nazwafirmy'=>'OWP OKO Małgorzata Wątor'
		),
		'import' => array (
				'application.models.*',
				'application.components.*',
				'application.modules.user.models.*',
				'application.modules.user.components.*',
				'application.extensions.yush.*',
				'application.components.YushComponent',
				'application.components.YushComponent2',
				'application.components.YushComponent3',
				'application.extensions.CaptchaExtended.*',	
				'application.components.CaptchaExtended.*',
		),
		'modules' => array (
				'strony',
				'user' => array (
						'tableUsers' => 'users',
						'tableProfiles' => 'profiles',
						'tableProfileFields' => 'profiles_fields'
				),
				'gii' => array (
						'class' => 'system.gii.GiiModule',
						'password' => 'a12345678',
						'ipFilters' => array (
								'127.0.0.1',
								'::1'
						)
				),
				
				
		),
		'components' => array (
				'user' => array (
						'allowAutoLogin' => true,
						'loginUrl' => array (
								'/user/login'
						)
				),
				
				'db' => array (

						'class' => 'CDbConnection',
						'connectionString' => 'mysql:host=localhost;dbname=kontakt1_sklep',
						'username' => 'kontakt1_sklep',
						'password' => 'Czm3a4Zxum@',
						'charset' => 'utf8',
						'emulatePrepare' => true
				),
				'phpThumb' => array (
						'class' => 'ext.EPhpThumb.EPhpThumb' 
				),
				'yush' => array (
						'class' => 'application.components.YushComponent',
						
						'lowercase' => true,
						'template' => array (
								'ModelName' => array (
										'small' => '{year}{month}{model}{modelId}',
										'thumb' => '{year}{month}{model}{modelId}',
										'original' => '{year}{month}{model}{modelId}' 
								) 
						) 
				),
				
				'yush2' => array (
						'class' => 'application.components.YushComponent2',
						
						'lowercase' => true,
						'template' => array (
								'ModelName' => array (
										'small' => '{year}{month}{model}{modelId}',
										'thumb' => '{year}{month}{model}{modelId}',
										'original' => '{year}{month}{model}{modelId}' 
								) 
						) 
				),
				'yush3' => array (
						'class' => 'application.components.YushComponent3',
						
						'lowercase' => true,
						'template' => array (
								'ModelName' => array (
										'small' => '{year}{month}{model}{modelId}',
										'thumb' => '{year}{month}{model}{modelId}',
										'original' => '{year}{month}{model}{modelId}' 
								) 
						) 
				),
				'urlManager' => array (
						'urlFormat' => 'path',
						'rules' => array (
								'<controller:\w+>/<id:\d+>' => '<controller>/view',
								'<controller:\w+>/<action:\w+>/<id:\d+>' => '<controller>/<action>',
								'<controller:\w+>/<action:\w+>' => '<controller>/<action>'
						)
				),
			
		)
)
; // wymagane przez pewne instalacje MySQL




