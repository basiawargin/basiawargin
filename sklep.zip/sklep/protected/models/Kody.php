<?php

class Kody extends CActiveRecord {
	
	public function tableName() {
		return 'kody';
	}
	
	
	public function rules() {
		
		return array (
				array (
						'id, kod',
						'required' 
				)
				);
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID',
				
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}
	
	
	
}