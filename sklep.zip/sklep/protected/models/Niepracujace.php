<?php

class Niepracujace extends CActiveRecord
{
	
	public function tableName()
	{
		return 'niepracujace';
	}

	public function rules()
	{
		
		return array(
			array('id_sklep, datawpr, dzien', 'required'),
			
		);
	}



	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
		);
	}

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
