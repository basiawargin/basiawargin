<?php

class Ceny extends CActiveRecord {
	
	public function tableName() {
		return 'ceny';
	}
	
	
	public function rules() {
		
		return array (array ('id, idprodukt, idrozmiar, cena,datawpr,upust, waluta, vat','required'));
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID',
				'cena' => 'Cena'
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}
	
	
	
}