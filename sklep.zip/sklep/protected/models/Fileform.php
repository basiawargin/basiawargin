<?php
class Fileform extends CActiveRecord {
	public $images;
	public $image;
	public $name;
	public $image_name;
	public $attributes;
	public $katalog;
	public $file;

	
	public $baseDirectory;
	public function rules() {
		return array (
				array (
						'image',
						'file',
						'types' => 'jpg, jpeg, gif, png, exe, mov, mp4, txt, doc, pdf, xls, 3gp, php, ini, avi, rar, zip',
						'safe' => false 
				) 
		);
	}
	public function attributeLabels() {
		return array (
				'image' => 'Verificatio' 
		);
	}
}