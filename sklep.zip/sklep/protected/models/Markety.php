<?php

class Markety extends CActiveRecord {
	
	public function tableName() {
		return 'markety';
	}
	
	
	public function rules() {
		
		return array(array('id, nazwa, datawpr ','required' ));
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID',
				'nazwa' => 'Nazwa marketu'
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}
	
	
	
}