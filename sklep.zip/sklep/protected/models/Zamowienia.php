<?php

class Zamowienia  extends CActiveRecord {
	
	public function tableName() {
		return 'zamowienia';
	}
	
	
	public function rules() {
		
		return array (
				array (
						'id, iduser, datawpr,produkty, imie, nazwisko,adres, idkod, miasto, cena, upust, datadostawy, telefon',
						'required' 
				)
				);
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID',
				
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}
	
	
	
}