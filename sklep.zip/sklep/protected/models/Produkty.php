<?php

class Produkty extends CActiveRecord {
	
	public function tableName() {
		return 'produkty';
	}
	
	
	public function rules() {
		
		return array (
				array (
						'id, nazwa, kategoria, datawpr',
						'required' 
				)
		);
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID',
				'nazwa' => 'Nazwa produktu'
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}


}