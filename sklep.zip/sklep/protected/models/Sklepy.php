<?php

class Sklepy extends CActiveRecord {
	
	public function tableName() {
		return 'sklepy';
	}
	
	
	public function rules() {
		
		return array (
				array (
						'id, iduser, nazwa, is_actual, datawpr, kod ',
						'required' 
				),
				);
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID',
				'nazwa' => 'Nazwa firmy'
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}
	
	
	
}