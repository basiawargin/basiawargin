<?php

class Rozmiary  extends CActiveRecord {
	
	public function tableName() {
		return 'rozmiary';
	}
	
	
	public function rules() {
		
		return array (
				array (
						'id, idprodukt,rozmiar,jednostka,datawpr',
						'required' 
				)
				);
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID'
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}
	
	
	
}