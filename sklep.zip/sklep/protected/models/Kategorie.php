<?php

class Kategorie extends CActiveRecord {
	
	public function tableName() {
		return 'kategorie';
	}
	
	
	public function rules() {
		
		return array (
				array (
						'nazwa, katalog, datawpr',
						'required' 
				),
				array (
						'nazwa',
						'length',
						'max' => 250 
				)
				
				
		);
	}
	
	
	public function attributeLabels() {
		return array (
				'id' => 'ID',
				'nazwa' => 'Nazwa kategorii'
				
		);
	}
	
	
	public static function model($className = __CLASS__) {
		return parent::model ( $className );
	}
	
	
	
}
