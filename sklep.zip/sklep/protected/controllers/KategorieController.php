<?php
class KategorieController extends Controller {
	
	public $layout = '//layouts/column2';
	
	
	public function filters() {
		return array (
				'accessControl', 
				'postOnly + delete' 
		); 
	}
	
	
	public function accessRules() {
		return array (
				array (
						'allow', 
						'actions' => array (
								'index',
						),
						'users' => array (
								'*' 
						) 
				),
				
		);
	}
	
	
		
		public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 	
		$this->render ( 'index');
	}
	


	public function actionListaKategorii()
	{
				
		$products = array();
		$products['records'] = array();

		$products2 = array();
		$products2['records'] = array();
		
			
		
		$criteria = new CDbCriteria ();	
		$criteria->condition = ' kateglowna IS NULL';	
		$dane = Kategorie::model ()->findAll ( $criteria );
				
		foreach($dane as $name)
		{	
			$plik = 'uploads/' . $name->katalog. '/fileform/';			
			if (file_exists ( $plik )) {
			
			
					$data2 = CFileHelper::findFiles ( $plik );
					$y = str_replace ( '\\', '/', $data2 [3] );
					$img = Yii::app ()->request->baseUrl . '/' . $y;
							
			} else {
								
					$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					$img = '<img src="'.$x2.'" />';
			}
			//
		
			$dane2 = Kategorie::model()->findAllByAttributes(array('kateglowna'=>$name->id));	
				
			
			foreach($dane2 as $name2)
			{
				$plik = 'uploads/' . $name2['katalog']. '/fileform/';			
				if (file_exists ( $plik )) {
			
			
					$data2 = CFileHelper::findFiles ( $plik );
					$y = str_replace ( '\\', '/', $data2 [1] );
					$img2 = Yii::app ()->request->baseUrl . '/' . $y;
							
				} else {
								
					$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					$img2 = '<img src="'.$x2.'" />';
				}

				
				
				$tab2 = array("id"=>$name2['id'],"nazwa"=>$name2['nazwa'],"katalog"=>$name2['katalog'],'img'=>$img2);	
				array_push($products2["records"], $tab2);	

			}		
					
		$tab = array("id"=>$name['id'],"nazwa"=>$name['nazwa'],"katalog"=>$name['katalog'],'podkategorie'=>$products2,'img'=>$img);
		array_push($products['records'], $tab);
		
		$products2 = array();
		$products2['records'] = array();	
		}


		$data['dane'] =array($products);
		echo json_encode($data);
	
	}
	
	public function actionListaKategoriiId()
	{
				
		$id=$_GET['id'];
		$name = Kategorie::model ()->findByPk($id);
		$products = array();
		$products['records'] = array();
			
		$plik = 'uploads/' . $name->katalog. '/fileform/';			
		if (file_exists ( $plik )) {
			
			
					$data2 = CFileHelper::findFiles ( $plik );
					$y = str_replace ( '\\', '/', $data2 [1] );
					$img = Yii::app ()->request->baseUrl . '/' . $y;
							
		} else {
								
					$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					$img = '<img src="'.$x2.'" />';
		}
		//
		
		$dane2 = Kategorie::model()->findAllByAttributes(array('kateglowna'=>$id));	
		$products2 = array();
		$products2['records'] = array();
		
		if(count($dane2) >0)
		{			
		
		foreach($dane2 as $name2)
		{
			$plik = 'uploads/' . $name2['katalog']. '/fileform/';			
			if (file_exists ( $plik )) {
			
			
					$data2 = CFileHelper::findFiles ( $plik );
					$y = str_replace ( '\\', '/', $data2 [1] );
					$img = Yii::app ()->request->baseUrl . '/' . $y;
							
			} else {
								
					$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					$img = '<img src="'.$x2.'" />';
			}

			$dane3 = Kategorie::model()->findAllByAttributes(array('kateglowna'=>$name2['id']));	
			$products3 = array();
			$products3['records'] = array();
			foreach($dane3 as $name3)
			{
				$plik3 = 'uploads/' . $name3['katalog']. '/fileform/';			
				if (file_exists ( $plik3 )) {
			
			
					$data3 = CFileHelper::findFiles ( $plik3 );
					$y3 = str_replace ( '\\', '/', $data3 [1] );
					$img3 = Yii::app ()->request->baseUrl . '/' . $y3;
							
				} else {
								
					$x3 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					$img3 = '<img src="'.$x3.'" />';
				}
				
				$tab3 = array("id"=>$name3['id'],"nazwa"=>$name3['nazwa'],"katalog"=>$name3['katalog'],'img'=>$img3);	
				array_push($products3["records"], $tab3);	
			}	

			$tab2 = array("id"=>$name2['id'],"nazwa"=>$name2['nazwa'],"katalog"=>$name2['katalog'],'podkategorie'=>$products3,'img'=>$img);	
			array_push($products2["records"], $tab2);	

		}
		
		} else {  $tab2 = array(); array_push($products2["records"], $tab2);}


			
		$tab = array("id"=>$name->id,"nazwa"=>$name->nazwa,"katalog"=>$name->katalog,"kateglowna"=>$name->kateglowna,'podkategorie'=>$products2,'img'=>$img);
		array_push($products['records'], $tab);
		
		$data['dane'] =array($products);
		echo json_encode($data);
	
	}

	public function actionDodajKategorie()
	{
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);

		$nazwa = $tablica["nazwa"];		
		$connection = Yii::app ()->db;
		$datawpr=strtotime(date('Y-m-d H:i:s'));
		$sql = "INSERT INTO kategorie (nazwa, datawpr ) VALUES (:nazwa,:datawpr)";
				$command = $connection->createCommand ( $sql );
				$command->bindParam ( ":nazwa", $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":datawpr", $datawpr, PDO::PARAM_INT );
				$command->execute ();
		
				$sql2="SELECT * FROM kategorie ORDER BY id DESC";
				$command2 = $connection->createCommand ($sql2);	
				$command2->execute ();
				$d= $command2->query();
				$tab= array();
				foreach($d as $key)
				{
				$tab[]=$key['id'];
				}
				$id=$tab[0];
			
				$katalog ='kat'.$id;
				$sql3 = "UPDATE kategorie SET katalog =:katalog WHERE id=:id";
				$command3 = $connection->createCommand ($sql3);
				$command3->bindParam ( ":katalog" , $katalog, PDO::PARAM_STR );
				$command3->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command3->execute ();
				
				$transaction->commit();	
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}
		$data['dane'] =array(1);
		echo json_encode($data);		
	
				
	}	
	
	public function actionUsunKategorie() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_GET['id'];
		$sql = "DELETE  FROM kategorie WHERE id=:id or kateglowna = :id ";
		$command = $connection->createCommand ( $sql );
		$command->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command->execute ();
		
		
		$sql2 = "SELECT * FROM produkty WHERE kategoria=:id or podkategoria1 = :id or podkategoria2 = :id";
		$command2 = $connection->createCommand ( $sql2 );
		$command2->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command2->execute ();
		$dane= $command2->query();
		
		foreach($dane as $name)
		{
		
		$sql3 = "DELETE  FROM rozmiary WHERE idproduktu=:id ";
		$command3 = $connection->createCommand ( $sql3 );
		$command3->bindParam ( ":id", $name['id'], PDO::PARAM_INT );
		$command3->execute ();	

		$sql4 = "DELETE  FROM ceny WHERE idproduktu=:id ";
		$command4 = $connection->createCommand ( $sql4 );
		$command4->bindParam ( ":id", $name['id'], PDO::PARAM_INT );
		$command4->execute ();		
			
		}
		$sql22 = "DELETE  FROM produkty WHERE kategoria = :id or podkategoria1 = :id or podkategoria2 = :id ";
		$command22 = $connection->createCommand ( $sql22 );
		$command22->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command22->execute ();	

		
				
				
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}	
		$data['dane'] =array(1);
		echo json_encode($data);
	}
	
		
		
	
	public function actionZmienKategorie() {
		
				
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {		
				
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		$id = $tablica["id"];
		$nazwa = $tablica["nazwa"];
			
		$sql = "UPDATE kategorie SET nazwa=:nazwa WHERE id=:id";
				$command = $connection->createCommand ( $sql );
				$command->bindParam ( ":id", $id, PDO::PARAM_INT );
				$command->bindParam ( ":nazwa", $nazwa, PDO::PARAM_STR );
				$command->execute ();			
				$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}			
				
		$data['dane'] =array(1);
		echo json_encode($data);
		
	}
	
	
	
	public function actionDodajPodkategorie()
	{
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);

		$nazwa = $tablica["nazwa"];	
		$kateglowna = $tablica["kateglowna"];	
		$connection = Yii::app ()->db;
		$datawpr=strtotime(date('Y-m-d H:i:s'));
		$sql = "INSERT INTO kategorie (nazwa, datawpr, kateglowna ) VALUES (:nazwa,:datawpr,:kateglowna)";
				$command = $connection->createCommand ( $sql );
				$command->bindParam ( ":nazwa", $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":datawpr", $datawpr, PDO::PARAM_INT );
				$command->bindParam ( ":kateglowna", $kateglowna, PDO::PARAM_INT );
				$command->execute ();
					
				$transaction->commit();	
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}
		$data['dane'] =array(1);
		echo json_encode($data);		
	
				
	}	
	
	
	public function actionZmienPodkategorie() {
		
				
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {		
				
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		$id = $tablica["id"];
		$nazwa = $tablica["nazwa"];
		$kateglowna = $tablica["kateglowna"];
	
		$sql1 = "UPDATE kategorie SET nazwa=:nazwa, kateglowna=:kateglowna WHERE id=:id";
				$command = $connection->createCommand ( $sql1 );
				$command->bindParam ( ":id", $id, PDO::PARAM_INT );
				$command->bindParam ( ":nazwa", $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":kateglowna", $kateglowna, PDO::PARAM_INT );
				$command->execute ();
				
			
				$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}			
				
		$data['dane'] =array(1);
		echo json_encode($data);
		
	}
	
	
	
	//fotografie
	
	
	
	public function actionDodajZdjecieKategoria() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_POST['id'];
		$foto = Kategorie::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		$documentroot = $_SERVER ['DOCUMENT_ROOT'];
		$username = '/uploads/' . $foto->katalog;
		$baseDirectory = 'uploads/' . $foto->katalog;
		
		if (file_exists ( $documentroot . "/" . $username )) {
		} else {
			mkdir ( $documentroot . "/" . $username, 0777 );
		}
		
		$model2 = new Fileform ();
		$model2->katalog = $msg;
		$model2->baseDirectory = 'uploads/' . $msg . '/';
		
		$model2->file = 'uploads/' . $msg . '/';
		$model2->images = 'd';	
		$model2->name ='d';
		$model2->attributes = 'd';


		$images = new CUploadedFile($_FILES['myfile']['name'], $_FILES['myfile']['tmp_name'], $_FILES['myfile']['type'], $_FILES['myfile']['size'], $_FILES['myfile']['error']);
      	$is = 'df';
		$model2->image = $images;
		
		
			if ($images) {
				// Clean up the filename
				$uglyName = strtolower ( $model2->name );
				$mediocreName = preg_replace ( '/[^a-zA-Z0-9]+/', '_', $uglyName );
				$beautifulName = trim ( $mediocreName, '_' ) . "." . $is;
				$model2->image_name = $beautifulName;
				$im = 'jpg';
				$newName = md5 ( microtime ( true ) ) . '_' . $model2->name . "." . $im;
			}
						
			if ($model2->save()){
		
				
				if ($images) {
					
					Yush::init ( $model2, $msg ); // this will build the nessesary structure
					                     
					// Nothing has been uploaded yet but YUSH will return a full path that can be used to save the resource
					$originalPath = Yush::getPath ( $model2, Yush::SIZE_ORIGINAL, $newName );
					$largePath = Yush::getPath ( $model2, Yush::SIZE_LARGE, $newName );
					$smallPath = Yush::getPath ( $model2, Yush::SIZE_SMALL, $newName );
					$thumbPath = Yush::getPath ( $model2, Yush::SIZE_THUMB, $newName );
					
					// Save the original resource to disk
					
					$images->saveAs ( $originalPath );
					
					// Create a large image
					$largeImage = Yii::app ()->phpThumb->create ( $originalPath );
					$largeImage->resize ( 700, 400 );
					$largeImage->save ( $largePath );
					
					$x2 = 'images/znak1.jpg';
					
					$x = $originalPath;
					$x3 = $largePath;
					$size2 = getimagesize ( $x );
					$skala = $size2 [0] / $size2 [1];
					
					$watermark = imagecreatefromjpeg ( $x2 );
					$watermark_width = imagesx ( $watermark );
					$watermark_height = imagesy ( $watermark );
					
					$size = getimagesize ( $x2 );
					
					if ($skala < 1) {
						$dest_x = $size [0] - $watermark_width + 90;
						$dest_y = $size [1] - $watermark_height + 170;
					} else {
						$dest_x = $size [0] - $watermark_width + 470;
						$dest_y = $size [1] - $watermark_height + 290;
					}
					
					$image = imagecreatefromjpeg ( $x );
					$image2 = imagecreatefromjpeg ( $x3 );
					imagecopymerge ( $image, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 25 );
					imagecopymerge ( $image2, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 25 );
					imagejpeg ( $image, $x );
					imagejpeg ( $image2, $x3 );
					
					imagedestroy ( $image );
					imagedestroy ( $image2 );
					imagedestroy ( $watermark );
					
					// Create a small image
					$smallImage = Yii::app ()->phpThumb->create ( $originalPath );
					$smallImage->resize ( 405, 220 );
					$smallImage->save ( $smallPath );
					
					// Create a thumbnail
					$thumbImage = Yii::app ()->phpThumb->create ( $originalPath );
					$thumbImage->resize ( 350, 200 );
					$thumbImage->save ( $thumbPath );
					
					$plik = 'uploads/' . $msg . '/fileform/';
					if (file_exists ( $plik )) {
					$data2 = CFileHelper::findFiles ( $plik );
					$liczba = count ( $data2 );
					$tab = array ();
					$numer = 1;
					for($x = 3; $x < $liczba;) {
					$y = str_replace ( '\\', '/', $data2 [$x] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
					$tab [] = $y;
					$x = $x + 4;
					$numer ++;
					
					}
					$str = implode(",",$tab);
	
					}
	
				$data_modyf = time();
				$sql1 = "Update kategorie  SET  datamodyf=:data_modyf ";
				$command = $connection->createCommand ( $sql1 );
				$command->bindParam ( ":data_modyf", $data_modyf, PDO::PARAM_INT );
				$command->execute ();
					
				}		
					
				}
				$transaction->commit();	
				
			}	
			catch(Exception $e)
			{
				$transaction->rollback();
			}
		$data =1;
		echo json_encode($data);
	}
	
	public function actionListaZdjecKategoria() {
				
			$id = $_POST['id'];
			$foto = Kategorie::model ()->findByPk($id);
			$plik = 'uploads/'.$foto->katalog .'/fileform/';
			$nazwa = $foto->nazwa;				
			$products=array();
			$products["records"]=array();
																
			if (file_exists ( $plik )) {
			
				$data2 = CFileHelper::findFiles ( $plik );
					$liczba = count ( $data2 );
					$tab = array ();
					$numer = 0;
					for($x = 1; $x < $liczba;) {
					$y = str_replace ( '\\', '/', $data2 [$x] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
					$tab [] = $x2;
					$x = $x + 4;
					$numer ++;
					}
				} else {
								
				$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
				$img = '<img src="'.$x2.'" />';
				$numer='x';
				}
			$product_item=array("numer" => $numer,"img" => $x2, "id"=>$id,"nazwa"=>$nazwa);
			array_push($products["records"], $product_item);
		
				
			$data["dane"]= array($products);	
			echo json_encode($data);
	}

	public function actionZdjecieKategoria()
	{
			
			$zdjeciex = $_GET['zdjecie'];
			$tab = explode("-",$zdjeciex);
		
			$zdjecie1 = $tab[2];
			$id = $tab[1];
	
			$zdjecie2 = str_replace("x","/",$zdjecie1);
			$zdjecie3 = str_replace("xx","//",$zdjecie2);
			$zdjecie4 = str_replace("xxX","_",$zdjecie3);
			$zdjecie = str_replace("xxXX",".",$zdjecie4);
	
			$foto = Newsletters::model ()->findByPk ( $id );
			$msg = $foto->katalog;
		
			$x = str_replace ( '/uploads/' . $msg . '/fileform//', '', $zdjecie );
			$pozycja_konca = strpos ( $x, '/' );
			$numer_katalogu = substr ( $x, 0, $pozycja_konca );
			$katalog1 = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/';
																	
			if (file_exists ( $katalog1 )) {
			
			
				$data2 = CFileHelper::findFiles ( $katalog1 );
					$liczba = count ( $data2 );
					$tabx = array ();
					$numer = 0;
					for($x = 1; $x < $liczba;) {
					$y = str_replace ( '\\', '/', $data2[$x] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
					$tabx [] = $x2;
					$x = $x + 4;
					$numer ++;
								
					
					}
				} else {
								
				$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
				$img = '<img src="'.$x2.'" />';
				$product_item=array(
				"numer" => 'x',
				"img" => $x2,
				
				);
			
			}
			
		$this->render('zdjecie',array('zdjecie'=>$x2));
	}
	public function actionSprawdzenieLiczby()
	{
		
		$id = $_POST['id'];
		$foto = Kategorie::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		// Sprawdzenie czy jest już jedno zdjęcie
		if(file_exists('uploads/' . $foto->katalog.'/fileform/'))
		{	
		$plik = 'uploads/' . $foto->katalog . '/fileform/';											
		$data2 = CFileHelper::findFiles ( $plik );
		$liczba_zdjec = count($data2)/4+1;
						
		} else {$liczba_zdjec =1;}
		
		$data = array('liczba'=>$liczba_zdjec);
		echo json_encode($data);
	}
	
	
	public function actionUsunZdjecieKategoria() {
	
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
	
		$usun = $_POST['usun'];
		$tab = explode("-",$usun);
		
		$zdjecie1 = $tab[2];
		$id = $tab[1];
	
		$zdjecie2 = str_replace("x","/",$zdjecie1);
		$zdjecie3 = str_replace("xx","//",$zdjecie2);
		$zdjecie4 = str_replace("xxX","_",$zdjecie3);
		$zdjecie = str_replace("xxXX",".",$zdjecie4);
	
		$foto = Kategorie::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		$x = str_replace ( '/uploads/' . $msg . '/fileform//', '', $zdjecie );
		$pozycja_konca = strpos ( $x, '/' );
		$numer_katalogu = substr ( $x, 0, $pozycja_konca );
		$katalog_do_usuniecia = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/';
		$katalog_do_usuniecia1 = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/thumb/';
		$katalog_do_usuniecia2 = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/original/';
		$katalog_do_usuniecia3 = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/cropped/';
		$katalog_do_usuniecia4 = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/large/';
		$katalog_do_usuniecia5 = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/small/';
			
		$plik = 'uploads/' . $msg . '/fileform/' . $numer_katalogu . '/thumb';
		$plik2 = 'uploads/' . $msg . '/fileform/' . $numer_katalogu . '/original';
		$plik4 = 'uploads/' . $msg . '/fileform/' . $numer_katalogu . '/large';
		$plik5 = 'uploads/' . $msg . '/fileform/' . $numer_katalogu . '/small';
		$plik3 = 'uploads/' . $msg . '/fileform/' . $numer_katalogu . '/cropped';
				
					
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik2 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik2 . '/' . $dirFile );
					}
				}
		}		
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik4 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik4 . '/' . $dirFile );
					}
				}
		}
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik5 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik5 . '/' . $dirFile );
					}
				}
			}	

				$data_modyf = time();
				$sql1 = "Update kategorie  SET  data_modyf=:data_modyf ";
				$command = $connection->createCommand ( $sql1 );
				$command->bindParam ( ":data_modyf", $data_modyf, PDO::PARAM_INT );
				$command->execute ();
		
			$transaction->commit();	
				
			}	
			catch(Exception $e)
			{
				$transaction->rollback();
			}
						
		$data["dane"]= array(1);	
		echo json_encode($data);
		
	}

	
}
