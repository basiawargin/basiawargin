<?php
class MarketyController extends Controller {
	
	public $layout = '//layouts/column2';
	
	
	public function filters() {
		return array (
				'accessControl', 
				'postOnly + delete' 
		); 
	}
	
	
	public function accessRules() {
		return array (array ('allow', 'actions' => array ('index'),	'users' => array ('*')));
	}
	
	
		
		public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 	
		$this->render ( 'index');
	}
	


	
		public function actionListaMarketowDoSelect()
	{

		$markety = Markety::model ()->findAll ();
				
		$products1=array();
		$products1["records"]=array();
		
		foreach ( $markety as $name ) {
			
		$product_item=array("id" => $name['id'],"nazwa" => $name['nazwa']);
			array_push($products1["records"], $product_item);	
		
		}
					
		$data['dane'] =array($products1);
		echo json_encode($data);
	
	}
	
	
	public function actionDodajMarket()
	{
		
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);

		$nazwa = $tablica["nazwa"];
		$data_wprowadzenia = date('Y-m-d H:i:s'); $datawpr = strtotime($data_wprowadzenia);	
			
				
		$sql1 = "INSERT INTO markety (nazwa, datawpr) VALUES (:nazwa, :datawpr)";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":nazwa" , $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command->execute ();
					
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}	
					
	
		$data['dane'] =array(1);	
		echo json_encode($data);		
	
				
	}	
	
	public function actionUsunMarket() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_GET['id'];
		$sql = "DELETE  FROM markety WHERE id=:id";
		$command = $connection->createCommand ( $sql );
		$command->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command->execute ();
				
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}
		$data['dane'] =array(1);	
		echo json_encode($data);	
	}
	
		
	
	
	
	
	
}
