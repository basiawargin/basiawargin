<?php
class ProduktyController extends Controller {
	
	public $layout = '//layouts/column2';
	
	
	public function filters() {
		return array (
				'accessControl', 
				'postOnly + delete' 
		); 
	}
	
	
	public function accessRules() {
		return array (array ('allow', 'actions' => array ('index',"zdjecie"),	'users' => array ('*')));
	}
	
	
		
		public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 	
		$this->render ( 'index');
	}
	



		public function actionListaParametrow()
	{

		$markety = Markety::model ()->findAll ();
				
		$products1=array();
		$products1["records"]=array();
		
		foreach ( $markety as $name ) {
			
		$product_item=array("id" => $name['id'],"nazwa" => $name['nazwa']);
			array_push($products1["records"], $product_item);	
		
		}

		//
		//

		$products2 = array();
		$products2['records'] = array();
		
		$criteria = new CDbCriteria ();	
		$criteria->condition = ' kateglowna IS NULL';	
		$dane = Kategorie::model ()->findAll ( $criteria );
		
		
		foreach($dane as $name)
		{
									
		$plik = 'uploads/' . $name['katalog']. '/fileform/';
							
			
		if (file_exists ( $plik )) {
			
			
					$data2 = CFileHelper::findFiles ( $plik );
					$y = str_replace ( '\\', '/', $data2 [3] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
							
		} else {
								
					$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					$img = '<img src="'.$x2.'" />';
		}
			
		$tab = array("id"=>$name['id'],"nazwa"=>$name['nazwa'],'img'=>$img);
		array_push($products2['records'], $tab);
		
		}




					
		$data['dane'] =array($products1, $products2);
		echo json_encode($data);
	
	}



		public function actionListaProduktow()
	{
		
		if($_GET['idmarket'] ==''){ $market = ' id IS NOT NULL';} else { $market = ' idmarket ='.$_GET['idmarket']; }
		if($_GET['idkategoria'] ==''){ $idkategoria = ' and id IS NOT NULL';} else { $idkategoria = ' and kategoria ='.$_GET['idkategoria']; }
		if($_GET['idpodkategoria1'] ==''){ $idpodkategoria1 = ' and id IS NOT NULL';} else { $idpodkategoria1 = ' and  podkategoria1 ='.$_GET['idpodkategoria1']; }
		if($_GET['idpodkategoria2'] ==''){ $idpodkategoria2 = ' and id IS NOT NULL';} else { $idpodkategoria2 = ' and podkategoria2 ='.$_GET['idpodkategoria2']; }
		
		$page= $_GET['page'];
		$limit = 20;
		
		$criteria = new CDbCriteria ();
		$criteria->order = 'id DESC';
		$criteria->condition= $market.'  '.$idkategoria.' '.$idpodkategoria1.' '.$idpodkategoria2;	
		$produkty = Produkty::model ()->findAll ( $criteria );
		
		$liczba_wierszy = count($produkty);
		$strony = ceil($liczba_wierszy/$limit);
		if($liczba_wierszy !== 0)
		{
					if($page > $strony) {
					$page = $page-1;
					
				} else { $page = $page; $start = ($page - 1) * $limit;}
		}
		else {
					$page=1;
					$start=0;
		}
		
		$connection = Yii::app ()->db;	
		
		$sq2 = 'SELECT DISTINCT * FROM produkty  WHERE '.$market.'  '.$idkategoria.' '.$idpodkategoria1.' '.$idpodkategoria2.' ORDER BY id DESC  LIMIT :zacznij, :limit_na_strone';
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$produkty2=$command2->queryAll();
		
			
		
		$products1=array();
		$products1["records"]=array();
		foreach ( $produkty2 as $name ) {
		
		
		$kategoria = Kategorie::model ()->findByPk ( $name['kategoria'] );	
		$podkategoria1 = Kategorie::model ()->findByPk ( $name['podkategoria1'] );
		$market = Markety::model ()->findByPk ( $name['idmarket'] );	
		$product_item=array("id" => $name['id'],"nazwa" => $name['nazwa'],"market"=>$market->nazwa, "kategoria"=>$kategoria->nazwa, "podkategoria1"=> $podkategoria1->nazwa, "opis"=>$name['opis'],"producent"=>$name['producent'],"img" => $img);
		array_push($products1["records"], $product_item);
		}
			
		
		
		$products2=array();
		$products2["paging"]= array();
		$ab =array();	
		
		$url = Yii::app ()->params ['url'];

		for($xc=1; $xc<=$strony; $xc++)
		{
			if($xc == $page) {$z='yes';} else {$z = 'no';}
			$ab[] = array('page'=>$xc,'url'=>'http://'.$url.'/index.php/produkty/ListaProduktow/page/'.$xc.'/idmarket/'.$_GET['idmarket'].'/idkategoria/'.$_GET['idkategeoria'].'/idpodkategoria1/'.$_GET['idpodkategoria1'].'/idpodkategoria2/'.$_GET['idpodkategoria2'],'current_page'=>$z);
		}
		if($strony >4)
			{ $products2["paging"]= array('first'=>'http://'.$url.'/index.php/produkty/ListaProduktow/page/1/idmarket/'.$_GET['idmarket'].'/idkategoria/'.$_GET['idkategeoria'].'/idpodkategoria1/'.$_GET['idpodkategoria1'].'/idpodkategoria2/'.$_GET['idpodkategoria2'],
			'last'=>'http://'.$url.'/index.php/produkty/ListaProduktow/page/'.$strony.'/idmarket/'.$_GET['idmarket'].'/idkategoria/'.$_GET['idkategeoria'].'/idpodkategoria1/'.$_GET['idpodkategoria1'].'/idpodkategoria2/'.$_GET['idpodkategoria2']);	}
			else { $products2["paging"]= array('first'=>'', 'last'=>'');}
		
		
		
		
		$products2["paging"]["pages"]= $ab;	
		$products2["paging"]["liczba_rekordow"]= $liczba_wierszy;
		$products2["paging"]["page"]= $page;
			
			
			
		$data['dane'] =array($products1, $products2);
		echo json_encode($data);
	
	}
	
		public function actionListaProduktow2()
	{
		$kod = $_GET['kod'];
		$idmarket = $_GET['idmarket'];
		$idkategoria = $_GET['idkategoria'];
		$idpodkategoria1 = $_GET['idpodkategoria1'];
		$page = $_GET['page'];
				
		if(isset($_POST['szukaj']))
		{
		
		$kod = $_POST['kod'];	
		$dane = Sklepy::model()->findAllByAttributes(array("kod"=>$kod));
		
		header('Location: http://kontakt1.vot.pl/index.php?kod='.$kod);	
	
		}
		
		
		
		
		// ustalenie listy produktów
		//
		//
		$products1=array();
		$products1["records"]=array();
		
		$connection = Yii::app ()->db;	
		
		if($idmarket ==''){ $market = ' R.id IS NOT NULL';} else { $market = ' P.idmarket ='.$idmarket; }
		if($idkategoria ==''){ $idkategoriax = ' and R.id IS NOT NULL';} else { $idkategoriax = ' and P.kategoria ='.$idkategoria; }
		if($idpodkategoria1 ==''){ $idpodkategoria1x = ' and R.id IS NOT NULL';} else { $idpodkategoria1x = ' and  P.podkategoria1 ='.$idpodkategoria1; }
		
	

		$limit=10;
				
		$sq1 = 'SELECT DISTINCT R.id AS idrozmiarR, R.idprodukt, R.rozmiar AS rozmiarR, R.katalog  AS katalogR, R.jednostka AS jednostkaR, P.id, P.nazwa , P.kategoria, P.podkategoria1, P.opis, P.producent,P.idsklep, P.idmarket,P.datawpr, P.datamodyf,C.cena AS cena, C.vat AS vat, C.upust AS upust  FROM rozmiary AS R JOIN produkty AS P  ON P.id = R.idprodukt  JOIN ceny AS C ON C.idrozmiar = R.id  WHERE '.$market.' '.$idkategoriax.' '.$idpodkategoria1x;
		$command1 = $connection->createCommand($sq1);
		$command1->execute ();
		$produkty1=$command1->queryAll();
		
		
		$liczba_wierszy = count($produkty1);
		$strony = ceil($liczba_wierszy/$limit);
		if($liczba_wierszy !== 0)
		{
					if($page > $strony) {
					$page = $page-1;
					
				} else { $page = $page; $start = ($page - 1) * $limit;}
		}
		else {
					$page=1;
					$start=0;
		}
		
	
		
		$sq2 = 'SELECT DISTINCT P.id AS id, P.nazwa AS nazwa, P.kategoria as kategoria, P.podkategoria1 AS podkategoria1, P.opis AS opis, P.producent AS producent,P.idsklep, P.idmarket AS idmarket,P.datawpr, P.datamodyf,
		R.id AS idrozmiarR, R.idprodukt, R.rozmiar AS rozmiarR, R.katalog  AS katalogR, R.jednostka AS jednostkaR, C.cena AS cena, C.vat AS vatC, C.upust AS upustC  FROM rozmiary AS R JOIN produkty AS P  ON P.id = R.idprodukt JOIN ceny AS C ON C.idrozmiar = R.id WHERE '.$market.' '.$idkategoriax.' '.$idpodkategoria1x.' ORDER BY R.id DESC  LIMIT :zacznij, :limit_na_strone';
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$produkty2=$command2->queryAll();
		
		foreach ( $produkty2 as $name ) {
		
		
		$kategoria = Kategorie::model ()->findByPk ( $name['kategoria'] );	
		$podkategoria1 = Kategorie::model ()->findByPk ( $name['podkategoria1'] );
		$market = Markety::model ()->findByPk ( $name['idmarket'] );	
		
		$plik = 'uploads/' . $name['katalogR']. '/fileform/';
							
			
		if (file_exists ( $plik )) {
			
			
					$data2 = CFileHelper::findFiles ( $plik );
					$y = str_replace ( '\\', '/', $data2 [3] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
							
		} else {
								
					$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					
		}
		
		
		
		$product_item=array("id" => $name['idrozmiarR'],"rozmiar"=>$name['rozmiarR'], "jednostka"=>$name['jednostkaR'],"vat"=>$name['vatC'], "upust"=>$name["upustC"], "nazwa" => $name['nazwa'], "cena"=>$name['cena'], "market"=>$market->nazwa, "kategoria"=>$kategoria->nazwa, "podkategoria1"=> $podkategoria1->nazwa, "opis"=>$name['opis'],"producent"=>$name['producent'],"img" => $x2);
		array_push($products1["records"], $product_item);
		}
			
		

		
		
		$products2=array();
		$products2["paging"]= array();
		$ab =array();	
		
		$url = Yii::app ()->params ['url'];

		for($xc=1; $xc<=$strony; $xc++)
		{
			if($xc == $page) {$z='yes';} else {$z = 'no';}
			$ab[] = array('page'=>$xc,'url'=>'http://'.$url.'/index.php/produkty/ListaProduktow2/page/'.$xc.'/idmarket/'.$_GET['idmarket'].'/idkategoria/'.$_GET['idkategeoria'].'/idpodkategoria1/'.$_GET['idpodkategoria1'].'/idpodkategoria2/'.$_GET['idpodkategoria2'],'current_page'=>$z);
		}
		if($strony >4)
			{ $products2["paging"]= array('first'=>'http://'.$url.'/index.php/produkty/ListaProduktow2/page/1/idmarket/'.$_GET['idmarket'].'/idkategoria/'.$_GET['idkategeoria'].'/idpodkategoria1/'.$_GET['idpodkategoria1'].'/idpodkategoria2/'.$_GET['idpodkategoria2'],
			'last'=>'http://'.$url.'/index.php/produkty/ListaProduktow2/page/'.$strony.'/idmarket/'.$_GET['idmarket'].'/idkategoria/'.$_GET['idkategeoria'].'/idpodkategoria1/'.$_GET['idpodkategoria1'].'/idpodkategoria2/'.$_GET['idpodkategoria2']);	}
			else { $products2["paging"]= array('first'=>'', 'last'=>'');}
		
		
		
		
		$products2["paging"]["pages"]= $ab;	
		$products2["paging"]["liczba_rekordow"]= $liczba_wierszy;
		$products2["paging"]["page"]= $page;	
		
		
		// ustalenie listy kategorii, listy podkategorii
		
		$kategorie=array();
		$kategorie["records"]=array();
		
		$kategorie2=array();
		$kategorie2["records"]=array();
		
		if($kod !="")
		{
				
			if($idmarket != '')
			{
				
				$kategorie = array();
				$kategorie['records'] = array();
				$criteria = new CDbCriteria ();	
				$criteria->condition = ' kateglowna IS NULL';	
				$dane2 = Kategorie::model ()->findAll ( $criteria );
				
				foreach($dane2 as $name)
				{	
						
				$tab = array("id"=>$name['id'],"nazwa"=>$name['nazwa'],"katalog"=>$name['katalog']);
				array_push($kategorie['records'], $tab);
				
				}
			}
			
			if($idkategoria =="")
			{				}
			else {
					
					$criteria2 = new CDbCriteria ();	
					$criteria2->condition = ' kateglowna = '.$idkategoria;	
					$dane3 = Kategorie::model ()->findAll ( $criteria2 );
				
					foreach($dane3 as $name)
					{	
						
					$tab2 = array("id"=>$name['id'],"nazwa"=>$name['nazwa'],"kateglowna"=>$name['kateglowna']);
					array_push($kategorie2['records'], $tab2);
				
					}
			}
			
		}
		
		
		

		
		
		
			
			$data['dane'] =array($products1, $products2, $kategorie, $kategorie2);
		echo json_encode($data);
	
	}
	
	
	
	
	
	public function actionDodajProdukt()
	{

		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);

		$idmarket = $tablica["idmarket"];
		$nazwa = $tablica["nazwa"];
		$producent = $tablica["producent"];
		$opis = $tablica["opis"];
		$idkategoria = $tablica["idkategoria"];
		$idpodkategoria1 = $tablica["idpodkategoria1"];
		$idpodkategoria2 = $tablica["idpodkategoria2"];
						
		$datawpr = time(); 	
		
			
				$logo = $nazwa;
				$sql1 = "INSERT INTO produkty (idmarket, nazwa,producent, kategoria, podkategoria1, podkategoria2,opis,datawpr)	VALUES (:idmarket, :nazwa,:producent, :kategoria, :podkategoria1,:podkategoria2,:opis,:datawpr)";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":nazwa" , $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":idmarket" , $idmarket, PDO::PARAM_INT );
				$command->bindParam ( ":opis" , $opis, PDO::PARAM_STR );
				$command->bindParam ( ":producent" , $producent, PDO::PARAM_STR );
				$command->bindParam ( ":kategoria" , $idkategoria, PDO::PARAM_INT );
				$command->bindParam ( ":podkategoria1" , $idpodkategoria1, PDO::PARAM_INT );
				$command->bindParam ( ":podkategoria2" , $idpodkategoria2, PDO::PARAM_INT );
				$command->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command->execute ();
		
				$komunikat1 ='OK';
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}	
	
		
			
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);		
					
	}	
	
	public function actionUsunProdukt() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_GET['id'];
		
		$namex = Rozmiary::model ()->findAllByAttributes(array('idprodukt'=>$id));
		
		$sql = "DELETE  FROM produkty WHERE id=:id";
		$command = $connection->createCommand ( $sql );
		$command->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command->execute ();
		
		$sql2 = "DELETE  FROM rozmiary WHERE idprodukt=:id";
		$command2 = $connection->createCommand ( $sql2 );
		$command2->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command2->execute ();
		
		$sql3 = "DELETE  FROM ceny WHERE idprodukt=:id";
		$command3 = $connection->createCommand ( $sql3 );
		$command3->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command3->execute ();
		
				
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}
		
			
		foreach ( $namex as $value => $kategoria )
			{
		
			$plik = 'uploads3/' . $kategoria.'/fileform';
				$files = glob($plik . "/*/*/*",GLOB_MARK); 
				
				foreach($files as $file){ 
				
				if (is_dir($file) and !in_array($file, array('..', '.')))  {
                unlink($file);
               
                rmdir($file);
                } else if(is_file($file) and ($file != __FILE__)) {
               
                unlink($file); 
				}
				}
			}
		
		
		$data['dane'] =array(1);	
		echo json_encode($data);	
	}
	
		
	public function actionPobierzProdukt() {
		
		$id = $_GET['id'];	
		$namex = Produkty::model ()->findByPk($id);
					
		$products1=array();
		$products1["records"]=array();

		if($namex->datamodyf == 1) {$datamodyf = date('Y-m-d H:i',$namex->datamodyf);}  else { $datamodyf = 'Brak danych';}
		$datawpr= date('Y-m-d H:i', $namex->datawpr);
		$kategoria = Kategorie::model ()->findByPk($namex->kategoria);
		$podkategoria1 = Kategorie::model ()->findByPk($namex->podkategoria1);
		$podkategoria2 = Kategorie::model ()->findByPk($namex->podkategoria2);
		$market = Markety::model ()->findByPk($danex->idmarket);
		$product_item=array(
			"id" => $namex->id,
			"nazwa" => $namex->nazwa,
			"opis" => $namex->opis,
			"producent" => $namex->producent,
			"kategoria"=>$namex->kategoria,
			"podkategoria1"=>$namex->podkategoria1,
			"podkategoria2"=>$namex->podkategoria2,
			"kategorianazwa"=>$kategoria->nazwa,
			"podkategoria1nazwa"=>$podkategoria1->nazwa,
			"podkategoria2nazwa"=>$podkategoria2->nazwa,
			"datawpr"=>$datawpr,
			"datamodyf"=>$datamodyf,
			"idmarket"=>$namex->idmarket,
			"market"=>$market->nazwa,
			);
		array_push($products1["records"], $product_item);
			
		//
				
		$products2 = array();
		$products2['records'] = array();	
		
		$criteria2 = new CDbCriteria ();	
		$criteria2->condition = ' kateglowna IS NULL';	
		$dane2 = Kategorie::model ()->findAll ( $criteria2 );
				
		foreach($dane2 as $name)
		{	
				if($name->id == $kategoria->id)
				{ $checked ='on';} else {$checked ='off';}
		
		$tab2 = array("id"=>$name['id'],"nazwa"=>$name['nazwa'],'checked'=>$checked);
		array_push($products2['records'], $tab2);
		
		}
		//
		
		$products3 = array();
		$products3['records'] = array();
		
		$criteria3 = new CDbCriteria ();	
		$criteria3->condition = ' kateglowna IS NULL';	
		$dane3 = Kategorie::model ()->findAll ( $criteria3 );
				
		foreach($dane3 as $name)
		{	
			$dane4 = Kategorie::model()->findAllByAttributes(array('kateglowna'=>$name->id));	
			foreach($dane4 as $name2)
			{
				if($name2->id == $podkategoria1->id)
				{ $checked ='on';} else {$checked ='off';}
				$tab3 = array("id"=>$name2['id'],"nazwa"=>$name2['nazwa'], 'checked'=>$checked);	
				array_push($products3["records"], $tab3);	
			}				
		}
		
		//
		//
		$products4 = array();
		$products4['records'] = array();
		
		$criteria4 = new CDbCriteria ();	
		$criteria4->condition = ' kateglowna IS NULL';	
		$dane5 = Kategorie::model ()->findAll ( $criteria4 );
				
		foreach($dane5 as $name)
		{	
			$dane6 = Kategorie::model()->findAllByAttributes(array('kateglowna'=>$name->id));	
			foreach($dane6 as $name2)
			{
				$dane7 = Kategorie::model()->findAllByAttributes(array('kateglowna'=>$name2->id));	
				foreach($dane7 as $name3)
				{
					if($name3['id'] == $podkategoria2->id)
					{ $checked ='on';} else {$checked ='off';}
					$tab4 = array("id"=>$name3['id'],"nazwa"=>$name3['nazwa'], 'checked'=>$checked);	
					array_push($products4["records"], $tab4);
				}
			}				
		}
		
		//
		$products5 = array();
		$products5['records'] = array();
		$criteria5 = new CDbCriteria ();	
		$criteria5->order = ' id DESC';	
		$dane8 = Markety::model ()->findAll ( $criteria5 );
				
		foreach($dane8 as $name)
		{	
					if($name->id == $namex->idmarket)
					{ $checked ='on';} else {$checked ='off';}
					$tab5 = array("id"=>$name['id'],"nazwa"=>$name['nazwa'], 'checked'=>$checked);	
					array_push($products5["records"], $tab5);
						
		}
		
		
	$data['dane'] =array($products1,$products2,$products3, $products4,$products5);	
	echo json_encode($data);	
	
	
	}

	
	
	
	public function actionZmienProdukt() {
		
				
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {		
				
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		$id = $tablica["id"];
		$idmarket = $tablica["idmarket"];
		$nazwa = $tablica["nazwa"];
		$producent = $tablica["producent"];
		$opis = $tablica["opis"];
		$idkategoria = $tablica["kategoria"];
		$idpodkategoria1 = $tablica["podkategoria1"];
		$idpodkategoria2 = $tablica["podkategoria2"];
										
		$datamodyf = time(); 	
				$sql1 = "UPDATE produkty SET idmarket=:idmarket, nazwa =:nazwa,producent=:producent, kategoria=:kategoria, podkategoria1=:podkategoria1, podkategoria2=:podkategoria2,  opis=:opis, datamodyf=:datamodyf WHERE id=:id";
							
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":idmarket" , $idmarket, PDO::PARAM_INT );
				$command->bindParam ( ":nazwa" , $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":producent" , $producent, PDO::PARAM_STR );
				$command->bindParam ( ":kategoria" , $idkategoria, PDO::PARAM_INT );
				$command->bindParam ( ":podkategoria1" , $idpodkategoria1, PDO::PARAM_INT );
				$command->bindParam ( ":podkategoria2" , $idpodkategoria2, PDO::PARAM_INT );
				$command->bindParam ( ":opis" , $opis, PDO::PARAM_STR );
				$command->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command->bindParam ( ":datamodyf" , $datamodyf, PDO::PARAM_INT );
				$command->execute ();
				$komunikat1='OK';
				
				$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}			
		
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);
		
	}
	
		public function actionAddToCart() {
		session_start();
		if(!isset($_SESSION['cartx'])){
		$_SESSION['cartx']=array();
		}
		

		$id = $_GET['id'];
		$quantity = $_GET['quantity'];
		$itemArray = array($id=>array('name'=>'cc','code'=>$id, 'quantity'=>1, 'price'=>'pp', 'image'=>'bb'));
		
		
		if(!empty($_SESSION["cartx"])) {
				
			foreach ($_SESSION["cartx"] as   $item){
		
				if($id == $item['code']) {
						$item['quantity'] =0;
						$item['quantity']=$quantity;
						
				} else {
					$_SESSION["cartx"] = array_merge($_SESSION["cartx"],$itemArray);
				}
			} 
		} else {
			$_SESSION["cartx"] = $itemArray;
		}	
		
		
		$products=array();
		$products["komunikat"]= $action;	
			
		$data['dane'] =array($products);	
		echo json_encode($data);
			

	}
		
	public function actionDisplayCart() {
		
	$iduser = Yii::app()->user->id;	
		
		
	if (count ( $_SESSION ['cartx'] ) > 0) {
	$products1=array();
	$products1["records"]=array();
	
	$connection = Yii::app ()->db;
	$total =0;
	
	foreach ($_SESSION["cartx"] as   $item){
    $r = Rozmiary::model ()->findByPk($item['code']); 
	
				$produkt = Produkty::model ()->findByPk($r->idprodukt);
							
			
					$sql1 = "SELECT * FROM ceny WHERE idrozmiar =:id ORDER BY id DESC LIMIT 0,1";
					$command = $connection->createCommand ($sql1);
					$command->bindParam ( ":id" , $r->id, PDO::PARAM_INT );
					$command->execute ();
					$DaneZBazy = $command->query();
					while(($Rekord=$DaneZBazy->read())!==false)
					{
							$cena= $Rekord['cena'];
							$waluta= $Rekord['waluta'];
							$upust= $Rekord['upust'];
							$vat= $Rekord['vat'];
							$dataceny = date('Y-m-d H:i',$Rekord['datawpr']);
					}
				
						$plik = 'uploads3/'. $r->katalog;											
						if (file_exists ( $plik )) {
			
						$data2 = CFileHelper::findFiles ( $plik );
						$l = count($data2);
						if($l >0)
						{$y = str_replace ( '\\', '/', $data2[3] );
						$img = Yii::app ()->request->baseUrl . '/' . $y;}
						else {$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';	}	
							
						} else {
	
						$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';					
						} 

						$subtotal = $cena * $item['quantity'];
					
		
		
					$product_item=array("id" => $r->id,
					"nazwa" => $produkt->nazwa,
					"jednostka" => $r->jednostka,
					"rozmiar"=>$r->rozmiar, 
					"idprodukt"=>$r->idprodukt, 
					"idsklep"=>$r->idsklep,
					"idmarket"=>$r->idmarket,
					"katalog"=>$r->katalog,
					"cena"=>$cena,
					"subcena"=>$subtotal,
					"waluta"=>$waluta,
					"upust"=>$upust,
					"vat"=>$vat,
					"dataceny"=>$dataceny,
					"img"=>$img,
					"ilosc"=>$item['quantity'],
					"subtotal"=>$subtotal
					);
					array_push($products1["records"], $product_item);	
			
	$total+= $subtotal;
	}

	$products2["paging"]["cenatotal"]= round($total,2);	
			}
	if($iduser)
	{
	$products3["paging"]["id"]= "T";
	} else {$products3["paging"]["id"]= "N"; }
	
	
	$data['dane'] =array($products1, $products2,$products3);	
	echo json_encode($data);
	
	
	
	}

public function actionRemoveFromCart() {


$id = $_GET['id'];	

foreach ($_SESSION["cartx"] as   $item){

				
if($id == $item['code']) {
unset($_SESSION["cartx"][$id]);

}
}



$data['dane'] =array(1);	
echo json_encode($data);
}


public function actionUpdateCart()
{


$id = $_GET['id'];
$quantity = $_GET['quantity'];


foreach ($_SESSION["cartx"] as   $item){

				
						if($id == $item['code']) {
							
							
							if(empty($_SESSION["cartx"][$id]["quantity"])) {
								$_SESSION["cartx"][$id]["quantity"] = 0;
							}
							
							$_SESSION["cartx"][$id]["quantity"] =  $quantity;
						}
				
}

		





$data['dane'] =array(1);	
echo json_encode($data);


}


}
