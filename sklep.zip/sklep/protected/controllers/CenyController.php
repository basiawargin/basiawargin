<?php
class SklepyController extends Controller {
	
	public $layout = '//layouts/column2';
	
	
	public function filters() {
		return array (
				'accessControl', 
				'postOnly + delete' 
		); 
	}
	
	
	public function accessRules() {
		return array (array ('allow', 'actions' => array ('index',"zdjecie"),	'users' => array ('*')));
	}
	
	
		
		public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 	
		$this->render ( 'index');
	}
	


		public function actionPobierzSklepy()
	{

		$page= $_GET['page'];
		$limit=20;

		$id_user=Yii::app()->user->id;
		$dane = User::model()->findByPk($id_user);
		$superuser = $dane->superuser;
		$id_sklep = $dane->id_sklep;
		
		
		$criteria = new CDbCriteria ();
		$criteria->order = 'id DESC';
	
		if($superuser == 2) {
			$criteria->condition= 'id = '.$id_sklep;	
			$sklepy = Sklepy::model ()->findAll ( $criteria );

		}
		else  
		{ 
			$sklepy = Sklepy::model ()->findAll ();
					
		}
		
		$liczba_wierszy = count($sklepy);
		$strony = ceil($liczba_wierszy/$limit);
		if($liczba_wierszy !== 0)
		{
					if($page > $strony) {
					$page = $page-1;
					
				} else { $page = $page; $start = ($page - 1) * $limit;}
		}
		else {
					$page=1;
					$start=0;
		}
		
		$connection = Yii::app ()->db;	
		if($superuser ==2)
		{ $sq2 = "SELECT DISTINCT * FROM sklepy  WHERE id =:id_sklep ORDER BY id DESC  LIMIT :zacznij, :limit_na_strone";
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":id_sklep" , $id_sklep, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$sklepy2=$command2->queryAll();
		} 
		
		if($superuser ==1)
		{
			
		$sq2 = "SELECT DISTINCT * FROM sklepy  ORDER BY id DESC  LIMIT :zacznij, :limit_na_strone";
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$sklepy2=$command2->queryAll();
		}
		
		
		
		$products1=array();
		$products1["records"]=array();
		foreach ( $sklepy2 as $name ) {
			
		if(	($name['pos_id']==0 or $name['pos_id'] == null) and ($name['CustomerId'] == 0 or $name['CustomerId'] == null )
			and ($name['marchant_id'] == 0 or $name['marchant_id'] == null) and ($name['MerchantPosId'] == 0 or $name['MerchantPosId'] == null))
			{
			$kom = 'platnosc_error';	
			} else { $kom = 'platnosc_ok';}
		
		if(	($name['godziny1']==0 and $name['godziny2'] == 0) or ($name['godziny3'] == 0 and $name['godziny4'] == 0 )
			or ($name['godziny5'] == 0 and $name['godziny6'] == 0) or ($name['godziny7'] == 0 and $name['godziny8'] == 0))
			{
			$kom2 = 'godziny_error';	
			} else { $kom2 = 'godziny_ok';}
			
			//-------------------------------------------------
			$plik = 'uploads2/'. $name['katalog'];											
			if (file_exists ( $plik )) {
			
				$data2 = CFileHelper::findFiles ( $plik );
				$l = count($data2);
				if($l >0)
				{$y = str_replace ( '\\', '/', $data2[3] );
				$img = Yii::app ()->request->baseUrl . '/' . $y;}
				else {$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';	}	
							
				} else {
	
				$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';					
			} 
			
			//------------------------------------------------
			
			$product_item=array("id" => $name['id'],"nazwa" => $name['nazwa'], "nip" => $name['nip'], "kom"=>$kom, "kom2"=>$kom2,"img" => $img);
			array_push($products1["records"], $product_item);
		}
			
		
		
		$products2=array();
		$products2["paging"]= array();
		$ab =array();	
		
		$url = Yii::app ()->params ['url'];

		for($xc=1; $xc<=$strony; $xc++)
		{
			if($xc == $page) {$z='yes';} else {$z = 'no';}
			$ab[] = array('page'=>$xc,'url'=>'http://'.$url.'/index.php/sklepy/ListaSklepow/page/'.$xc,'current_page'=>$z);
		}
		if($strony >4)
			{ $products2["paging"]= array('first'=>'http://'.$url.'/index.php/sklepy/ListaSklepow/page/1/',
			'last'=>'http://'.$url.'/index.php/sklepy/ListaSklepow/page/'.$strony);	}
			else { $products2["paging"]= array('first'=>'', 'last'=>'');}
		
		$products2["paging"]["pages"]= $ab;	
		$products2["paging"]["liczba_rekordow"]= $liczba_wierszy;
		$products2["paging"]["page"]= $page;
			
			
			
		$data['dane'] =array($products1, $products2);
		echo json_encode($data);
	
	}
	
		public function actionPobierzSklepySelect()
	{

		$id_user=Yii::app()->user->id;
		$dane = User::model()->findbyPk($id_user);
		$superuser = $dane->superuser;
		$id_sklep = $dane->id_sklep;
		
		$model = new Uzytkownicy ();
		$criteria = new CDbCriteria ();
		$criteria->order = 'id DESC';
	
		if($superuser == 2) {
			$criteria->condition= 'id = '.$id_sklep;	
			$count = Sklepy::model ()->count ( $criteria );
			$sklepy = Sklepy::model ()->findAll ( $criteria );

		}
		else  
		{ 
			$count = Sklepy::model ()->count ( $criteria );
			$sklepy = Sklepy::model ()->findAll ( $criteria );
					
		}
		
		$products1=array();
		$products1["records"]=array();
		foreach ( $sklepy as $name ) {
			
		if(	($name['pos_id']==0 or $name['pos_id'] == null) and ($name['CustomerId'] == 0 or $name['CustomerId'] == null )
			and ($name['marchant_id'] == 0 or $name['marchant_id'] == null) and ($name['MerchantPosId'] == 0 or $name['MerchantPosId'] == null))
			{
			$kom = 'platnosc_error';	
			} else { $kom = 'platnosc_ok';}
		
		if(	($name['godziny1']==0 and $name['godziny2'] == 0) or ($name['godziny3'] == 0 and $name['godziny4'] == 0 )
			or ($name['godziny5'] == 0 and $name['godziny6'] == 0) or ($name['godziny7'] == 0 and $name['godziny8'] == 0))
			{
			$kom2 = 'godziny_error';	
			} else { $kom2 = 'godziny_ok';}
			
			//-------------------------------------------------
			$plik = 'uploads2/'. $name['katalog'];											
			if (file_exists ( $plik )) {
			
				$data2 = CFileHelper::findFiles ( $plik );
				$l = count($data2);
				if($l >0)
				{$y = str_replace ( '\\', '/', $data2[3] );
				$img = Yii::app ()->request->baseUrl . '/' . $y;}
				else {$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';	}	
							
				} else {
	
				$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';					
			} 
			
			//------------------------------------------------
			
			$product_item=array("id" => $name['id'],"nazwa" => $name['nazwa'], "nip" => $name['nip'], "kom"=>$kom, "kom2"=>$kom2,"img" => $img);
			array_push($products1["records"], $product_item);	
		
		}
					
		$data['dane'] =array($products1);
		echo json_encode($data);
	
	}
	
	
	public function actionDodajSklep()
	{
		
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);

		$nazwa = $tablica["nazwa"];
		$ulica = $tablica["ulica"];
		$numer = $tablica["numer"];
		$miasto = $tablica["miasto"];
		$kraj = $tablica["kraj"];
		$telefon = $tablica["telefon"];
		$email = $tablica["email"];
		$nip = $tablica["nip"];
		$kod = $tablica["kod"];
		$is_actual = $tablica["is_actual"];
		$godziny1 = $tablica["godziny1"];
		$godziny2 = $tablica["godziny2"];
		$godziny3 = $tablica["godziny3"];
		$godziny4 = $tablica["godziny4"];
		$godziny5 = $tablica["godziny5"];
		$godziny6 = $tablica["godziny6"];
		$godziny7 = $tablica["godziny7"];
		$godziny8 = $tablica["godziny8"];
		
		$radius = $tablica["radius"];
		$oplata = $tablica["oplata"];
		$kilometr = $tablica["kilometr"];
		
		$errors = array();
		$errors['godz1']='NO';
		$errors['godz2']='NO';
		$errors['godz3']='NO';
		$errors['godz4']='NO';
		
				
		//---------------------------------------------------------------------
		if($godziny1 > $godziny2)
		{ $errors['godz1']='TAK';}
	
		if($godziny3 > $godziny4)
		{ $errors['godz2']='TAK'; }
	
		if($godziny5 > $godziny6)
		{ $errors['godz3']='TAK';}
	
		if($godziny7 > $godziny8)
		{  $errors['godz4']='TAK';}
	
		
		if( ($godziny2 - $godziny1 == 0) )
		{ $errors['godz1']='TAK';}
			
		if( ($godziny4 - $godziny3 == 0))
		{ $errors['godz2']='TAK';}
	
		if( ($godziny6 - $godziny5 == 0))
		{ $errors['godz3']='TAK';}
	
		if( ($godziny8 - $godziny7 == 0))
		{ $errors['godz4']='TAK';}
	
	
		if($godziny1 == 1 and $godziny2 !== 1 )	{$errors['godz1']='TAK'; }
		if($godziny1 !== 1 and $godziny2 == 1 )	{ $errors['godz1']='TAK';}
				
		if($godziny3 == 1 and $godziny4 !== 1 )	{ $errors['godz2']='TAK';}
		if($godziny3 !== 1 and $godziny4 == 1 )	{$errors['godz2']='TAK'; }
		
		if($godziny5 == 1 and $godziny6 !== 1 )	{$errors['godz3']='TAK'; }
		if($godziny5 !== 1 and $godziny6 == 1 )	{$errors['godz3']='TAK'; }
		
		if($godziny7 == 1 and $godziny8 !== 1 )	{$errors['godz4']='TAK'; }
		if($godziny7 !== 1 and $godziny8 == 1 )	{$errors['godz4']='TAK'; }
	
		if( ($godziny1==1 and $godziny2 == 1) )
		{ $errors['godz1']='NO';}
	
		if( ($godziny3==1 and $godziny4 == 1) )
		{ $errors['godz2']='NO';}
	
		if( ($godziny5==1 and $godziny6 == 1) )
		{ $errors['godz3']='NO';}
	
		if( ($godziny7==1 and $godziny8 == 1) )
		{ $errors['godz4']='NO';}
	
		//------------------------------------------------------------------------
		
		
		$data_wprowadzenia = date('Y-m-d H:i:s'); $data_wpr = strtotime($data_wprowadzenia);	
		$logo ='kat'.$nip;
		$data_modyfikacji = 1;
		
		
		if($errors['godz1'] !== 'TAK' and $errors['godz2'] !== 'TAK' and $errors['godz3'] !== 'TAK' and $errors['godz4'] !== 'TAK')
		{
						
				
				$sql1 = "INSERT INTO sklepy (nazwa, nip, ulica, numer, miasto, kraj,  telefon, email, is_actual, datawpr, datamodyf, katalog, godziny1, godziny2, godziny3, godziny4, godziny5, godziny6,godziny7, godziny8,kilometr,radius,oplata, kod)
				VALUES (:nazwa, :nip, :ulica, :numer, :miasto, :kraj, :telefon, :email, :is_actual, :datawpr, :datamodyf, :katalog, :godziny1, :godziny2, :godziny3, :godziny4, :godziny5, :godziny6, :godziny7, :godziny8, :kilometr,:radius,:oplata,:kod )";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":nazwa" , $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":nip" , $nip, PDO::PARAM_STR );
				$command->bindParam ( ":ulica" , $ulica, PDO::PARAM_STR );
				$command->bindParam ( ":numer" , $numer, PDO::PARAM_STR );
				$command->bindParam ( ":miasto" , $miasto, PDO::PARAM_STR );
				$command->bindParam ( ":kraj" , $kraj, PDO::PARAM_STR );
				$command->bindParam ( ":telefon" , $telefon, PDO::PARAM_STR );
				$command->bindParam ( ":email" , $email, PDO::PARAM_STR );
				$command->bindParam ( ":is_actual" , $is_actual, PDO::PARAM_STR );
				$command->bindParam ( ":datawpr" , $data_wpr, PDO::PARAM_INT );
				$command->bindParam ( ":datamodyf" , $data_modyfikacji, PDO::PARAM_INT );
				$command->bindParam ( ":katalog" , $logo, PDO::PARAM_STR );
				$command->bindParam ( ":godziny1" , $godziny1, PDO::PARAM_INT );
				$command->bindParam ( ":godziny2" , $godziny2, PDO::PARAM_INT );
				$command->bindParam ( ":godziny3" , $godziny3, PDO::PARAM_INT );
				$command->bindParam ( ":godziny4" , $godziny4, PDO::PARAM_INT );
				$command->bindParam ( ":godziny5" , $godziny5, PDO::PARAM_INT );
				$command->bindParam ( ":godziny6" , $godziny6, PDO::PARAM_INT );
				$command->bindParam ( ":godziny7" , $godziny7, PDO::PARAM_INT );
				$command->bindParam ( ":godziny8" , $godziny8, PDO::PARAM_INT );
				$command->bindParam ( ":kilometr" , $kilometr, PDO::PARAM_INT );
				$command->bindParam ( ":radius" , $radius, PDO::PARAM_INT );
				$command->bindParam ( ":oplata" , $oplata, PDO::PARAM_INT );
				$command->bindParam ( ":kod" , $kod, PDO::PARAM_STR );
				$command->execute ();
				
						
				$sql2="SELECT id FROM sklepy WHERE katalog = :logo";
				$command2 = $connection->createCommand ($sql2);	
				$command2->bindParam ( ":logo" , $logo, PDO::PARAM_STR );
				$command2->execute ();
				$DaneZBazy = $command2->query();
				while(($Rekord=$DaneZBazy->read())!==false)
				{
				$id= $Rekord['id'];
				}
			
				$logo2= 'kat'.$id;
				$sql3 = "UPDATE sklepy SET katalog =:logo WHERE id=:id";
				$command3 = $connection->createCommand ($sql3);
				$command3->bindParam ( ":logo" , $logo2, PDO::PARAM_STR );
				$command3->bindParam ( ":id" , $id, PDO::PARAM_STR );
				$command3->execute ();
				$komunikat1 ='OK';
		} else 
		{
			$komunikat1 ='NO';
		}			
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}	
			
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);		
	
				
	}	
	
	public function actionUsunSklep() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_GET['id'];
		$sql = "DELETE  FROM sklepy WHERE id=:id";
		$command = $connection->createCommand ( $sql );
		$command->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command->execute ();
				
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}
		$data['dane'] =array(1);	
		echo json_encode($data);	
	}
	
		
	public function actionPobierzSklep() {
		
		$id = $_GET['id'];	
		$name = Sklepy::model ()->findByPk($id);
					
		$products1=array();
		$products1["records"]=array();
		
	
		$jednostka = array (
			0 => '00:00',
			1800 => '00:30',
			1800 * 2 => '01:00',
			1800 * 3 => '01:30',
			1800 * 4 => '02:00',
			1800 * 5 => '02:30',
			1800 * 6 => '03:00',
			1800 * 7 => '03:30',
			1800 * 8 => '04:00',
			1800 * 9 => '04:30',
			1800 * 10 => '05:00',
			1800 * 11 => '05:30',
			1800 * 12 => '06:00',
			1800 * 13 => '06:30',
			1800 * 14 => '07:00',
			1800 * 15 => '07:30',
			1800 * 16 => '08:00',
			1800 * 17 => '08:30',
			1800 * 18 => '09:00',
			1800 * 19 => '09:30',
			1800 * 20 => '10:00',
			1800 * 21 => '10:30',
			1800 * 22 => '11:00',
			1800 * 23 => '11:30',
			1800 * 24 => '12:00',
			1800 * 25 => '12:30',
			1800 * 26 => '13:00',
			1800 * 27 => '13:30',
			1800 * 28 => '14:00',
			1800 * 29 => '14:30',
			1800 * 30 => '15:00',
			1800 * 31 => '15:30',
			1800 * 32 => '16:00',
			1800 * 33 => '16:30',
			1800 * 34 => '17:00',
			1800 * 35 => '17:30',
			1800 * 36 => '18:00',
			1800 * 37 => '18:30',
			1800 * 38 => '19:00',
			1800 * 39 => '19:30',
			1800 * 40 => '20:00',
			1800 * 41 => '20:30',
			1800 * 42 => '21:00',
			1800 * 43 => '21:30',
			1800 * 44 => '22:00',
			1800 * 45 => '22:30',
			1800 * 46 => '23:00',
			1800 * 47 => '23:30',
			1800 * 48 => '24:00'
		);
			
					
		$x1 = $name->godziny1; $y1 = $name->godziny2;
		$x2 = $name->godziny3; $y2 = $name->godziny4;
		$x3 = $name->godziny5; $y3 = $name->godziny6;
		$x4 = $name->godziny7; $y4 = $name->godziny8;
	
		
		foreach($jednostka as $key => $value)
		{
			if($key == $x1) { $g1 = $value; }
			if($key == $y1) { $g2 = $value; }
			if($key == $x2) { $g3 = $value; }
			if($key == $y2) { $g4 = $value; }
			if($key == $x3) { $g5 = $value; }
			if($key == $y3) { $g6 = $value; }
			if($key == $x4) { $g7 = $value; }
			if($key == $y4) { $g8 = $value; }
		}
		
		
		if($x1== 1)
		{ $robocze='';} else {$robocze = $g1." -  ".$g2;} 
	
		if($x2 == 1)
		{ $sobota='';} else {$sobota = $g3." -  ".$g4; } 
	
	
		if($x3 == 1)
		{ $niedziela='';} else {$niedziela = $g5."-  ".$g6; } 
						
		if($name->godziny7 == 1) { $na_wynos='';} else 
		{				
		
		$na_wynos = $g7.' - '.$g8;	
		} 						
		$kilometry = array(1=>'Do 1km',1=>'Do 2km',3=>'Do 3km',4=>'Do 4km',5=>'Do 5km',6=>'Do 6km',7=>'Do 7km',8=>'Do 8km',9=>'Do 9km',10=>'Do 10km',11=>'Do 20km',12=>'Do 30km',13=>'Do 40km',14=>'Do 50km');
		$kilometry2 = array(1=>'Za 1km',1=>' Za 2km',3=>'Za 3km',4=>'Za 4km',5=>'Za 5km',6=>'Za 6km',7=>'Za 7km',8=>'Za 8km',9=>'Za 9km',10=>'ZA 10km',11=>'Za 20km',12=>'Za 30km',13=>'Za 40km',14=>'Za 50km');
		
		foreach($kilometry2 as $key => $value){ if($name->kilometr == $key) {$opl= $value;}}
		$oplata = $name->oplata.' PLN/'.$opl.'';	
		$oplata1 = $name->oplata;	
		
		foreach($kilometry as $key => $value){ if($name->radius == $key) {$radius= $value;}}
		
		if($name->datamodyf == 1) {$data_modyf = date('Y-m-d H:i',$name->datamodyf);}  else { $data_modyf = 'Brak danych';}
		
		$data_wpr= date('Y-m-d H:i', $name->datawpr);

		$product_item=array(
			"id" => $name->id,
			"nazwa" => $name->nazwa,
			"miasto" => $name->miasto,
			"kraj"=>$name->kraj,
			"ulica"=>$name->ulica,
			"numer"=>$name->numer,
			"nip" => $name->nip,
			"kod" => $name->kod,
			"telefon"=>$name->telefon,
			"email"=>$name->email,
			"kraj"=>$name->kraj,
			'is_actual'=>$name->is_actual,
			"data_wprowadzenia"=>$data_wpr,
			"data_modyfikacji"=>$data_modyf,
			"godziny_robocze"=>$robocze,
			"godziny_sobota"=>$sobota,
			"godziny_niedziela"=>$niedziela,
			"na_wynos"=>$na_wynos,
			"pos_id"=>$name->pos_id,
			"marchant_id"=>$name->marchant_id,
			"CustomerId"=>$name->CustomerId,
			"MerchantPosId"=>$name->MerchantPosId,
			"radius"=>$radius,
			"oplata"=>$oplata,
			"oplata1"=>$oplata1,
			"kilometr"=>$name->kilometr,
			"godziny1"=>$name->godziny1,
			"godziny2"=>$name->godziny2,
			"godziny3"=>$name->godziny3,
			"godziny4"=>$name->godziny4,
			"godziny5"=>$name->godziny5,
			"godziny6"=>$name->godziny6,
			"godziny7"=>$name->godziny7,
			"godziny8"=>$name->godziny8
			 
			);
			array_push($products1["records"], $product_item);
			
			
	echo json_encode($products1);
	
	
	}

	
	
	
	public function actionZmienSklep() {
		
				
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {		
				
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		
		$id = $tablica["id"];
		$nazwa = $tablica["nazwa"];
		$ulica = $tablica["ulica"];
		$numer = $tablica["numer"];
		$miasto = $tablica["miasto"];
		$kraj = $tablica["kraj"];
		$kod = $tablica["kod"];
		$telefon = $tablica["telefon"];
		$email = $tablica["email"];
		$nip = $tablica["nip"];
		$is_actual = $tablica["is_actual"];
		$godziny1 = $tablica["godziny1"];
		$godziny2 = $tablica["godziny2"];
		$godziny3 = $tablica["godziny3"];
		$godziny4 = $tablica["godziny4"];
		$godziny5 = $tablica["godziny5"];
		$godziny6 = $tablica["godziny6"];
		$godziny7 = $tablica["godziny7"];
		$godziny8 = $tablica["godziny8"];
		
		$radius = $tablica["radius"];
		$oplata = $tablica["oplata"];
		$kilometr = $tablica["kilometr"];

		$errors = array();
		$errors['plat']='NO';
		$errors['godz1']='NO';
		$errors['godz2']='NO';
		$errors['godz3']='NO';
		$errors['godz4']='NO';
		
		
		if($godziny1 > $godziny2)
		{ $errors['godz1']='TAK';}
	
		if($godziny3 > $godziny4)
		{ $errors['godz2']='TAK'; }
	
		if($godziny5 > $godziny6)
		{ $errors['godz3']='TAK';}
	
		if($godziny7 > $godziny8)
		{  $errors['godz4']='TAK';}
	
		
		if( ($godziny2 - $godziny1 == 0) )
		{ $errors['godz1']='TAK';}
			
		if( ($godziny4 - $godziny3 == 0))
		{ $errors['godz2']='TAK';}
	
		if( ($godziny6 - $godziny5 == 0))
		{ $errors['godz3']='TAK';}
	
		if( ($godziny8 - $godziny7 == 0))
		{ $errors['godz4']='TAK';}
	
		if($godziny1 == 1 and $godziny2 !== 1 )	{$errors['godz1']='TAK'; }
		if($godziny1 !== 1 and $godziny2 == 1 )	{ $errors['godz1']='TAK';}
				
		if($godziny3 == 1 and $godziny4 !== 1 )	{ $errors['godz2']='TAK';}
		if($godziny3 !== 1 and $godziny4 == 1 )	{$errors['godz2']='TAK'; }
		
		if($godziny5 == 1 and $godziny6 !== 1 )	{$errors['godz3']='TAK'; }
		if($godziny5 !== 1 and $godziny6 == 1 )	{$errors['godz3']='TAK'; }
		
		if($godziny7 == 1 and $godziny8 !== 1 )	{$errors['godz4']='TAK'; }
		if($godziny7 !== 1 and $godziny8 == 1 )	{$errors['godz4']='TAK'; }
	
		if( ($godziny1==1 and $godziny2 == 1) )
		{ $errors['godz1']='NO';}
	
		if( ($godziny3==1 and $godziny4 == 1) )
		{ $errors['godz2']='NO';}
	
		if( ($godziny5==1 and $godziny6 == 1) )
		{ $errors['godz3']='NO';}
	
		if( ($godziny7==1 and $godziny8 == 1) )
		{ $errors['godz4']='NO';}
				
			
		$data_modyfikacji = date('Y-m-d H:i:s'); $data_modyf = strtotime($data_modyfikacji);
					

		if($errors['godz1'] !== 'TAK' and $errors['godz2'] !== 'TAK' and $errors['godz3'] !== 'TAK' and $errors['godz4'] !== 'TAK')
		{
				
		$sql1 = "UPDATE sklepy SET nazwa =:nazwa, miasto=:miasto, nip=:nip, ulica=:ulica, numer=:numer, kraj=:kraj,kod=:kod,
				telefon=:telefon,email=:email,is_actual=:is_actual,datamodyf=:datamodyf, 
				godziny1 =:godziny1,godziny2 =:godziny2,godziny3 =:godziny3,godziny4 =:godziny4,godziny5 =:godziny5,godziny6 =:godziny6,godziny7 =:godziny7,godziny8 =:godziny8,
				oplata =:oplata,kilometr =:kilometr,radius=:radius WHERE id=:id";
							
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":nazwa" , $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":nip" , $nip, PDO::PARAM_STR );
				$command->bindParam ( ":ulica" , $ulica, PDO::PARAM_STR );
				$command->bindParam ( ":numer" , $numer, PDO::PARAM_STR );
				$command->bindParam ( ":miasto" , $miasto, PDO::PARAM_STR );
				$command->bindParam ( ":kraj" , $kraj, PDO::PARAM_STR );
				$command->bindParam ( ":kod" , $kod, PDO::PARAM_STR );
				$command->bindParam ( ":telefon" , $telefon, PDO::PARAM_STR );
				$command->bindParam ( ":email" , $email, PDO::PARAM_STR );
				$command->bindParam ( ":is_actual" , $is_actual, PDO::PARAM_STR );
				$command->bindParam ( ":datamodyf" , $data_modyf, PDO::PARAM_INT );
				$command->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command->bindParam ( ":godziny1" , $godziny1, PDO::PARAM_INT );
				$command->bindParam ( ":godziny2" , $godziny2, PDO::PARAM_INT );
				$command->bindParam ( ":godziny3" , $godziny3, PDO::PARAM_INT );
				$command->bindParam ( ":godziny4" , $godziny4, PDO::PARAM_INT );
				$command->bindParam ( ":godziny5" , $godziny5, PDO::PARAM_INT );
				$command->bindParam ( ":godziny6" , $godziny6, PDO::PARAM_INT );
				$command->bindParam ( ":godziny7" , $godziny7, PDO::PARAM_INT );
				$command->bindParam ( ":godziny8" , $godziny8, PDO::PARAM_INT );
				$command->bindParam ( ":oplata" , $oplata, PDO::PARAM_INT );
				$command->bindParam ( ":kilometr" , $kilometr, PDO::PARAM_INT );
				$command->bindParam ( ":radius" , $radius, PDO::PARAM_INT );
				$command->execute ();
				$komunikat1='OK';
		}else{
			$komunikat1='NO';
		}
			
				$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}			
		
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);
		
	}
	
	
	public function actionZmienSklep2() {
		
				
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {		
		
		$errors = array();
		$errors['plat']='NO';
				
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		
		$id = $tablica["id"];
		$data_modyfikacji = date('Y-m-d H:i:s'); $data_modyf = strtotime($data_modyfikacji);
		$pos_id = $tablica['pos_id'];
		$marchant_id = $tablica['marchant_id'];
		$CustomerId = $tablica['CustomerId'];
		$MerchantPosId = $tablica['MerchantPosId'];


		if($pos_id==0) {$pos_id = null; }
		if($marchant_id==0) {$marchant_id = null; }
		if($CustomerId==0) {$CustomerId = null; }
		if($MerchantPosId==0) {$MerchantPosId = null; }
				
		if (is_numeric($pos_id) and !is_numeric($marchant_id)){ $errors['plat']='TAK';} 
		if (!is_numeric($pos_id) and is_numeric($marchant_id)){$errors['plat']='TAK';} 
		if (is_numeric($CustomerId) and !is_numeric($MerchantPosId)){ $errors['plat']='TAK';} 
		if (!is_numeric($CustomerId) and is_numeric($MerchantPosId)){$errors['plat']='TAK';} 
					
		$data_modyfikacji = date('Y-m-d H:i:s'); $data_modyf = strtotime($data_modyfikacji);
		if($errors['plat'] =='NO')
		{
			$sql1 = "UPDATE sklepy SET datamodyf=:data_modyfikacji,	pos_id =:pos_id,marchant_id =:marchant_id,CustomerId =:CustomerId,MerchantPosId =:MerchantPosId	WHERE id=:id";
			$command1 = $connection->createCommand ($sql1);
			$command1->bindParam ( ":data_modyfikacji" , $data_modyf, PDO::PARAM_INT );
			$command1->bindParam ( ":id" , $id, PDO::PARAM_INT );
			$command1->bindParam ( ":pos_id" , $pos_id, PDO::PARAM_INT );
			$command1->bindParam ( ":marchant_id" , $marchant_id, PDO::PARAM_INT );
			$command1->bindParam ( ":CustomerId" , $CustomerId, PDO::PARAM_INT );
			$command1->bindParam ( ":MerchantPosId" , $MerchantPosId, PDO::PARAM_INT );
			$command1->execute ();
			$komunikat1 ='OK';
		}
		else {
		$komunikat1 = 'NO';
		}		
			$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}			
			
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);
		
	}
	
	// ---------------------------------------------------------------------------------------------------------------------------------
	
	//fotografie
	
	
	
	public function actionDodajZdjecieSklep() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_POST['id'];
		$foto = Sklepy::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		$documentroot = $_SERVER ['DOCUMENT_ROOT'];
		$username = '/uploads2/' . $foto->katalog;
		$baseDirectory = 'uploads2/' . $foto->katalog;
		
		if (file_exists ( $documentroot . "/" . $username )) {
		} else {
			mkdir ( $documentroot . "/" . $username, 0777 );
		}
		
		$model2 = new Fileform ();
		$model2->katalog = $msg;
		$model2->baseDirectory = 'uploads2/' . $msg . '/';
		
		$model2->file = 'uploads2/' . $msg . '/';
		$model2->images = 'd';	
		$model2->name ='d';
		$model2->attributes = 'd';


		$images = new CUploadedFile($_FILES['myfile']['name'], $_FILES['myfile']['tmp_name'], $_FILES['myfile']['type'], $_FILES['myfile']['size'], $_FILES['myfile']['error']);
      		$is = 'df';
		$model2->image = $images;
		
		
			if ($images) {
				// Clean up the filename
				$uglyName = strtolower ( $model2->name );
				$mediocreName = preg_replace ( '/[^a-zA-Z0-9]+/', '_', $uglyName );
				$beautifulName = trim ( $mediocreName, '_' ) . "." . $is;
				$model2->image_name = $beautifulName;
				$im = 'jpg';
				$newName = md5 ( microtime ( true ) ) . '_' . $model2->name . "." . $im;
			}
						
			if ($model2->save()){
		
				
				if ($images) {
					
					Yush2::init ( $model2, $msg ); 
					                     

					$originalPath = Yush2::getPath ( $model2, Yush2::SIZE_ORIGINAL, $newName );
					$largePath = Yush2::getPath ( $model2, Yush2::SIZE_LARGE, $newName );
					$smallPath = Yush2::getPath ( $model2, Yush2::SIZE_SMALL, $newName );
					$thumbPath = Yush2::getPath ( $model2, Yush2::SIZE_THUMB, $newName );
					
					
					
					$images->saveAs ( $originalPath );
					
					
					$largeImage = Yii::app ()->phpThumb->create ( $originalPath );
					$largeImage->resize ( 700, 400 );
					$largeImage->save ( $largePath );
					
					$x2 = 'images/logo.jpg';
					
					$x = $originalPath;
					$x3 = $largePath;
					$size2 = getimagesize ( $x );
					$skala = $size2 [0] / $size2 [1];
					
					$watermark = imagecreatefromjpeg ( $x2 );
					$watermark_width = imagesx ( $watermark );
					$watermark_height = imagesy ( $watermark );
					
					$size = getimagesize ( $x2 );
					
					if ($skala < 1) {
						$dest_x = $size [0] - $watermark_width + 90;
						$dest_y = $size [1] - $watermark_height + 170;
					} else {
						$dest_x = $size [0] - $watermark_width + 470;
						$dest_y = $size [1] - $watermark_height + 290;
					}
					
					$image = imagecreatefromjpeg ( $x );
					$image2 = imagecreatefromjpeg ( $x3 );
					imagecopymerge ( $image, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 25 );
					imagecopymerge ( $image2, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 25 );
					imagejpeg ( $image, $x );
					imagejpeg ( $image2, $x3 );
					
					imagedestroy ( $image );
					imagedestroy ( $image2 );
					imagedestroy ( $watermark );
					
					// Create a small image
					$smallImage = Yii::app ()->phpThumb->create ( $originalPath );
					$smallImage->resize ( 405, 220 );
					$smallImage->save ( $smallPath );
					
					// Create a thumbnail
					$thumbImage = Yii::app ()->phpThumb->create ( $originalPath );
					$thumbImage->resize ( 350, 200 );
					$thumbImage->save ( $thumbPath );
					
						
					
	
				$data_modyf = time();
				$sql1 = "Update sklepy  SET  datamodyf=:data_modyf ";
				$command1 = $connection->createCommand ( $sql1 );
				$command1->bindParam ( ":data_modyf", $data_modyf, PDO::PARAM_INT );
				$command1->execute ();
					
				}		
					
				}
				$transaction->commit();	
				
			}	
			catch(Exception $e)
			{
				$transaction->rollback();
			}
		
		$data['dane'] =array(1);	
		echo json_encode($data);
	}
	
	public function actionListaZdjecSklep() {
				
			$id = $_POST['id'];
			$foto = Sklepy::model ()->findByPk($id);
			$plik = 'uploads2/'.$foto->katalog .'/fileform/';
			$nazwa = $foto->nazwa;				
			$products=array();
			$products["records"]=array();
																
			if (file_exists ( $plik )) {
			
				$data2 = CFileHelper::findFiles ( $plik );
					$liczba = count ( $data2 );
					$tab = array ();
					$numer = 0;
					for($x = 1; $x < $liczba;) {
					$y = str_replace ( '\\', '/', $data2 [$x] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
					$tab [] = $x2;
					$x = $x + 4;
					$numer ++;
					}
				} else {
								
				$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
				$img = '<img src="'.$x2.'" />';
				$numer='x';
				}
			$product_item=array("numer" => $numer,"img" => $x2, "id"=>$id,"nazwa"=>$nazwa);
			array_push($products["records"], $product_item);
		
				
			$data["dane"]= array($products);	
			echo json_encode($data);
	}

	public function actionZdjecieSklep()
	{
			
			$zdjeciex = $_GET['zdjecie'];
			$tab = explode("-",$zdjeciex);
		
			$zdjecie1 = $tab[2];
			$id = $tab[1];
	
			$zdjecie2 = str_replace("x","/",$zdjecie1);
			$zdjecie3 = str_replace("xx","//",$zdjecie2);
			$zdjecie4 = str_replace("xxX","_",$zdjecie3);
			$zdjecie = str_replace("xxXX",".",$zdjecie4);
	
			$foto = Sklepy::model ()->findByPk ( $id );
			$msg = $foto->katalog;
		
			$x = str_replace ( '/uploads2/' . $msg . '/fileform//', '', $zdjecie );
			$pozycja_konca = strpos ( $x, '/' );
			$numer_katalogu = substr ( $x, 0, $pozycja_konca );
			$katalog1 = 'uploads2/' . $msg . '/fileform//' . $numer_katalogu . '/';
																	
			if (file_exists ( $katalog1 )) {
			
			
				$data2 = CFileHelper::findFiles ( $katalog1 );
					$liczba = count ( $data2 );
					
					$numer = 0;
					for($xz = 1; $x < $liczba;) {
					$y = str_replace ( '\\', '/', $data2[$xz] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
					$xz = $xz + 4;
														
					}
				} else {
								
				$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
						
			}
			
		$this->render('zdjecie',array('zdjecie'=>$x2));
	}

	public function actionSprawdzenieLiczby()
	{
		
		$id = $_POST['id'];
		$foto = Sklepy::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		// Sprawdzenie czy jest już jedno zdjęcie
		if(file_exists('uploads2/' . $foto->katalog.'/fileform/'))
		{	
		$plik = 'uploads2/' . $foto->katalog . '/fileform/';											
		$data2 = CFileHelper::findFiles ( $plik );
		$liczba_zdjec = count($data2)/4+1;
						
		} else {$liczba_zdjec =1;}
		
		$data = array('liczba'=>$liczba_zdjec);
		echo json_encode($data);
	}
	
	
	public function actionUsunZdjecieSklep() {
	
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
	
		$usun = $_POST['usun'];
		$tab = explode("-",$usun);
		
		$zdjecie1 = $tab[2];
		$id = $tab[1];
	
		$zdjecie2 = str_replace("x","/",$zdjecie1);
		$zdjecie3 = str_replace("xx","//",$zdjecie2);
		$zdjecie4 = str_replace("xxX","_",$zdjecie3);
		$zdjecie = str_replace("xxXX",".",$zdjecie4);
	
		$foto = Sklepy::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		$x = str_replace ( '/uploads2/' . $msg . '/fileform//', '', $zdjecie );
		$pozycja_konca = strpos ( $x, '/' );
		$numer_katalogu = substr ( $x, 0, $pozycja_konca );
		$katalog_do_usuniecia = 'uploads2/' . $msg . '/fileform//' . $numer_katalogu . '/';
		$katalog_do_usuniecia1 = 'uploads2/' . $msg . '/fileform//' . $numer_katalogu . '/thumb/';
		$katalog_do_usuniecia2 = 'uploads2/' . $msg . '/fileform//' . $numer_katalogu . '/original/';
		$katalog_do_usuniecia3 = 'uploads2/' . $msg . '/fileform//' . $numer_katalogu . '/cropped/';
		$katalog_do_usuniecia4 = 'uploads2/' . $msg . '/fileform//' . $numer_katalogu . '/large/';
		$katalog_do_usuniecia5 = 'uploads2/' . $msg . '/fileform//' . $numer_katalogu . '/small/';
			
		$plik = 'uploads2/' . $msg . '/fileform/' . $numer_katalogu . '/thumb';
		$plik2 = 'uploads2/' . $msg . '/fileform/' . $numer_katalogu . '/original';
		$plik4 = 'uploads2/' . $msg . '/fileform/' . $numer_katalogu . '/large';
		$plik5 = 'uploads2/' . $msg . '/fileform/' . $numer_katalogu . '/small';
		$plik3 = 'uploads2/' . $msg . '/fileform/' . $numer_katalogu . '/cropped';
				
					
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik2 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik2 . '/' . $dirFile );
					}
				}
		}		
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik4 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik4 . '/' . $dirFile );
					}
				}
		}
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik5 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik5 . '/' . $dirFile );
					}
				}
			}	

				$data_modyf = time();
				$sql1 = "Update sklepy  SET  datamodyf=:data_modyf ";
				$command = $connection->createCommand ( $sql1 );
				$command->bindParam ( ":data_modyf", $data_modyf, PDO::PARAM_INT );
				$command->execute ();
		
			$transaction->commit();	
				
			}	
			catch(Exception $e)
			{
				$transaction->rollback();
			}
						
		$data['dane'] =array(1);	
		echo json_encode($data);
		
	}
	
	
		
//-------------------------------------------------------------------------------------------------------
	
		
public function actionListaNiepracujace() {
	
		$id = $_GET['id'];
										
		$criteria = new CDbCriteria ();
		$criteria->condition= ' id_sklep = '.$id;	
		$dane2 = Niepracujace::model ()->findAll ( $criteria );
					
		$products1=array();
		$products1["records"]=array();
			
		foreach ( $dane2 as $name ) {
			$dzien2 =  date('Y-m-d', $name->dzien);
			$datawpr =  date('Y-m-d', $name->datawpr);
			$product_item=array("id" => $name->id, "dzien2" => $dzien2, "id_sklep"=>$name->id_sklep, "datawpr"=>$datawpr);
			array_push($products1["records"], $product_item);
			}
		$data['dane'] = array($products1);	
		echo json_encode($data);	
	}
		
public function actionDodajNiepracujacy() {
	
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
					
			$form_data = $_POST['form_data'];
			$tablica = json_decode($form_data, true);
			$id_sklep = $tablica['idsklep'];
			$dzien = strtotime($tablica['dzien']);
			$datawpr = time();
			
			$criteria = new CDbCriteria ();
			$criteria->condition= ' id_sklep = '.$id_sklep.' and dzien = '.$dzien;	
			$dane2 = Niepracujace::model ()->findAll ( $criteria );
			$liczba = count($dane2);
			if($liczba ==0)	
			{
			
				$sql1 = "INSERT INTO niepracujace (id_sklep, dzien, datawpr)	VALUES (:id_sklep,:dzien,:datawpr)";
				$command1 = $connection->createCommand ($sql1);
				$command1->bindParam ( ":id_sklep" , $id_sklep, PDO::PARAM_INT );
				$command1->bindParam ( ":dzien" , $dzien, PDO::PARAM_INT );
				$command1->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command1->execute ();
			}
		
			$transaction->commit();	
				
		}	
		catch(Exception $e)
		{
				$transaction->rollback();
		}
		
		$data['dane'] =array(1);	
		echo json_encode($data);	
	}

	public function actionUsunNiepracujacy() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			$id = $_GET['id'];
		
			$sql1 = "DELETE  FROM niepracujace WHERE id=:id";
			$command1 = $connection->createCommand ( $sql1 );
			$command1->bindParam ( ":id", $id, PDO::PARAM_INT );
			$command1->execute ();
		
			$transaction->commit();	
				
		}	
		catch(Exception $e)
		{
				$transaction->rollback();
		}

		$data = array(1);
		echo json_encode($data);					
			
		}
	
	
	
	
}
