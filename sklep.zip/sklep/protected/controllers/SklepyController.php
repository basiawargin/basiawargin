<?php
class SklepyController extends Controller {
	
	public $layout = '//layouts/column2';
	
	
	public function filters() {
		return array (
				'accessControl', 
				'postOnly + delete' 
		); 
	}
	
	
	public function accessRules() {
		return array (array ('allow', 'actions' => array ('index',"zdjecie"),	'users' => array ('*')));
	}
	
	
		
		public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 	
		$this->render ( 'index');
	}
	

		public function actionPobierzUzytkownikowDoSelect()
	{

		
		$iduser = Yii::app()->user->id; 
		
		$danez = User::model()->findByPk($iduser);
		$superuser = $danez->superuser;

		$products=array();
		$products["records"]=array();					
		
		if($superuser == 1)
		{
		$connection = Yii::app ()->db;	
				
		$sql = "SELECT DISTINCT * FROM users WHERE superuser = 1 or superuser = 2 ";
		$command = $connection->createCommand($sql);
		$command->execute ();
		$rows=$command->queryAll();
		}		
		elseif($superuser == 2)
		{
		$connection = Yii::app ()->db;	
		$sql = "SELECT DISTINCT * FROM users WHERE id =:iduser";
		$command = $connection->createCommand($sql);
		$command2->bindParam( ":iduser" , $iduser, PDO::PARAM_INT );
		$command->execute ();
		$rows=$command->queryAll();
		}		
		
		
		
		foreach ( $rows as $name ) {
						
			$product_item=array("id" => $name['id'],"username" => $name['username'] );
			array_push($products["records"], $product_item);
			
		}
		
					
		$data['dane'] =array($products);
		echo json_encode($data);
	}



	
	


		public function actionPobierzSklepy()
	{

		
		$page= $_GET['page'];
		$limit=20;
		
		if($_GET['iduser'] == '')
		{ $iduser = Yii::app()->user->id; }
		else {
		$iduser =$_GET['iduser'];
		}
 		

		if($_GET['idmarket'] != '')
		{ $market = ' idmarket = '.$_GET['idmarket']; }
		else { $market = 'id IS NOT NULL'; }

		$dane = User::model()->findByPk($iduser);
		$superuser = $dane->superuser;
		
		
		$criteria = new CDbCriteria ();
		$criteria->order = 'id DESC';
	
		if($superuser == 1) {
			
		$connection = Yii::app ()->db;	
		$sql = "SELECT DISTINCT * FROM sklepy WHERE iduser =  ".$iduser." and ".$market;
		$command = $connection->createCommand($sql);
		$command->execute ();
		$rows=$command->queryAll();

		}

		if($superuser == 2) {
		
			if($_GET['iduser'] == '')
			{
			$connection = Yii::app ()->db;	
			$sql = "SELECT DISTINCT * FROM sklepy WHERE  ".$market;
			$command = $connection->createCommand($sql);
			$command->execute ();
			$rows=$command->queryAll();
			} else {
			
			$connection = Yii::app ()->db;	
			$sql = "SELECT DISTINCT * FROM sklepy WHERE iduser =  ".$iduser." and ".$market;
			$command = $connection->createCommand($sql);
			$command->execute ();
			$rows=$command->queryAll();
			}

		}
	
		
		$liczba_wierszy = count($rows);
		$strony = ceil($liczba_wierszy/$limit);
		if($liczba_wierszy !== 0)
		{
					if($page > $strony) {
					$page = $page-1;
					
				} else { $page = $page; $start = ($page - 1) * $limit;}
		}
		else {
					$page=1;
					$start=0;
		}
		
		$connection = Yii::app ()->db;	
		if($superuser ==2)
		{ $sq2 = "SELECT DISTINCT * FROM sklepy  WHERE iduser =:iduser and ".$market." ORDER BY id DESC  LIMIT :zacznij, :limit_na_strone";
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":iduser" , $iduser, PDO::PARAM_INT );
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$sklepy2=$command2->queryAll();
		} 
		
		if($superuser ==1)
		{
			
		$sq2 = "SELECT DISTINCT * FROM sklepy WHERE iduser =  ".$iduser." and ".$market." ORDER BY id DESC  LIMIT :zacznij, :limit_na_strone";
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$sklepy2=$command2->queryAll();
		}
	
		
		
		$products1=array();
		$products1["records"]=array();
		foreach ( $sklepy2 as $name ) {
			$market = Markety::model()->findByPk($name['idmarket']);
			$kod = Kody::model()->findByPk($name['idkod']);	
			
			$product_item=array("id" => $name['id'],"nazwa" => $name['nazwa'],'miasto'=>$name['miasto'], 'kod'=>$kod->kod, 'market'=>$market['nazwa']);
			array_push($products1["records"], $product_item);
		}
			
		
		
		$products2=array();
		$products2["paging"]= array();
		$ab =array();	
		
		$url = Yii::app ()->params ['url'];

		for($xc=1; $xc<=$strony; $xc++)
		{
			if($xc == $page) {$z='yes';} else {$z = 'no';}
			$ab[] = array('page'=>$xc,'url'=>'http://'.$url.'/index.php/sklepy/PobierzSklepy/page/'.$xc.'/iduser/'.$iduser.'/idmarket/'.$_GET['idmarket'],'current_page'=>$z);
		}
		if($strony >4)
			{ $products2["paging"]= array('first'=>'http://'.$url.'/index.php/sklepy/PobierzSklepy/page/1/iduser/'.$iduser.'/idmarket/'.$_GET['idmarket'],
			'last'=>'http://'.$url.'/index.php/sklepy/PobierzSklepy/page/'.$strony.'/iduser/'.$iduser.'/idmarket/'.$_GET['idmarket']);	}
			else { $products2["paging"]= array('first'=>'', 'last'=>'');}
		
		$products2["paging"]["pages"]= $ab;	
		$products2["paging"]["liczba_rekordow"]= $liczba_wierszy;
		$products2["paging"]["page"]= $page;
			
			
			
		$data['dane'] =array($products1, $products2);
		echo json_encode($data);
	
	}
	
		public function actionPobierzSklepySelect()
	{

		if($_GET['iduser'] == '')
		{ $iduser = Yii::app()->user->id; }
		else { $iduser = $_GET['iduser']; }

		$dane = User::model()->findByPk($iduser);
		$superuser = $dane->superuser;
		$id_sklep = $dane->id_sklep;
		
		
		$criteria = new CDbCriteria ();
		$criteria->order = 'id DESC';
	
		if($superuser == 2) {
			$criteria->condition= 'iduser = '.$iduser;	
			$sklepy = Sklepy::model ()->findAll ( $criteria );

		}
		else  
		{ 
			$sklepy = Sklepy::model ()->findAll ();
					
		}
		
		$products1=array();
		$products1["records"]=array();
		foreach ( $sklepy as $name ) {
		
			
		$product_item=array("id" => $name['id'],"nazwa" => $name['nazwa']);
		array_push($products1["records"], $product_item);	
		
		}
					
		$data['dane'] =array($products1);
		echo json_encode($data);
	
	}
	
	
	public function actionDodajSklep()
	{
		
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		$idmarket = $tablica["idmarket"];
		$nazwa = $tablica["nazwa"];
		$ulica = $tablica["ulica"];
		$numer = $tablica["numer"];
		$miasto = $tablica["miasto"];
		$kraj = $tablica["kraj"];
		$kod = $tablica["kod"];
		$is_actual = $tablica["is_actual"];
		$godziny1 = $tablica["godziny1"];
		$godziny2 = $tablica["godziny2"];
		$godziny3 = $tablica["godziny3"];
		$godziny4 = $tablica["godziny4"];
		$godziny5 = $tablica["godziny5"];
		$godziny6 = $tablica["godziny6"];
		
		$errors = array();
		$errors['godz1']='NO';
		$errors['godz2']='NO';
		$errors['godz3']='NO';
	
		
				
		//---------------------------------------------------------------------
		if($godziny1 > $godziny2)
		{ $errors['godz1']='TAK';}
	
		if($godziny3 > $godziny4)
		{ $errors['godz2']='TAK'; }
	
		if($godziny5 > $godziny6)
		{ $errors['godz3']='TAK';}
	
	
	
		
		if( ($godziny2 - $godziny1 == 0) )
		{ $errors['godz1']='TAK';}
			
		if( ($godziny4 - $godziny3 == 0))
		{ $errors['godz2']='TAK';}
	
		if( ($godziny6 - $godziny5 == 0))
		{ $errors['godz3']='TAK';}
	
		
	
	
		if($godziny1 == 1 and $godziny2 !== 1 )	{$errors['godz1']='TAK'; }
		if($godziny1 !== 1 and $godziny2 == 1 )	{ $errors['godz1']='TAK';}
				
		if($godziny3 == 1 and $godziny4 !== 1 )	{ $errors['godz2']='TAK';}
		if($godziny3 !== 1 and $godziny4 == 1 )	{$errors['godz2']='TAK'; }
		
		if($godziny5 == 1 and $godziny6 !== 1 )	{$errors['godz3']='TAK'; }
		if($godziny5 !== 1 and $godziny6 == 1 )	{$errors['godz3']='TAK'; }
		
		
	
		if( ($godziny1==1 and $godziny2 == 1) )
		{ $errors['godz1']='NO';}
	
		if( ($godziny3==1 and $godziny4 == 1) )
		{ $errors['godz2']='NO';}
	
		if( ($godziny5==1 and $godziny6 == 1) )
		{ $errors['godz3']='NO';}
	
	
	
		//------------------------------------------------------------------------
		
		
		$data_wprowadzenia = date('Y-m-d H:i:s'); $data_wpr = strtotime($data_wprowadzenia);	
		$data_modyfikacji = 1;
		$iduser = Yii::app()->user->id;
		
		if($errors['godz1'] == 'NO' and $errors['godz2'] == 'NO' and $errors['godz3'] == 'NO')
		{
						
				
				$sql1 = "INSERT INTO sklepy (iduser,idmarket, nazwa, ulica, numer, miasto, kraj,  is_actual, datawpr, datamodyf,godziny1, godziny2, godziny3, godziny4, godziny5, godziny6, kod)
				VALUES (:iduser, :idmarket, :nazwa,  :ulica, :numer, :miasto, :kraj,  :is_actual, :datawpr, :datamodyf, :godziny1, :godziny2, :godziny3, :godziny4, :godziny5, :godziny6,  :kod )";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":nazwa" , $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":ulica" , $ulica, PDO::PARAM_STR );
				$command->bindParam ( ":numer" , $numer, PDO::PARAM_STR );
				$command->bindParam ( ":miasto" , $miasto, PDO::PARAM_STR );
				$command->bindParam ( ":kraj" , $kraj, PDO::PARAM_STR );
				$command->bindParam ( ":is_actual" , $is_actual, PDO::PARAM_STR );
				$command->bindParam ( ":datawpr" , $data_wpr, PDO::PARAM_INT );
				$command->bindParam ( ":datamodyf" , $data_modyfikacji, PDO::PARAM_INT );
				$command->bindParam ( ":godziny1" , $godziny1, PDO::PARAM_INT );
				$command->bindParam ( ":godziny2" , $godziny2, PDO::PARAM_INT );
				$command->bindParam ( ":godziny3" , $godziny3, PDO::PARAM_INT );
				$command->bindParam ( ":godziny4" , $godziny4, PDO::PARAM_INT );
				$command->bindParam ( ":godziny5" , $godziny5, PDO::PARAM_INT );
				$command->bindParam ( ":godziny6" , $godziny6, PDO::PARAM_INT );
				$command->bindParam ( ":iduser" , $iduser, PDO::PARAM_INT );
				$command->bindParam ( ":idmarket" , $idmarket, PDO::PARAM_INT );
				$command->bindParam ( ":kod" , $kod, PDO::PARAM_STR );
				$command->execute ();
				
				$komunikat1 ='OK';
		} else 
		{
			$komunikat1 ='NO';
		}			
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}	
			
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);		
	
				
	}	
	
	public function actionUsunSklep() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_GET['id'];
		$sql = "DELETE  FROM sklepy WHERE id=:id";
		$command = $connection->createCommand ( $sql );
		$command->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command->execute ();
				
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}
		$data['dane'] =array(1);	
		echo json_encode($data);	
	}
	
		
	public function actionPobierzSklep() {
		
		$id = $_GET['id'];	
		$name = Sklepy::model ()->findByPk($id);
					
		$products1=array();
		$products1["records"]=array();
		
	
		$jednostka = array (
			0 => '00:00',
			1800 => '00:30',
			1800 * 2 => '01:00',
			1800 * 3 => '01:30',
			1800 * 4 => '02:00',
			1800 * 5 => '02:30',
			1800 * 6 => '03:00',
			1800 * 7 => '03:30',
			1800 * 8 => '04:00',
			1800 * 9 => '04:30',
			1800 * 10 => '05:00',
			1800 * 11 => '05:30',
			1800 * 12 => '06:00',
			1800 * 13 => '06:30',
			1800 * 14 => '07:00',
			1800 * 15 => '07:30',
			1800 * 16 => '08:00',
			1800 * 17 => '08:30',
			1800 * 18 => '09:00',
			1800 * 19 => '09:30',
			1800 * 20 => '10:00',
			1800 * 21 => '10:30',
			1800 * 22 => '11:00',
			1800 * 23 => '11:30',
			1800 * 24 => '12:00',
			1800 * 25 => '12:30',
			1800 * 26 => '13:00',
			1800 * 27 => '13:30',
			1800 * 28 => '14:00',
			1800 * 29 => '14:30',
			1800 * 30 => '15:00',
			1800 * 31 => '15:30',
			1800 * 32 => '16:00',
			1800 * 33 => '16:30',
			1800 * 34 => '17:00',
			1800 * 35 => '17:30',
			1800 * 36 => '18:00',
			1800 * 37 => '18:30',
			1800 * 38 => '19:00',
			1800 * 39 => '19:30',
			1800 * 40 => '20:00',
			1800 * 41 => '20:30',
			1800 * 42 => '21:00',
			1800 * 43 => '21:30',
			1800 * 44 => '22:00',
			1800 * 45 => '22:30',
			1800 * 46 => '23:00',
			1800 * 47 => '23:30',
			1800 * 48 => '24:00'
		);
			
					
		$x1 = $name->godziny1; $y1 = $name->godziny2;
		$x2 = $name->godziny3; $y2 = $name->godziny4;
		$x3 = $name->godziny5; $y3 = $name->godziny6;
		
	
		
		foreach($jednostka as $key => $value)
		{
			if($key == $x1) { $g1 = $value; }
			if($key == $y1) { $g2 = $value; }
			if($key == $x2) { $g3 = $value; }
			if($key == $y2) { $g4 = $value; }
			if($key == $x3) { $g5 = $value; }
			if($key == $y3) { $g6 = $value; }
			
		}
		
		
		if($x1== 1)
		{ $robocze='';} else {$robocze = $g1." -  ".$g2;} 
	
		if($x2 == 1)
		{ $sobota='';} else {$sobota = $g3." -  ".$g4; } 
	
	
		if($x3 == 1)
		{ $niedziela='';} else {$niedziela = $g5."-  ".$g6; } 
						
						
		
		
		if($name->datamodyf == 1) {$data_modyf = date('Y-m-d H:i',$name->datamodyf);}  else { $data_modyf = 'Brak danych';}
		
		$data_wpr= date('Y-m-d H:i', $name->datawpr);
		$market = Markety::model ()->findByPk($name->idmarket);
		$product_item=array(
			"id" => $name->id,
			"nazwa" => $name->nazwa,
			"idmarket" => $name->idmarket,
			"iduser" => $name->iduser,
			"miasto" => $name->miasto,
			"kraj"=>$name->kraj,
			"ulica"=>$name->ulica,
			"numer"=>$name->numer,
			"kod" => $name->kod,
			"kraj"=>$name->kraj,
			'is_actual'=>$name->is_actual,
			"data_wprowadzenia"=>$data_wpr,
			"data_modyfikacji"=>$data_modyf,
			"godziny_robocze"=>$robocze,
			"godziny_sobota"=>$sobota,
			"godziny_niedziela"=>$niedziela,
			"godziny1"=>$name->godziny1,
			"godziny2"=>$name->godziny2,
			"godziny3"=>$name->godziny3,
			"godziny4"=>$name->godziny4,
			"godziny5"=>$name->godziny5,
			"godziny6"=>$name->godziny6,
			"market"=>$market->nazwa
			 
			);
			array_push($products1["records"], $product_item);
			
			//
			$products2=array();
			$products2["records"]=array();
			
			$markety = Markety::model ()->findAll();
			foreach($markety as $name2)
			{
				if($name2->id == $name->idmarket) {$checked ='on';} else { $checked = 'off';}
				$product_item2=array("id" => $name2->id,"nazwa" => $name2->nazwa,"checked" => $checked);
				
				array_push($products2["records"], $product_item2);
			}
		$data['dane'] =array($products1,$products2);	
		echo json_encode($data);
	
	
	}

	
	
	
	public function actionZmienSklep() {
		
				
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {		
				
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		$idmarket = $tablica["idmarket"];
		$iduser = $tablica["iduser"];
		$id = $tablica["id"];
		$nazwa = $tablica["nazwa"];
		$ulica = $tablica["ulica"];
		$numer = $tablica["numer"];
		$miasto = $tablica["miasto"];
		$kraj = $tablica["kraj"];
		$kod = $tablica["kod"];
		
		$is_actual = $tablica["is_actual"];
		$godziny1 = $tablica["godziny1"];
		$godziny2 = $tablica["godziny2"];
		$godziny3 = $tablica["godziny3"];
		$godziny4 = $tablica["godziny4"];
		$godziny5 = $tablica["godziny5"];
		$godziny6 = $tablica["godziny6"];
		$godziny7 = $tablica["godziny7"];
		$godziny8 = $tablica["godziny8"];
		
		
		$errors = array();
		$errors['godz1']='NO';
		$errors['godz2']='NO';
		$errors['godz3']='NO';
		
		
		if($godziny1 > $godziny2)
		{ $errors['godz1']='TAK';}
	
		if($godziny3 > $godziny4)
		{ $errors['godz2']='TAK'; }
	
		if($godziny5 > $godziny6)
		{ $errors['godz3']='TAK';}
	
	
		
		if( ($godziny2 - $godziny1 == 0) )
		{ $errors['godz1']='TAK';}
			
		if( ($godziny4 - $godziny3 == 0))
		{ $errors['godz2']='TAK';}
	
		if( ($godziny6 - $godziny5 == 0))
		{ $errors['godz3']='TAK';}
	
		
	
		if($godziny1 == 1 and $godziny2 !== 1 )	{$errors['godz1']='TAK'; }
		if($godziny1 !== 1 and $godziny2 == 1 )	{ $errors['godz1']='TAK';}
				
		if($godziny3 == 1 and $godziny4 !== 1 )	{ $errors['godz2']='TAK';}
		if($godziny3 !== 1 and $godziny4 == 1 )	{$errors['godz2']='TAK'; }
		
		if($godziny5 == 1 and $godziny6 !== 1 )	{$errors['godz3']='TAK'; }
		if($godziny5 !== 1 and $godziny6 == 1 )	{$errors['godz3']='TAK'; }
		
	
	
		if( ($godziny1==1 and $godziny2 == 1) )
		{ $errors['godz1']='NO';}
	
		if( ($godziny3==1 and $godziny4 == 1) )
		{ $errors['godz2']='NO';}
	
		if( ($godziny5==1 and $godziny6 == 1) )
		{ $errors['godz3']='NO';}
	
		
				
			
		$data_modyfikacji = date('Y-m-d H:i:s'); $data_modyf = strtotime($data_modyfikacji);
					

		if($errors['godz1'] == 'NO' and $errors['godz2'] == 'NO' and $errors['godz3'] == 'NO')
		{
		
				
		$sql1 = "UPDATE sklepy SET idmarket=:idmarket, iduser=:iduser, nazwa =:nazwa, miasto=:miasto, ulica=:ulica, numer=:numer, kraj=:kraj,kod=:kod,
				is_actual=:is_actual,datamodyf=:datamodyf, 
				godziny1 =:godziny1,godziny2 =:godziny2,godziny3 =:godziny3,godziny4 =:godziny4,godziny5 =:godziny5,godziny6 =:godziny6,
				idmarket=:idmarket, iduser=:iduser WHERE id=:id";
							
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":nazwa" , $nazwa, PDO::PARAM_STR );
				$command->bindParam ( ":ulica" , $ulica, PDO::PARAM_STR );
				$command->bindParam ( ":numer" , $numer, PDO::PARAM_STR );
				$command->bindParam ( ":miasto" , $miasto, PDO::PARAM_STR );
				$command->bindParam ( ":kraj" , $kraj, PDO::PARAM_STR );
				$command->bindParam ( ":kod" , $kod, PDO::PARAM_STR );
				$command->bindParam ( ":is_actual" , $is_actual, PDO::PARAM_STR );
				$command->bindParam ( ":datamodyf" , $data_modyf, PDO::PARAM_INT );
				$command->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command->bindParam ( ":godziny1" , $godziny1, PDO::PARAM_INT );
				$command->bindParam ( ":godziny2" , $godziny2, PDO::PARAM_INT );
				$command->bindParam ( ":godziny3" , $godziny3, PDO::PARAM_INT );
				$command->bindParam ( ":godziny4" , $godziny4, PDO::PARAM_INT );
				$command->bindParam ( ":godziny5" , $godziny5, PDO::PARAM_INT );
				$command->bindParam ( ":godziny6" , $godziny6, PDO::PARAM_INT );
				$command->bindParam ( ":iduser" , $iduser, PDO::PARAM_INT );
				$command->bindParam ( ":idmarket" , $idmarket, PDO::PARAM_INT );
				$command->execute ();
				$komunikat1='OK';
		}else{
			$komunikat1='NO';
		}
			
				$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}			
		
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);
		
	}
	
	
	public function actionZmienSklep2() {
		
				
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {		
		
		$errors = array();
		$errors['plat']='NO';
				
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		
		$id = $tablica["id"];
		$data_modyfikacji = date('Y-m-d H:i:s'); $data_modyf = strtotime($data_modyfikacji);
		$pos_id = $tablica['pos_id'];
		$marchant_id = $tablica['marchant_id'];
		$CustomerId = $tablica['CustomerId'];
		$MerchantPosId = $tablica['MerchantPosId'];


		if($pos_id==0) {$pos_id = null; }
		if($marchant_id==0) {$marchant_id = null; }
		if($CustomerId==0) {$CustomerId = null; }
		if($MerchantPosId==0) {$MerchantPosId = null; }
				
		if (is_numeric($pos_id) and !is_numeric($marchant_id)){ $errors['plat']='TAK';} 
		if (!is_numeric($pos_id) and is_numeric($marchant_id)){$errors['plat']='TAK';} 
		if (is_numeric($CustomerId) and !is_numeric($MerchantPosId)){ $errors['plat']='TAK';} 
		if (!is_numeric($CustomerId) and is_numeric($MerchantPosId)){$errors['plat']='TAK';} 
					
		$data_modyfikacji = date('Y-m-d H:i:s'); $data_modyf = strtotime($data_modyfikacji);
		if($errors['plat'] =='NO')
		{
			$sql1 = "UPDATE sklepy SET datamodyf=:data_modyfikacji,	pos_id =:pos_id,marchant_id =:marchant_id,CustomerId =:CustomerId,MerchantPosId =:MerchantPosId	WHERE id=:id";
			$command1 = $connection->createCommand ($sql1);
			$command1->bindParam ( ":data_modyfikacji" , $data_modyf, PDO::PARAM_INT );
			$command1->bindParam ( ":id" , $id, PDO::PARAM_INT );
			$command1->bindParam ( ":pos_id" , $pos_id, PDO::PARAM_INT );
			$command1->bindParam ( ":marchant_id" , $marchant_id, PDO::PARAM_INT );
			$command1->bindParam ( ":CustomerId" , $CustomerId, PDO::PARAM_INT );
			$command1->bindParam ( ":MerchantPosId" , $MerchantPosId, PDO::PARAM_INT );
			$command1->execute ();
			$komunikat1 ='OK';
		}
		else {
		$komunikat1 = 'NO';
		}		
			$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}			
			
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);
		
	}
	
	
//-------------------------------------------------------------------------------------------------------
	
		
public function actionListaNiepracujace() {
	
		$id = $_GET['id'];
										
		$criteria = new CDbCriteria ();
		$criteria->condition= ' id_sklep = '.$id;	
		$dane2 = Niepracujace::model ()->findAll ( $criteria );
					
		$products1=array();
		$products1["records"]=array();
			
		foreach ( $dane2 as $name ) {
			$dzien2 =  date('Y-m-d', $name->dzien);
			$datawpr =  date('Y-m-d', $name->datawpr);
			$product_item=array("id" => $name->id, "dzien2" => $dzien2, "id_sklep"=>$name->id_sklep, "datawpr"=>$datawpr);
			array_push($products1["records"], $product_item);
			}
		$data['dane'] = array($products1);	
		echo json_encode($data);	
	}
		
public function actionDodajNiepracujacy() {
	
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
					
			$form_data = $_POST['form_data'];
			$tablica = json_decode($form_data, true);
			$id_sklep = $tablica['idsklep'];
			$dzien = strtotime($tablica['dzien']);
			$datawpr = time();
			
			$criteria = new CDbCriteria ();
			$criteria->condition= ' id_sklep = '.$id_sklep.' and dzien = '.$dzien;	
			$dane2 = Niepracujace::model ()->findAll ( $criteria );
			$liczba = count($dane2);
			if($liczba ==0)	
			{
			
				$sql1 = "INSERT INTO niepracujace (id_sklep, dzien, datawpr)	VALUES (:id_sklep,:dzien,:datawpr)";
				$command1 = $connection->createCommand ($sql1);
				$command1->bindParam ( ":id_sklep" , $id_sklep, PDO::PARAM_INT );
				$command1->bindParam ( ":dzien" , $dzien, PDO::PARAM_INT );
				$command1->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command1->execute ();
			}
		
			$transaction->commit();	
				
		}	
		catch(Exception $e)
		{
				$transaction->rollback();
		}
		
		$data['dane'] =array(1);	
		echo json_encode($data);	
	}

	public function actionUsunNiepracujacy() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			$id = $_GET['id'];
		
			$sql1 = "DELETE  FROM niepracujace WHERE id=:id";
			$command1 = $connection->createCommand ( $sql1 );
			$command1->bindParam ( ":id", $id, PDO::PARAM_INT );
			$command1->execute ();
		
			$transaction->commit();	
				
		}	
		catch(Exception $e)
		{
				$transaction->rollback();
		}

		$data = array(1);
		echo json_encode($data);					
			
		}
	
	
	
	
}
