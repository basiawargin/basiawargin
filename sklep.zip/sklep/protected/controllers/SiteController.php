<?php
class SiteController extends Controller {
	

	
	/**
	 * Declares class-based actions.
	 */
	public function actions() {
		return array (
				
				'captcha'=>array(
						'class'=>'CCaptchaAction',
						'backColor'=>0xFFFFFF,
					),
				
				// page action renders "static" pages stored under 'protected/views/site/pages'
				// They can be accessed via: index.php?r=site/page&view=FileName
				'page' => array (
						'class' => 'CViewAction',
						
				) 
		);
	}
	
	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	 
	
	 public function actionRegister() {
		 $this->layout = 'adminlayout';
		 $this->render ( 'admin', array());
	 } 
	 
	public function actionIndex() {
		
		
		
		$idmarket = $_REQUEST['idmarket'];
		if($idmarket != '')
		{
			
				$kategorie = array();
				$kategorie['records'] = array();
				$criteria = new CDbCriteria ();	
				$criteria->condition = ' kateglowna IS NULL';	
				$dane2 = Kategorie::model ()->findAll ( $criteria );
				
				foreach($dane2 as $name)
				{	
						
				$tab = array("id"=>$name['id'],"nazwa"=>$name['nazwa'],"katalog"=>$name['katalog'],'podkategorie'=>$products2);
				array_push($kategorie['records'], $tab);
				
				}
		}
		
						
		if($_REQUEST['kod'])
		{
			$kod = $_REQUEST['kod'];	
			$dane = Sklepy::model()->findAllByAttributes(array("kod"=>$kod));
			$idmarket = $_REQUEST['idmarket'];
			if($idmarket != '')
			{
			
				$kategorie = array();
				$kategorie['records'] = array();
				$criteria = new CDbCriteria ();	
				$criteria->condition = ' kateglowna IS NULL';	
				$dane2 = Kategorie::model ()->findAll ( $criteria );
				
				foreach($dane2 as $name)
				{	
						
				$tab = array("id"=>$name['id'],"nazwa"=>$name['nazwa'],"katalog"=>$name['katalog'],'podkategorie'=>$products2);
				array_push($kategorie['records'], $tab);
				
				}
			}
		}
		else {}
		
		
		
		if(isset($_POST['szukaj']))
		{
				
		$kod = $_POST['kod'];	
		$dane = Sklepy::model()->findAllByAttributes(array("kod"=>$kod));
		$idmarket = "";	
		$kategorie = array();
		$kategorie['records'] = array();
		} 
		
		
			
		$this->render ( 'index', array("dane"=>$dane, "kod" =>$kod,"idmarket"=>$idmarket,"kategorie"=>$kategorie)  );
		
	}



	

	
	
	public function actionError() {
		if ($error = Yii::app ()->errorHandler->error) {
			if (Yii::app ()->request->isAjaxRequest)
				echo $error ['message'];
			else
				$this->render ( 'error', $error );
		}
	}
	
	
	public function actionContact() {
		$model = new ContactForm ();
		if (isset ( $_POST ['ContactForm'] )) {
			$model->attributes = $_POST ['ContactForm'];
			if ($model->validate ()) {
				$name = '=?UTF-8?B?' . base64_encode ( $model->name ) . '?=';
				$subject = '=?UTF-8?B?' . base64_encode ( $model->subject ) . '?=';
				$headers = "From: $name <{$model->email}>\r\n" . "Reply-To: {$model->email}\r\n" . "MIME-Version: 1.0\r\n" . "Content-Type: text/plain; charset=UTF-8";
				
				mail ( Yii::app ()->params ['adminEmail'], $subject, $model->body, $headers );
				Yii::app ()->user->setFlash ( 'contact', 'Thank you for contacting us. We will respond to you as soon as possible.' );
				$this->refresh ();
			}
		}
		$this->render ( 'contact', array (
				'model' => $model 
		) );
	}
	
	
	public function actionLogin() {
		$model = new LoginForm ();
		
		// if it is ajax validation request
		if (isset ( $_POST ['ajax'] ) && $_POST ['ajax'] === 'login-form') {
			echo CActiveForm::validate ( $model );
			Yii::app ()->end ();
		}
		
		// collect user input data
		if (isset ( $_POST ['LoginForm'] )) {
			$model->attributes = $_POST ['LoginForm'];
			// validate user input and redirect to the previous page if valid
			if ($model->validate () && $model->login ())
				$this->redirect ( Yii::app ()->user->returnUrl );
		}
		// display the login form
		$this->render ( 'login', array (
				'model' => $model 
		) );
	}
	
	/**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout() {
		Yii::app ()->user->logout ();
		$this->redirect ( Yii::app ()->homeUrl );
	}
	
	

		
		
		
}
