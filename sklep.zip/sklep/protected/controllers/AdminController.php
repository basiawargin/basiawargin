<?php
class AdminController extends Controller {
	
	
	public function actions() {
		return array (
				
				'captcha' => array (
						'class' => 'CCaptchaAction',
						'backColor' => 0xFFFFFF 
				),
				'page' => array (
						'class' => 'CViewAction' 
				) 
		);
	}
	public function filters() {
		return array (
				'accessControl', 
				'ajaxOnly +  ' 
		);
	}
	
	
	 
	 public function actionAdmin() {
		 $this->layout = 'adminlayout';
		 $this->render ( 'admin');
	 }
	
	
	
	
}
