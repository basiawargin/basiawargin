<?php
class RozmiaryController extends Controller {
	
	public $layout = '//layouts/column2';
	
	
	public function filters() {
		return array (
				'accessControl', 
				'postOnly + delete' 
		); 
	}
	
	
	public function accessRules() {
		return array (
				array (
						'allow', 
						'actions' => array (
								'index',
						),
						'users' => array (
								'*' 
						) 
				),
				
		);
	}
	
	
		
		public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 	
		$this->render ( 'index');
	}
	
	
	

		public function actionListaRozmiarow()
	{
		$id= $_GET['id'];
		$rozmiary = Rozmiary::model ()->findAllByAttributes (array('idprodukt'=>$id));
				
		$products1=array();
		$products1["records"]=array();
		$connection = Yii::app ()->db;
		foreach ( $rozmiary as $name ) {
			
			
		
		$sql1 = "SELECT * FROM ceny WHERE idrozmiar =:id ORDER BY id DESC LIMIT 0,1";
		$command = $connection->createCommand ($sql1);
		$command->bindParam ( ":id" , $name['id'], PDO::PARAM_INT );
		$command->execute ();
		$DaneZBazy = $command->query();
		while(($Rekord=$DaneZBazy->read())!==false)
		{
				$cena= $Rekord['cena'];
				$waluta= $Rekord['waluta'];
				$upust= $Rekord['upust'];
				$vat= $Rekord['vat'];
				$dataceny = date('Y-m-d H:i',$Rekord['datawpr']);
		}
				
		if($name['datamodyf'] == 1) {$datamodyf = date('Y-m-d H:i',$name['datamodyf']);}  else { $datamodyf = 'Brak danych';}
		$datawpr= date('Y-m-d H:i', $name['datawpr']);

		$plik = 'uploads3/'. $name['katalog'];											
		if (file_exists ( $plik )) {
			
				$data2 = CFileHelper::findFiles ( $plik );
				$l = count($data2);
				if($l >0)
				{$y = str_replace ( '\\', '/', $data2[3] );
				$img = Yii::app ()->request->baseUrl . '/' . $y;}
				else {$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';	}	
							
				} else {
	
				$img = Yii::app ()->request->baseUrl . '/images/blanck.jpg';					
		} 

		
		$product_item=array("id" => $name['id'],
		"jednostka" => $name['jednostka'],
		"rozmiar"=>$name['rozmiar'], 
		"idprodukt"=>$name['idprodukt'], 
		"idsklep"=>$name['idsklep'],
		"idmarket"=>$name['idmarket'],
		"katalog"=>$name['katalog'],
		"datawpr"=>$datawpr,
		"dataodyf"=>$dataodyf,
		"cena"=>$cena,
		"waluta"=>$waluta,
		"upust"=>$upust,
		"vat"=>$vat,
		"dataceny"=>$dataceny,
		"img"=>$img,
		"id"=>$name['id']
		);
		array_push($products1["records"], $product_item);	
		$idprodukt=$name['idprodukt'];
		}
		
		$products2=array();
		$products2["records"]=array();
		$produkt = Produkty::model ()->findByPk ($idprodukt);
		$t2=array("id" => $name->id,"nazwa" => $produkt->nazwa);
		array_push($products2["records"], $t2);
		
		$data['dane'] =array($products1,$products2);	
		echo json_encode($data);	
		
	}
	
		public function actionPobierzRozmiar()
	{
		$id= $_GET['id'];
		$name = Rozmiary::model ()->findByPk($id);
				
		$products1=array();
		$products1["records"]=array();
		
		$plik = 'uploads3/' . $name->katalog. '/fileform/';			
			if (file_exists ( $plik )) {
			
			
					$data2 = CFileHelper::findFiles ( $plik );
					$y = str_replace ( '\\', '/', $data2 [1] );
					$img = Yii::app ()->request->baseUrl . '/' . $y;
							
			} else {
								
					$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
					$img = '<img src="'.$x2.'" />';
			}	
			
		
		$connection = Yii::app ()->db;
		$sql1 = "SELECT * FROM ceny WHERE idrozmiar =:id ORDER BY id DESC LIMIT 0,1";
		$command = $connection->createCommand ($sql1);
		$command->bindParam ( ":id" , $id, PDO::PARAM_INT );
		$command->execute ();
		$DaneZBazy = $command->query();
		while(($Rekord=$DaneZBazy->read())!==false)
		{
				$cena= $Rekord['cena'];
				$waluta= $Rekord['waluta'];
				$upust= $Rekord['upust'];
				$vat= $Rekord['vat'];
				$dataceny = date('Y-m-d H:i',$Rekord['datawpr']);
		}
		
		if($name->datamodyf == 1) {$datamodyf = date('Y-m-d H:i',$name->datamodyf);}  else { $datamodyf = 'Brak danych';}
		$datawpr= date('Y-m-d H:i', $name->datawpr);
		
		$product_item=array("id" => $id,
		"jednostka" => $name->jednostka,
		"rozmiar"=>$name->rozmiar, 
		"idprodukt"=>$name->idprodukt, 
		"idsklep"=>$name->idsklep,
		"idmarket"=>$name->idmarket,
		"katalog"=>$name->katalog,
		"datawpr"=>$datawpr,
		"dataodyf"=>$dataodyf,
		"cena"=>$cena,
		"waluta"=>$waluta,
		"upust"=>$upust,
		"vat"=>$vat,
		"img"=>$img,
		"dataceny"=>$dataceny
		);
		array_push($products1["records"], $product_item);	
		
		
		$data['dane'] =array($products1);	
		echo json_encode($data);	
		
	}
	
	public function actionDodajRozmiar()
	{
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		
		$idprodukt = $tablica["idprodukt"];
		$jednostka = $tablica["jednostka"];
		$rozmiar = $tablica["rozmiar"];

		$datawpr = time(); 	
		$cena = $tablica["cena"];	
		$waluta = $tablica["waluta"];	
		$upust = $tablica["upust"];	
		$vat = $tablica["vat"];	
		$produkt = Produkty::model ()->findByPk ($idprodukt);	
		$idsklep = $produkt->idsklep;
		$logo = 'r'.$tablica["rozmiar"].$idprodukt;
		
				$sql1 = "INSERT INTO rozmiary (idprodukt, idmarket, katalog, datawpr, rozmiar, jednostka)	VALUES (:idprodukt, :idmarket, :katalog, :datawpr, :rozmiar, :jednostka)";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":idprodukt" , $idprodukt, PDO::PARAM_INT );
				$command->bindParam ( ":idmarket" , $produkt->idmarket, PDO::PARAM_INT );
				$command->bindParam ( ":rozmiar" , $rozmiar, PDO::PARAM_INT );
				$command->bindParam ( ":jednostka" , $jednostka, PDO::PARAM_STR );
				$command->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command->bindParam ( ":katalog" , $logo, PDO::PARAM_STR );
				$command->execute ();
				
						
				$sql2="SELECT id FROM rozmiary WHERE katalog = :logo";
				$command2 = $connection->createCommand ($sql2);	
				$command2->bindParam ( ":logo" , $logo, PDO::PARAM_STR );
				$command2->execute ();
				$DaneZBazy = $command2->query();
				while(($Rekord=$DaneZBazy->read())!==false)
				{
				$id= $Rekord['id'];
				}
			
				$logo2= 'kat'.$id;
				$sql3 = "UPDATE rozmiary SET katalog =:logo WHERE id=:id";
				$command3 = $connection->createCommand ($sql3);
				$command3->bindParam ( ":logo" , $logo2, PDO::PARAM_STR );
				$command3->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command3->execute ();
				
				$sql4 = "INSERT INTO ceny (idprodukt, idrozmiar,cena, datawpr, upust, waluta,vat )	VALUES	(:idprodukt, :idrozmiar,:cena,  :datawpr,:upust,:waluta, :vat)";
				$command4 = $connection->createCommand ($sql4);
				$command4->bindParam ( ":idprodukt" , $idprodukt, PDO::PARAM_INT );
				$command4->bindParam ( ":idrozmiar" , $id, PDO::PARAM_INT );
				$command4->bindParam ( ":cena" , $cena, PDO::PARAM_STR );
				$command4->bindParam ( ":waluta" , $waluta, PDO::PARAM_STR );
				$command4->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command4->bindParam ( ":upust" , $upust, PDO::PARAM_INT );
				$command4->bindParam ( ":vat" , $vat, PDO::PARAM_INT );
				$command4->execute ();
					
				
				$komunikat1 ='OK';
				$transaction->commit();	
				
			}	
			catch(Exception $e)
			{
				$transaction->rollback();
			}
	
		
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);		
					
	}	
	public function actionUsunRozmiar() {
		
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
			
		$id = $_GET['id'];
		$sql = "DELETE  FROM rozmiary WHERE id=:id";
		$command = $connection->createCommand ( $sql );
		$command->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command->execute ();
		
		$sql2 = "DELETE  FROM ceny WHERE idrozmiar=:id";
		$command2 = $connection->createCommand ( $sql2 );
		$command2->bindParam ( ":id", $id, PDO::PARAM_INT );
		$command2->execute ();
		
				
		$transaction->commit();
				
		} catch ( Exception $e ) {
				$transaction->rollback ();
		}
		$data['dane'] =array(1);	
		echo json_encode($data);	
	}
	
	public function actionZmienRozmiar()
	{
			$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
		
		
		
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
		
		$id = $tablica["id"];
		$jednostka = $tablica["jednostka"];
		$rozmiar = $tablica["rozmiar"];

		$datawpr = time(); 	
		$cena = $tablica["cena"];	
		$waluta = $tablica["waluta"];	
		$upust = $tablica["upust"];	
		$vat = $tablica["vat"];	
		$datamodyf = time();
		$r = Rozmiary::model ()->findByPk ($id);
		
				$sql1 = "UPDATE rozmiary  SET datamodyf=:datamodyf, rozmiar=:rozmiar, jednostka=:jednostka WHERE id=:id";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command->bindParam ( ":rozmiar" , $rozmiar, PDO::PARAM_INT );
				$command->bindParam ( ":jednostka" , $jednostka, PDO::PARAM_STR );
				$command->bindParam ( ":datamodyf" , $datamodyf, PDO::PARAM_INT );
				$command->execute ();
							
				$sql4 = "INSERT INTO ceny (idprodukt, idrozmiar, cena, datawpr, upust, waluta,vat )	VALUES	(:idprodukt, :idrozmiar,:cena,  :datawpr,:upust,:waluta, :vat)";
				$command4 = $connection->createCommand ($sql4);
				$command4->bindParam ( ":idprodukt" , $r->idprodukt, PDO::PARAM_INT );
				$command4->bindParam ( ":idrozmiar" , $id, PDO::PARAM_INT );
				$command4->bindParam ( ":cena" , $cena, PDO::PARAM_STR );
				$command4->bindParam ( ":waluta" , $waluta, PDO::PARAM_STR );
				$command4->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command4->bindParam ( ":upust" , $upust, PDO::PARAM_INT );
				$command4->bindParam ( ":vat" , $vat, PDO::PARAM_INT );
				$command4->execute ();
					
				
				$komunikat1 ='OK';
				$transaction->commit();	
				
			}	
			catch(Exception $e)
			{
				$transaction->rollback();
			}
	
		
		$products=array();
		$products["komunikat"]= $komunikat1;	
	
		$data['dane'] =array($products);	
		echo json_encode($data);		
					
	}	
	
	
//fotografie
	
	
	
	public function actionDodajZdjecieRozmiar() {
		
		$connection = Yii::app ()->db;
		
		$id = $_POST['id'];
		$foto = Rozmiary::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		$documentroot = $_SERVER ['DOCUMENT_ROOT'];
		$username = '/uploads3/' . $foto->katalog;
		$baseDirectory = 'uploads3/' . $foto->katalog;
		
		if (file_exists ( $documentroot . "/" . $username )) {
		} else {
			mkdir ( $documentroot . "/" . $username, 0777 );
		}
		
		$model2 = new Fileform ();
		$model2->katalog = $msg;
		$model2->baseDirectory = 'uploads3/' . $msg . '/';
		
		$model2->file = 'uploads3/' . $msg . '/';
		$model2->images = 'd';	
		$model2->name ='d';
		$model2->attributes = 'd';


		$images = new CUploadedFile($_FILES['myfile']['name'], $_FILES['myfile']['tmp_name'], $_FILES['myfile']['type'], $_FILES['myfile']['size'], $_FILES['myfile']['error']);
      	$is = 'df';
		$model2->image = $images;
		
		
			if ($images) {
				// Clean up the filename
				$uglyName = strtolower ( $model2->name );
				$mediocreName = preg_replace ( '/[^a-zA-Z0-9]+/', '_', $uglyName );
				$beautifulName = trim ( $mediocreName, '_' ) . "." . $is;
				$model2->image_name = $beautifulName;
				$im = 'jpg';
				$newName = md5 ( microtime ( true ) ) . '_' . $model2->name . "." . $im;
			}
						
			if ($model2->save()){
		
				
				if ($images) {
					
					Yush3::init ( $model2, $msg ); // this will build the nessesary structure
					                     
					// Nothing has been uploaded yet but YUSH will return a full path that can be used to save the resource
					$originalPath = Yush3::getPath ( $model2, Yush3::SIZE_ORIGINAL, $newName );
					$largePath = Yush3::getPath ( $model2, Yush3::SIZE_LARGE, $newName );
					$smallPath = Yush3::getPath ( $model2, Yush3::SIZE_SMALL, $newName );
					$thumbPath = Yush3::getPath ( $model2, Yush3::SIZE_THUMB, $newName );
					
					// Save the original resource to disk
					
					$images->saveAs ( $originalPath );
					
					// Create a large image
					$largeImage = Yii::app ()->phpThumb->create ( $originalPath );
					$largeImage->resize ( 700, 400 );
					$largeImage->save ( $largePath );
					
					$x2 = 'images/znak1.jpg';
					
					$x = $originalPath;
					$x3 = $largePath;
					$size2 = getimagesize ( $x );
					$skala = $size2 [0] / $size2 [1];
					
					$watermark = imagecreatefromjpeg ( $x2 );
					$watermark_width = imagesx ( $watermark );
					$watermark_height = imagesy ( $watermark );
					
					$size = getimagesize ( $x2 );
					
					if ($skala < 1) {
						$dest_x = $size [0] - $watermark_width + 90;
						$dest_y = $size [1] - $watermark_height + 170;
					} else {
						$dest_x = $size [0] - $watermark_width + 470;
						$dest_y = $size [1] - $watermark_height + 290;
					}
					
					$image = imagecreatefromjpeg ( $x );
					$image2 = imagecreatefromjpeg ( $x3 );
					imagecopymerge ( $image, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 25 );
					imagecopymerge ( $image2, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 25 );
					imagejpeg ( $image, $x );
					imagejpeg ( $image2, $x3 );
					
					imagedestroy ( $image );
					imagedestroy ( $image2 );
					imagedestroy ( $watermark );
					
					// Create a small image
					$smallImage = Yii::app ()->phpThumb->create ( $originalPath );
					$smallImage->resize ( 405, 220 );
					$smallImage->save ( $smallPath );
					
					// Create a thumbnail
					$thumbImage = Yii::app ()->phpThumb->create ( $originalPath );
					$thumbImage->resize ( 350, 200 );
					$thumbImage->save ( $thumbPath );
					
					}
	
					
				}
				
			
		$data =1;
		echo json_encode($data);
	}
	
	public function actionListaZdjecRozmiar() {
				
			$id = $_POST['id'];
			$foto = Rozmiary::model ()->findByPk($id);
			$plik = 'uploads3/'.$foto->katalog .'/fileform/';
			$nazwa = $foto->rozmiar. $foto->jednostka;				
			$products=array();
			$products["records"]=array();
																
			if (file_exists ( $plik )) {
			
				$data2 = CFileHelper::findFiles ( $plik );
					$liczba = count ( $data2 );
					$tab = array ();
					$numer = 0;
					for($x = 1; $x < $liczba;) {
					$y = str_replace ( '\\', '/', $data2 [$x] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
					$tab [] = $x2;
					$x = $x + 4;
					$numer ++;
					}
				} else {
								
				$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
				$img = '<img src="'.$x2.'" />';
				$numer='x';
				}
			$product_item=array("numer" => $numer,"img" => $x2, "id"=>$id,"nazwa"=>$nazwa);
			array_push($products["records"], $product_item);
		
				
			$data["dane"]= array($products);	
			echo json_encode($data);
	}

	public function actionZdjecieRozmiar()
	{
			
			$zdjeciex = $_GET['zdjecie'];
			$tab = explode("-",$zdjeciex);
		
			$zdjecie1 = $tab[2];
			$id = $tab[1];
	
			$zdjecie2 = str_replace("x","/",$zdjecie1);
			$zdjecie3 = str_replace("xx","//",$zdjecie2);
			$zdjecie4 = str_replace("xxX","_",$zdjecie3);
			$zdjecie = str_replace("xxXX",".",$zdjecie4);
	
			$foto = Rozmiary::model ()->findByPk ( $id );
			$msg = $foto->katalog;
		
			$x = str_replace ( '/uploads3/' . $msg . '/fileform//', '', $zdjecie );
			$pozycja_konca = strpos ( $x, '/' );
			$numer_katalogu = substr ( $x, 0, $pozycja_konca );
			$katalog1 = 'uploads/' . $msg . '/fileform//' . $numer_katalogu . '/';
																	
			if (file_exists ( $katalog1 )) {
			
			
				$data2 = CFileHelper::findFiles ( $katalog1 );
					$liczba = count ( $data2 );
					$tabx = array ();
					$numer = 0;
					for($x = 1; $x < $liczba;) {
					$y = str_replace ( '\\', '/', $data2[$x] );
					$x2 = Yii::app ()->request->baseUrl . '/' . $y;
					$tabx [] = $x2;
					$x = $x + 4;
					$numer ++;
								
					
					}
				} else {
								
				$x2 = Yii::app ()->request->baseUrl . '/images/blanck.jpg';
				$img = '<img src="'.$x2.'" />';
				$product_item=array(
				"numer" => 'x',
				"img" => $x2,
				
				);
			
			}
			
		$this->render('zdjecie',array('zdjecie'=>$x2));
	}
	public function actionSprawdzenieLiczby()
	{
		
		$id = $_POST['id'];
		$foto = Rozmiary::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		// Sprawdzenie czy jest już jedno zdjęcie
		if(file_exists('uploads3/' . $foto->katalog.'/fileform/'))
		{	
		$plik = 'uploads3/' . $foto->katalog . '/fileform/';											
		$data2 = CFileHelper::findFiles ( $plik );
		$liczba_zdjec = count($data2)/4+1;
						
		} else {$liczba_zdjec =1;}
		
		$data = array('liczba'=>$liczba_zdjec);
		echo json_encode($data);
	}
	
	
	public function actionUsunZdjecieRozmiar() {
	
		$connection = Yii::app ()->db;
		$transaction = $connection->beginTransaction ();
		try {
	
		$usun = $_POST['usun'];
		$tab = explode("-",$usun);
		
		$zdjecie1 = $tab[2];
		$id = $tab[1];
	
		$zdjecie2 = str_replace("x","/",$zdjecie1);
		$zdjecie3 = str_replace("xx","//",$zdjecie2);
		$zdjecie4 = str_replace("xxX","_",$zdjecie3);
		$zdjecie = str_replace("xxXX",".",$zdjecie4);
	
		$foto = Rozmiary::model ()->findByPk ( $id );
		$msg = $foto->katalog;
		
		$x = str_replace ( '/uploads3/' . $msg . '/fileform//', '', $zdjecie );
		$pozycja_konca = strpos ( $x, '/' );
		$numer_katalogu = substr ( $x, 0, $pozycja_konca );
		$katalog_do_usuniecia = 'uploads3/' . $msg . '/fileform//' . $numer_katalogu . '/';
		$katalog_do_usuniecia1 = 'uploads3/' . $msg . '/fileform//' . $numer_katalogu . '/thumb/';
		$katalog_do_usuniecia2 = 'uploads3/' . $msg . '/fileform//' . $numer_katalogu . '/original/';
		$katalog_do_usuniecia3 = 'uploads3/' . $msg . '/fileform//' . $numer_katalogu . '/cropped/';
		$katalog_do_usuniecia4 = 'uploads3/' . $msg . '/fileform//' . $numer_katalogu . '/large/';
		$katalog_do_usuniecia5 = 'uploads3/' . $msg . '/fileform//' . $numer_katalogu . '/small/';
			
		$plik = 'uploads3/' . $msg . '/fileform/' . $numer_katalogu . '/thumb';
		$plik2 = 'uploads3/' . $msg . '/fileform/' . $numer_katalogu . '/original';
		$plik4 = 'uploads3/' . $msg . '/fileform/' . $numer_katalogu . '/large';
		$plik5 = 'uploads3/' . $msg . '/fileform/' . $numer_katalogu . '/small';
		$plik3 = 'uploads3/' . $msg . '/fileform/' . $numer_katalogu . '/cropped';
				
					
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik2 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik2 . '/' . $dirFile );
					}
				}
		}		
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik4 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik4 . '/' . $dirFile );
					}
				}
		}
		if ($dirHandle = opendir ( $plik )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
					
						unlink ( $plik . '/' . $dirFile );
					}
				}
		}			
		if ($dirHandle = opendir ( $plik5 )) {
				
				$rmDir = true;
				while ( false !== ($dirFile = readdir ( $dirHandle )) ) {
					if ($dirFile != "." && $dirFile != "..") {
						unlink ( $plik5 . '/' . $dirFile );
					}
				}
			}	

				$data_modyf = time();
				$sql1 = "Update rozmiary  SET  data_modyf=:data_modyf ";
				$command = $connection->createCommand ( $sql1 );
				$command->bindParam ( ":data_modyf", $data_modyf, PDO::PARAM_INT );
				$command->execute ();
		
			$transaction->commit();	
				
			}	
			catch(Exception $e)
			{
				$transaction->rollback();
			}
						
		$data["dane"]= array(1);	
		echo json_encode($data);
		
	}
	

	
}
