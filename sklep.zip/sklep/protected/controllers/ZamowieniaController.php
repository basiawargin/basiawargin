<?php
class ZamowieniaController extends Controller {
	
	public $layout = '//layouts/column2';
	
	
	public function filters() {
		return array (
				'accessControl', 
				'postOnly + delete' 
		); 
	}
	
	
	public function accessRules() {
		return array (array ('allow', 'actions' => array ('index'),	'users' => array ('*')));
	}
	
	
		
		public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 	
		$this->render ( 'index');
	}
	

	public function actionPobierzUzytkownikowDoSelectNadzor()
	{

		
		$iduser = Yii::app()->user->id; 
		
		$danez = User::model()->findByPk($iduser);
		$superuser = $danez->superuser;

		$products=array();
		$products["records"]=array();					
		
		if($superuser == 1)
		{
		$connection = Yii::app ()->db;	
				
		$sql = "SELECT DISTINCT * FROM users WHERE  superuser= 2";
		$command = $connection->createCommand($sql);
		$command->execute ();
		$rows=$command->queryAll();
		}		
				
		
		
		
		foreach ( $rows as $name ) {
						
			$product_item=array("id" => $name['id'],"username" => $name['username'] );
			array_push($products["records"], $product_item);
			
		}
		
					
		$data['dane'] =array($products);
		echo json_encode($data);
	}





		public function actionPobierzZamowienia()
	{

		
		$page= $_GET['page'];
		$limit=20;
		
		if($_GET['iduser'] == '')
		{ $iduser = Yii::app()->user->id; }
		else {
		$iduser =$_GET['iduser'];
		}
 		
		$dane = User::model()->findByPk($iduser);
		$superuser = $dane->superuser;
		
			
		$connection = Yii::app ()->db;
		if($superuser == 1) {
			
			
		$sql = "SELECT DISTINCT * FROM zamowienia " ;
		$command = $connection->createCommand($sql);
		$command->execute ();
		$rows=$command->queryAll();

		}
		
		
		if($superuser == 2) {
		$sql = "SELECT DISTINCT K.id, K.kod, P.id, P.iduser, P.idkod FROM kody AS K JOIN punkty AS P  ON K.id = P.idkod JOIN zamowienia AS Z ON Z.idkod = K.id WHERE P.iduser=:iduser";
		$command = $connection->createCommand($sql);
		$command->bindParam( ":iduser" , $iduser, PDO::PARAM_INT );
		$command->execute ();
		$rows=$command->queryAll();
		}
	
		if($superuser == 3) {
			
		$connection = Yii::app ()->db;	
		$sql = "SELECT DISTINCT * FROM zamowienia WHERE zadanie =  ".$iduser ;
		$command = $connection->createCommand($sql);
		$command->execute ();
		$rows=$command->queryAll();

		}
	
		$liczba_wierszy = count($rows);
		$strony = ceil($liczba_wierszy/$limit);
		if($liczba_wierszy !== 0)
		{
					if($page > $strony) {
					$page = $page-1;
					
				} else { $page = $page; $start = ($page - 1) * $limit;}
		}
		else {
					$page=1;
					$start=0;
		}
		
		$connection = Yii::app ()->db;	
		
		if($superuser ==1)
		{ 
		$sq2 = "SELECT DISTINCT * FROM zamowienia    ORDER BY id DESC  LIMIT :zacznij, :limit_na_strone";
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$zamowienia=$command2->queryAll();
		} 
		
		if($superuser ==2)
		{ 
		$sq2 = "SELECT DISTINCT K.id AS idk, K.kod, P.id AS idp, P.iduser, P.idkod, Z.id AS id, Z.datawpr, Z.datadostawy, Z.idkod, Z.imie, Z.nazwisko, Z.adres, Z.miasto, Z.cena, Z.upust, Z.produkty, Z.telefon  FROM kody AS K JOIN punkty AS P  ON K.id = P.idkod JOIN zamowienia AS Z ON Z.idkod = K.id WHERE P.iduser=:iduser  ORDER BY Z.id DESC  LIMIT :zacznij, :limit_na_strone";
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":iduser" , $iduser, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$zamowienia=$command2->queryAll();
		} 
		
		if($superuser ==3)
		{ 
		$sq2 = "SELECT DISTINCT * FROM zamowienia  WHERE zadanie =:iduser  ORDER BY id DESC  LIMIT :zacznij, :limit_na_strone";
		$command2 = $connection->createCommand($sq2);
		$command2->bindParam( ":iduser" , $iduser, PDO::PARAM_INT );
		$command2->bindParam( ":zacznij" , $start, PDO::PARAM_INT );
		$command2->bindParam( ":limit_na_strone" , $limit, PDO::PARAM_INT );
		$command2->execute ();
		$zamowienia=$command2->queryAll();
		} 
		
		$produkty = array();
		
		$products1=array();
		$products1["records"]=array();
		
		foreach ($zamowienia as $name ) {
			
			$prod = explode(",", $name['produkty']);
		
			$new_array = array();
			foreach ($prod as $user) {
				
			$nums = explode('-',$user);
			$new_array[$nums[0]] = $nums[1];
			}
			
			
			
			for($x=0; $x<count($prod); $x++)
			{
				$rozmiary = Rozmiary::model ()->findByPk($prod[$x]);
				$produktyx = Produkty::model ()->findByPk($rozmiary->idprodukt);	
				$produkty[] =$produktyx->nazwa;	
			}
			$kod = Kody::model ()->findByPk($name['idkod']);	

			$datawpr = date("Y-m-d H:i:s", $name['datawpr']);
			$datadostawy = date("Y-m-d H:i:s", $name['datadostawy']);
			
			$product_item=array("id" => $name['id'],"datawpr" => $datawpr,"datadostawy"=>$datadostawy,
			"produkty"=>$produkty, "adres"=>$name['adres'],"telefon"=>$name['telefon'],"kod"=>$kod->kod, "miasto"=>$name["miasto"],"cena"=>$name['cena'], "vat"=>$name['vat'], "upust"=>$name["upust"]);
			array_push($products1["records"], $product_item);
		}
			
		
		
		$products2=array();
		$products2["paging"]= array();
		$ab =array();	
		
		$url = Yii::app ()->params ['url'];

		for($xc=1; $xc<=$strony; $xc++)
		{
			if($xc == $page) {$z='yes';} else {$z = 'no';}
			$ab[] = array('page'=>$xc,'url'=>'http://'.$url.'/index.php/zamowienia/PobierzZamowienia/page/'.$xc,'current_page'=>$z);
		}
		if($strony >4)
			{ $products2["paging"]= array('first'=>'http://'.$url.'/index.php/zamowienia/PobierzZamowienia/page/1',
			'last'=>'http://'.$url.'/index.php/zamowienia/PobierzZamowienia/page/'.$strony);	}
			else { $products2["paging"]= array('first'=>'', 'last'=>'');}
		
		$products2["paging"]["pages"]= $ab;	
		$products2["paging"]["liczba_rekordow"]= $liczba_wierszy;
		$products2["paging"]["page"]= $page;
			
			
			
		$data['dane'] =array($products1, $products2);
		echo json_encode($data);
	
	}
	
	
	public function actionDodajZamowienie()
	{
			
		$connection = Yii::app ()->db;
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
	
		$adres = $tablica["adres"];
		$miasto = $tablica["miasto"];
		$kod = $tablica["kod"];
		$imie = $tablica["imie"];
		$nazwisko = $tablica["nazwisko"];
		$datadostawy = strtotime($tablica["datadostawy"]);
		$telefon = $tablica["telefon"];

		$produkty = $tablica["produkty"];
		
		$upust = 1;
				
		//------------------------------------------------------------------------
				
		$data_wprowadzenia = date('Y-m-d H:i:s'); $datawpr = strtotime($data_wprowadzenia);	
		
		$iduser = Yii::app()->user->id;
		$kody = Kody::model ()->findAllByAttributes(array('kod'=>$kod));
		$tab=array();
		foreach($kody as $name)
		{
			$tab[]= $name['id'];
		}
	
				
		$sql1 = "INSERT INTO zamowienia (iduser, datawpr,produkty,imie, nazwisko,adres, idkod, miasto,  upust,  datadostawy, telefon )
				VALUES (:iduser, :datawpr,  :produkty, :imie, :nazwisko, :adres, :idkod, :miasto, :upust,  :datadostawy, :telefon)";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":nazwisko" , $nazwisko, PDO::PARAM_STR );
				$command->bindParam ( ":imie" , $imie, PDO::PARAM_STR );
				$command->bindParam ( ":iduser" , $iduser, PDO::PARAM_INT );
				$command->bindParam ( ":adres" , $adres, PDO::PARAM_STR );
				$command->bindParam ( ":telefon" , $telefon, PDO::PARAM_STR );
				$command->bindParam ( ":miasto" , $miasto, PDO::PARAM_STR );
				$command->bindParam ( ":produkty" , $produkty, PDO::PARAM_STR );
				$command->bindParam ( ":datawpr" , $datawpr, PDO::PARAM_INT );
				$command->bindParam ( ":datadostawy" , $datadostawy, PDO::PARAM_INT );
				$command->bindParam ( ":idkod" , $tab[0], PDO::PARAM_INT );
				$command->bindParam ( ":upust" , $upust, PDO::PARAM_INT );
				
				$command->execute ();
		
		$data['dane'] =array(1);	
		echo json_encode($data);		
					
	}	

	
	public function actionPobierzZamowienie() {
		
		$id = $_GET['id'];	
		$namex = Zamowienia::model ()->findByPk($id);
					
		$products1=array();
		$products1["records"]=array();

		
		$datawpr= date('Y-m-d H:i', $namex->datawpr);
		$datadostawy= date('Y-m-d H:i', $namex->datadostawy);
		if($namex->zrealizowano)
		{$zrealizowano= date('Y-m-d H:i', $namex->zrealizowano);} else {$zrealizowano ='-';}

		$prod = explode("=>", $namex->produkty);
		
		$products2=array();
		$products2["records"]= array();
		$new_array = array();
		$l = count($prod) -1;
		for($cc=0; $cc<$l; $cc++)
		{
			$prod2 = explode(',',$prod[$cc]);
						
			$d1 = Rozmiary::model ()->findByPk($prod2[0]);
			$d2= Produkty::model ()->findByPk($d1->idprodukt);
			
			$new_array['id'] = $prod2[0];
			$new_array['ilosc'] = $prod2[1];
			$new_array['cena'] = $prod2[2];
			$new_array['nazwa'] = $d2->nazwa;
			$new_array['jednostka'] = $d1->jednostka;
			$new_array['vat'] = $prod2[3];
			$new_array['upust'] = $prod2[4];
			
		
			array_push($products2["records"], $new_array);
		
		}
		
		
		
		
		
		$kod = Kody::model ()->findByPk($namex->idkod);
		if($namex->zadanie)
		{$zadanie = User::model ()->findByPk($namex->zadanie); $zadanie2 = $zadanie->username; 
		$datazadania= date('Y-m-d H:i', $namex->datazadania);
		} else { $zadanie2 ='-'; $datazadania ='-';}
		
						
		$product_item=array(
			"id" => $namex->id,
			"nazwisko" => $namex->nazwisko,
			"imie" => $namex->imie,
			"adres" => $namex->adres,
			"kod" => $kod->kod,
			"miasto" => $namex->miasto,
			"datawpr"=>$datawpr,
			"datadostawy"=>$datadostawy,
			"produkty" => $products2,
			"cena" => $namex->cena,
			"datazadania"=>$datazadania,
			"zrealizowano"=>$zrealizowano,
			"zadanie"=>$zadanie2
			);
		array_push($products1["records"], $product_item);
			
		
		
		
	$data['dane'] =array($products1);	
	echo json_encode($data);	
	
	
	}

	
	public function actionUstalZadanie()
	{
			
		$connection = Yii::app ()->db;
		$form_data = $_POST['form_data'];
		$tablica = json_decode($form_data, true);
	
		$id = $tablica["id"];
		$iduser = $tablica["iduser"];
						
		//------------------------------------------------------------------------
				
		$data_wprowadzenia = date('Y-m-d H:i:s'); $datazadania = strtotime($data_wprowadzenia);	
		
				
		$sql1 = "UPDATE zamowienia SET zadanie=:iduser, datazadania=:datazadania WHERE id =:id";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":datazadania" , $datazadania, PDO::PARAM_INT );
				$command->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command->bindParam ( ":iduser" , $iduser, PDO::PARAM_INT );
				
				$command->execute ();
		
		$data['dane'] =array(1);	
		echo json_encode($data);		
					
	}	

	public function actionZrealizowano()
	{
			
		$connection = Yii::app ()->db;
		
		$id = $_GET['id'];
		$data_wprowadzenia = date('Y-m-d H:i:s'); $datarealizacji = strtotime($data_wprowadzenia);	
		
				
		$sql1 = "UPDATE zamowienia SET  zrealizowano=:zrealizowano  WHERE id =:id";
				$command = $connection->createCommand ($sql1);
				$command->bindParam ( ":zrealizowano" , $datarealizacji, PDO::PARAM_INT );
				$command->bindParam ( ":id" , $id, PDO::PARAM_INT );
				$command->execute ();
		
		$data['dane'] =array(1);	
		echo json_encode($data);		
					
	}	
	
	
}
