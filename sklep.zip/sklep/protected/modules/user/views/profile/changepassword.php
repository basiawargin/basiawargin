<p class="clearfix"></p>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="heading"><h3><?php echo UserModule::t('Twoj profil'); ?></h3>
            
        </div>
    </div>
</div>

<p class="clearfix"></p>

<div class="section padding-bot50">
    <div class="container">
        <h6 class="margin-top20"></h6>
		<div class="collapse navbar-collapse" id="navbar-menu">
       </div><!-- /.navbar-collapse -->	
		<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
		<?php

$form = $this->beginWidget ( 'UActiveForm', array (
		'id' => 'changepassword-form',
		'enableAjaxValidation' => true 
) );
?>

	<p class="note"><?php echo UserModule::t('Pola oznaczone <span class="required">*</span> sa wymagane.'); ?></p>
	<?php echo CHtml::errorSummary($model); ?>
	
	<div class="row">
	<?php echo $form->labelEx($model,'haslo'); ?>
	<?php echo $form->passwordField($model,'password'); ?>
	<?php echo $form->error($model,'password'); ?>
	<p class="hint">
	<?php echo UserModule::t("Haslo minimum 4 znaki."); ?>
	</p>
	</div>

	<div class="row">
	<?php echo $form->labelEx($model,'Powtorz haslo'); ?>
	<?php echo $form->passwordField($model,'verifyPassword'); ?>
	<?php echo $form->error($model,'verifyPassword'); ?>
	</div>


	<div class="row submit">
	<?php echo CHtml::submitButton(UserModule::t("Zapisz")); ?>
	</div>

<?php $this->endWidget(); ?>	
					
		</div>
		<p class="clearfix"></p>
		
	</div>
</div>
