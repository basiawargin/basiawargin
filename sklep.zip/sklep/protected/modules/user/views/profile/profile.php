
<div class="sub-agile">
	<p><?php if(Yii::app()->user->hasFlash('profileMessage')): ?>
		<?php echo Yii::app()->user->getFlash('profileMessage'); ?>
		
		<?php endif; ?></p>
				
		
</div>

