<p class="clearfix"></p>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="heading"><h3>Profil użytkownika</h3>
            <p>Wtym miejscu możesz zmienić swoje dane konta. Pola oznaczone * są wymagane. </p>
        </div>
	</div>
</div>

<p class="clearfix"></p>

<div class="section padding-bot50">
    <div class="container">
        <h6 class="margin-top20"></h6>
		<div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
             
            </ul>
        </div><!-- /.navbar-collapse -->	
		<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 form">
		  
		
<?php if(Yii::app()->user->hasFlash('profileMessage')): ?>
<div class="success">
<?php echo Yii::app()->user->getFlash('profileMessage'); ?>
</div>
<?php endif; ?>

<?php

$form = $this->beginWidget ( 'UActiveForm', array (
		'id' => 'profile-form',
		'enableAjaxValidation' => true,
		'htmlOptions' => array (
				'enctype' => 'multipart/form-data' 
		) 
) );
?>

	

	<?php echo $form->errorSummary(array($model,$profile)); ?>

<?php
$profileFields = $profile->getFields ();
if ($profileFields) {
	foreach ( $profileFields as $field ) {
		?>
	<div class="row">
		<?php
		
		echo $form->labelEx ( $profile, $field->varname );
		
		if ($field->widgetEdit ( $profile )) {
			echo $field->widgetEdit ( $profile );
		} elseif ($field->range) {
			echo $form->dropDownList ( $profile, $field->varname, Profile::range ( $field->range ) );
		} elseif ($field->field_type == "TEXT") {
			echo $form->textArea ( $profile, $field->varname, array (
					'rows' => 6,
					'cols' => 50 
			) );
		} else {
			echo $form->textField ( $profile, $field->varname, array (
					'size' => 60,
					'maxlength' => (($field->field_size) ? $field->field_size : 255) 
			) );
		}
		echo $form->error ( $profile, $field->varname );
		?>
	</div>	
			<?php
	}
}
?>
	<div class="row">
		<?php echo $form->labelEx($model,'nick'); ?>
		<?php echo $form->textField($model,'username',array('size'=>20,'maxlength'=>20)); ?>
		<?php echo $form->error($model,'username'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'email'); ?>
		<?php echo $form->textField($model,'email',array('size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'email'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? UserModule::t('Utwórz') : UserModule::t('Zapisz')); ?>
	</div>

<?php $this->endWidget(); ?>


<!-- form -->
				
							

          
 
		</div>
		<p class="clearfix"></p>
		
	</div>
</div>
 

