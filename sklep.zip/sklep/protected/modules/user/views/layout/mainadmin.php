
<?php $this->beginContent(UserBW::module()->appLayout); ?>
<?php echo $content; ?>
<?php $this->endContent(); ?>
