
<?php $this->beginContent(UserBW::module()->logLayout); ?>
<?php echo $content; ?>
<?php $this->endContent(); ?>
