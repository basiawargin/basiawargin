<div class="col-lg-12 col-md-4 col-sm-4 col-xs-12">
    <div class="x_panel">
        <div class="x_title">
		<?php
		$id = $_GET['id']; 
		
		$dane = User::model ()->findByPk($id);
		$id_uzytkownika = $dane->id_uzytkownika;
	
		$dane2 = Uzytkownicy::model ()->findByPk($id_uzytkownika);
		$nazwa_uzytkownika = $dane2->nazwa;
		
		?>
            <h2>Użytkownik konta - punkt sprzedaży  <?php echo $nazwa_uzytkownika ?><small></small></h2>
            
            <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <div class="dashboard-widget-content">
				<?php 		$id_user=Yii::app()->user->id;
									$dane = User::model()->findbyPk($id_user);
									if($dane->superuser == 2 or $dane->superuser == 3) {
					  ?>
				
					
				
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/usun_user?id=<?php echo $id ?>&id_uzytkownika=<?php echo $id_uzytkownika ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Usuń  użytkownika </a>
				</div>
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/user/admin/update2?id=<?php echo $id ?>&id_uzytkownika=<?php echo $id_uzytkownika ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Zmień dane </a>
				</div>	
				
				
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/user/admin/create2/id/<?php echo $id_uzytkownika ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span>Dodaj nowego użytkownika dla <?php echo $nazwa_uzytkownika ?></a>
				</div>	
					   <?php
						} else {}
						?>
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/index" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Lista punktów sprzedaży</a>
				</div>		
			<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/lista?id_uzytkownika=<?php echo $id_uzytkownika ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Lista użytkowników  <?php echo $nazwa_uzytkownika ?></a>
				</div>	
				<?php
$ust1 = User::model ()->findAllByAttributes ( array('id'=> $model->id ));
foreach($ust1 as $name1) {$id_uzytkownika = $name1->id_uzytkownika; } 

$dane = Uzytkownicy::model ()->findAllByAttributes ( array('id'=> $id_uzytkownika ));
foreach($dane as $name) {$nazwa = $name->nazwa; } ?>		
		
 <?php
$attributes = array (
		'id',
		'username' 
);

$profileFields = ProfileField::model ()->forOwner ()->sort ()->findAll ();
if ($profileFields) {
	foreach ( $profileFields as $field ) {
		array_push ( $attributes, array (
				'label' => UserModule::t ( $field->title ),
				'name' => $field->varname,
				'type' => 'raw',
				'value' => (($field->widgetView ( $model->profile )) ? $field->widgetView ( $model->profile ) : (($field->range) ? Profile::range ( $field->range, $model->profile->getAttribute ( $field->varname ) ) : $model->profile->getAttribute ( $field->varname ))) 
		) );
	}
}

array_push ( $attributes,
'id',

array(             
'name'=>'id_uzytkownika',
'value'=>$nazwa,
),

 'email',

 array (
		'name' => 'Data utworzenia',
		'value' => date ( "d.m.Y H:i:s", $model->createtime ) 
), array (
		'name' => 'Ostatnia wizyta',
		'value' => (($model->lastvisit) ?  date ( "d.m.Y H:i:s", $model->lastvisit ) : UserModule::t ( "Nieobecny" )) 
), array (
		'name' => 'Superuser',
		'value' => User::itemAlias ( "AdminStatus", $model->superuser ) 
)
,

 array (
		'name' => 'Status',
		'value' => User::itemAlias ( "UserStatus", $model->status ) 
),


array (
		'name' => 'Uzytkownik ID',
		'value' =>  $model->id_uzytkownika  
)
 );

$this->widget ( 'zii.widgets.CDetailView', array (
		'data' => $model,
		'attributes' => $attributes 
) );

?>

	
			
				
			</div>
		</div>
	</div>
</div>
	



