<p class="clearfix"></p>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="heading"><h3>Administracja użytkownikami</h3>
            <p>  </p>
        </div>
    </div>
</div>

<p class="clearfix"></p>

<div class="section padding-bot50">
    <div class="container">
        <h6 class="margin-top20"></h6>
		<div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
               <?php
if (count ( $list )) {
	foreach ( $list as $item )
		echo "<li>" . $item . "</li>";
}
?>
	<li><?php echo CHtml::link(UserModule::t('Dodaj nowego użytkownika'),array('create')); ?></li>
	             
              
        </div><!-- /.navbar-collapse -->
		<p class="clearfix"></p>
		
		<div class="col-lg-12 col-md-6 col-xs-12 col-sm-12">
            
<?php

$this->widget ( 'zii.widgets.grid.CGridView', array (
		'dataProvider' => $dataProvider,
		'columns' => array (
				array (
						'name' => 'id',
						'type' => 'raw',
						'value' => 'CHtml::link(CHtml::encode($data->id),array("admin/update","id"=>$data->id))' 
				),
				array (
						'name' => 'username',
						'type' => 'raw',
						'value' => 'CHtml::link(CHtml::encode($data->username),array("admin/view","id"=>$data->id))' 
				),
				array (
						'name' => 'email',
						'type' => 'raw',
						'value' => 'CHtml::link(CHtml::encode($data->email), "mailto:".$data->email)' 
				),
				array (
						'name' => 'createtime',
						'value' => 'date("d.m.Y H:i:s",$data->createtime)' 
				),
				array (
						'name' => 'endtime',
						'value' => 'date("d.m.Y H:i:s",$data->endtime)' 
				),
				array (
						'name' => 'status',
						'value' => 'User::itemAlias("UserStatus",$data->status)' 
				),
				array (
						'name' => 'superuser',
						'value' => 'User::itemAlias("AdminStatus",$data->superuser)' 
				),
				array (
						'name' => 'dostawca',
						'value' => 'User::itemAlias("DostawcaStatus",$data->dostawca)' 
				),
				array (
						'name' => 'paytime',
						'value' => 'date("d.m.Y H:i:s",$data->paytime)' 
				),
				array (
						'class' => 'CButtonColumn' 
				) 
		) 
) );
?>
		
		</div>
		
	</div>
</div>


