<div class="col-lg-12 col-md-4 col-sm-4 col-xs-12">
    <div class="x_panel">
        <div class="x_title">
		<?php
		$id = $_GET['id'];
		$dane = Uzytkownicy::model ()->findByPk(array('id'=>$id));
		$nazwa_uzytkownika = $dane->nazwa; 

		?>
            <h2>Użytkownicy konta - punkt sprzedaży  <?php echo $nazwa_uzytkownika ?><small><?php echo $liczba ?></small></h2>
           
            <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <div class="dashboard-widget-content">
								
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/index" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Lista punktów sprzedazy</a>
				</div>
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/lista?id_uzytkownika=<?php echo $id ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Lista użytkowników <?php echo $nazwa_uzytkownika ?></a>
				</div>
				<?php
				echo $this->renderPartial ( '_form', array (
				'model' => $model,
				'profile' => $profile 
				) );
				?>
				
		
			</div>
		</div>
	</div>
</div>
	


















