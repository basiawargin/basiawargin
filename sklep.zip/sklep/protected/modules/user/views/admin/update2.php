<div class="col-lg-12 col-md-4 col-sm-4 col-xs-12">
    <div class="x_panel">
        <div class="x_title">
		<?php
		$id = $_GET['id']; 
		
		$dane = User::model ()->findByPk($id);
		$id_uzytkownika = $dane->id_uzytkownika;
	
		$dane2 = Uzytkownicy::model ()->findByPk($id_uzytkownika);
		$nazwa_uzytkownika = $dane2->nazwa;
		
		?>
            <h2>Użytkownik konta - punkt sprzedaży  <?php echo $nazwa_uzytkownika ?><small></small></h2>
            
            <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <div class="dashboard-widget-content">
				<?php 		$id_user=Yii::app()->user->id;
									$dane = User::model()->findbyPk($id_user);
									if($dane->superuser == 2 or $dane->superuser == 3) {
					  ?>
				
					
				
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/usun_user?id=<?php echo $id ?>&id_uzytkownika=<?php echo $id_uzytkownika ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Usuń  użytkownika </a>
				</div>			
					
				
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/user/admin/create2/id/<?php echo $id_uzytkownika ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span>Dodaj nowego użytkownika dla <?php echo $nazwa_uzytkownika ?></a>
				</div>	
					   <?php
						} else {}
						?>
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/index" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Lista punktów sprzedaży</a>
				</div>
				<div class='right-button-margin'>
					<a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/uzytkownicy/lista?id_uzytkownika=<?php echo $id_uzytkownika ?>" class="btn btn-primary pull-right">
					<span class='glyphicon glyphicon-list'></span> Lista użytkowników  <?php echo $nazwa_uzytkownika ?></a>
				</div>
				<?php
				echo $this->renderPartial ( '_form2', array (
				'model' => $model,
				'profile' => $profile 
				) );
				?>
				
			</div>
		</div>
	</div>
</div>
	


