<p class="clearfix"></p>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="heading"><h3>Administracja użytkownikami</h3>
            <p>  </p>
        </div>
    </div>
</div>

<p class="clearfix"></p>

<div class="section padding-bot50">
    <div class="container">
        <h6 class="margin-top20"></h6>
		<div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
               <?php
if (count ( $list )) {
	foreach ( $list as $item )
		echo "<li>" . $item . "</li>";
}
?>
	<li><?php echo CHtml::link(UserModule::t('Dodaj nowego użytkownika'),array('create')); ?></li>
	<li><?php echo CHtml::link(UserModule::t('Zmień użytkownika - '.$model->username),array('update','id'=>$model->id)); ?></li>            
    <li><?php echo CHtml::link(UserModule::t('Usuń użytkownika - '.$model->username),array('usun','id'=>$model->id)); ?></li>  
	 
        </div><!-- /.navbar-collapse -->
		<p class="clearfix"></p>
		
		<div class="col-lg-12 col-md-6 col-xs-12 col-sm-12">
<?php
$dane = Uzytkownicy::model ()->findAllByAttributes ( array('id_user'=> $model->id ));
foreach($dane as $name) {$nazwa = $name->nazwa; } 


?>	
<?php if(isset($nazwa)){	?>
<h3><?php echo $nazwa ?></h3>		
<?php } ?>
<?php
echo $this->renderPartial ( '_form', array (
		'model' => $model,
		'profile' => $profile 
) );
?>

		
		</div>
		
	</div>
</div>
