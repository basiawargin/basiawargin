<?php 
		
		$id_user=Yii::app()->user->id;
		$dane = User::model()->findbyPk($id_user);
		$superuser = $dane->superuser;
		$id_klienta = $dane->id_klienta;

?>

<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
<fieldset>
	<legend>Informacje podstawowe</legend>
	<?php echo CHtml::beginForm('','post',array('enctype'=>'multipart/form-data')); ?>
	<?php echo CHtml::errorSummary(array($model,$profile)); ?>

	<div class="row">
		<?php echo CHtml::activeLabelEx($model,'username'); ?>
		<?php echo CHtml::activeTextField($model,'username',array('size'=>20,'maxlength'=>20,'class'=>'form-control')); ?>
		<?php echo CHtml::error($model,'username'); ?>
	</div>

	<div class="row">
		<?php echo CHtml::activeLabelEx($model,'password'); ?>
		<?php echo CHtml::activePasswordField($model,'password',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
		<?php echo CHtml::error($model,'password'); ?>
	</div>

	<div class="row">
		<?php echo CHtml::activeLabelEx($model,'email'); ?>
		<?php echo CHtml::activeTextField($model,'email',array('size'=>60,'maxlength'=>128,'class'=>'form-control')); ?>
		<?php echo CHtml::error($model,'email'); ?>
	</div>
	
	<div class="row">
		<?php echo CHtml::activeLabelEx($model,'superuser'); ?>
		<?php echo CHtml::activeDropDownList($model,'superuser',User::itemAlias('KlientStatus'),array('class'=>'form-control')); ?>
		<?php echo CHtml::error($model,'superuser'); ?>
	</div>
	
	<div class="row">
		<?php echo CHtml::activeLabelEx($model,'status'); ?>
		<?php echo CHtml::activeDropDownList($model,'status',User::itemAlias('UserStatus'), array('class'=>'form-control')); ?>
		<?php echo CHtml::error($model,'status'); ?>
	</div>
	
	<div class="row">
		<?php echo CHtml::activeLabelEx($model,'id_klienta'); ?>
		<?php echo CHtml::activeHiddenField($model,'id_klienta',array('value'=>$id_klienta)); ?>
		<?php echo CHtml::error($model,'id_klienta'); ?>
	</div>
	
	<div class="row">
		<?php echo CHtml::activeLabelEx($model,'id_uzytkownika'); ?>
		<?php echo CHtml::activeHiddenField($model,'id_uzytkownika',array('value'=>$_GET['id_uzytkownika'])); ?>
		<?php echo CHtml::error($model,'id_uzytkownika'); ?>
	</div>
<?php
$profileFields = $profile->getFields ();
if ($profileFields) {
	foreach ( $profileFields as $field ) {
		?>
	<div class="row">
		<?php echo CHtml::activeLabelEx($profile,$field->varname); ?>
		<?php
		if ($field->widgetEdit ( $profile )) {
			echo $field->widgetEdit ( $profile );
		} elseif ($field->range) {
			echo CHtml::activeDropDownList ( $profile, $field->varname, Profile::range ( $field->range ) );
		} elseif ($field->field_type == "TEXT") {
			echo CHtml::activeTextArea ( $profile, $field->varname, array (
					'rows' => 6,
					'cols' => 50 
			) );
		} else {
			echo CHtml::activeTextField ( $profile, $field->varname, array (
					'size' => 60,
					'maxlength' => (($field->field_size) ? $field->field_size : 255) 
			) );
		}
		?>
		<?php echo CHtml::error($profile,$field->varname); ?>
	</div>	
			<?php
	}
}
?>
	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Utwórz' : 'Zapisz'); ?>
	</div>

<?php echo CHtml::endForm(); ?>
</fieldset>
</div>
<!-- form -->

