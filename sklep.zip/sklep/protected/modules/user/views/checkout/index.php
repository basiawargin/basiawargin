

<script type="text/javascript" src="//code.jquery.com/jquery-2.2.3.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.20/pdfmake.js"></script>

<div>
	<div class="load"></div>
	<div class="zamowienia"></div>
</div>

	

<script>


$(document).ready(function(){




	
var json_url = "http://kontakt1.vot.pl/index.php/produkty/DisplayCart";
pokazKoszyk2(json_url);




$(document).on('submit', '#koszyk-form1', function(){

	var json_url = "http://kontakt1.vot.pl/index.php/produkty/DisplayCart";
	realizujKoszyk(json_url);
	return false;
});



$(document).on('submit', '#koszyk', function(){

	var form_data=JSON.stringify($(this).serializeObject()); 

	$.ajax({
    	url: "http://kontakt1.vot.pl/index.php/zamowienia/DodajZamowienie",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":form_data},
    	success : function(data) {
				
				read_products_html="<div class='row panel-body mt-4 ml-1'>";
				read_products_html+="<div><h6>Dziękujemy za zakupy.</h6></div>";
				read_products_html+="</div>";
				
		
				$(".zamowienia").html('');				
				$('.zamowienia').html(read_products_html);
				}
			});
		return false;
	});
	


$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};	





  


 $(document).on('click', '.usun', function(){
		
		var id=$(this).find('a').attr('data-id');
		var json_url = "http://kontakt1.vot.pl/index.php/produkty/RemoveFromCart/id/"+id;

		$.getJSON(json_url, function(data){
	
		var json_url2 = "http://kontakt1.vot.pl/index.php/produkty/DisplayCart";
		pokazKoszyk2(json_url2);

		});
		return false;
	});


 $(document).on('click', '.produkt', function(){

		var id = $(this).find('.product-id').text();
    		var quantity = $(this).find('.cart-quantity').val();
		var json_url = "http://kontakt1.vot.pl/index.php/produkty/UpdateCart/id/"+id+"/quantity/"+quantity;
																				
   		$.getJSON(json_url, function(data){
		var json_url2 = "http://kontakt1.vot.pl/index.php/produkty/DisplayCart";
		pokazKoszyk2(json_url2);

		});
		return false;
	});
	
});	
 
 

function pokazKoszyk2(json_url)
{
			$.getJSON(json_url, function(data){
			
			$(".load").html('<i class="fa fa-spin fa-spinner"></i> Przetwarzanie...');
			$('.zamowienia').html('');
			
			var read_products_html="";
			if(data.dane[2].paging.id === "N")
			{
				
				
				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Należy się zalogować lub zarejestrować, jeśli nie masz konta.</p>";
				read_products_html+="</div>";

			} else {
			

				if(data.dane[0] === null)
				{
				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Brak produktow w koszyku.</p>";
				read_products_html+="</div>";
				} 
				else {	
					var total ="";
					var produkty = '';
			
					read_products_html+="<div class='py-5 text-center'>";
					read_products_html+="";
					read_products_html+="<h2>Twoje zamówienie</h2>";
					read_products_html+="<p class='lead'>Szczegóły</p>";
					read_products_html+="</div>";	
					read_products_html+="<div class='justify-content-center'><div class='col-md-7 order-md-1'>";
					read_products_html+="<h4 class='mb-3'></h4>";
					read_products_html+="<form action='#' name='koszyk-form1' id='koszyk-form1' method='pos'>";
				
					$.each(data.dane[0].records, function(keyx, valx) {
							
					read_products_html+="<div class='row'>";
					read_products_html+="<div class='col-md-6 mb-3'>";
					read_products_html+="<div class='float-left'>"+valx.nazwa+"  "+valx.rozmiar+"  "+valx.jednostka+"  -   "+valx.cena+"  "+valx.waluta+" </div>";
					read_products_html+="<div class='float-left'> Razem: "+valx.subtotal+"  "+valx.waluta+"</div>";
					read_products_html+="</div>";

					read_products_html+="<div class='col-md-6 mb-3'>";
					read_products_html+="<div class='produkt' class='col-lg-12'>";
					read_products_html+="<div class='product-id' style='display:none;'>"+valx.id+"</div>";
					read_products_html+="<div  class='input-group col-lg-6  float-left usun'>";
					read_products_html+="<a href='#' data-id='"+valx.id+"' class='col-lg-12 btn btn-default'> Usuń</a>";	
					read_products_html+="</div>";	
					
					read_products_html+="<div class='input-group col-lg-6'>";
               		read_products_html+="<input type='number' name='quantity' value='"+valx.ilosc+"' class='form-control col-lg-12 cart-quantity' min='1' />";
					read_products_html+="</div>";
					read_products_html+="</div>";	
					read_products_html+="</div>";
					
					read_products_html+="</div><br />";
					
					});		
				
					read_products_html+="<div class='justify-content-center px-2 px-sm-2 px-md-2'>";
					read_products_html+="<div> Razem: "+data.dane[1].paging.cenatotal+" PLN</div>";
					read_products_html+="</div>";
				
				

					
					read_products_html+="<hr class='mb-4 '>";
					read_products_html+="<div class='row px-sm-2 px-md-2 justify-content-center'>";
					read_products_html+="<input type='submit'  name='realizuj' class='form-control col-lg-4 col-md-3 col-sm-3 col-6' value=' Realizuj' />";
					read_products_html+="</div>";
					read_products_html+="</form>";
					read_products_html+="</div></div>";
				}
						
			}
			$(".load").html('');	
			$('.zamowienia').html(read_products_html);
		});
		
}
 

function realizujKoszyk(json_url)
{







			$(".load").html('<i class="fa fa-spin fa-spinner"></i> Przetwarzanie...');	
			$.getJSON(json_url, function(data){
			var x = data.dane[2].paging.id;
			if(x == "T")
			{	
				read_products_html ="";
				
				if(data.dane[1].paging.cenatotal == "0")
				{
				$('.zamowienia').html('');
				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Brak produktow w koszyku.</p>";
				read_products_html+="</div>";
				} 
				else {
				var total;
				var produkty = '';
				total = 0;			
				
				$.each(data.dane[0].records, function(keyx, valx) {
								
				produkty+= valx.id+','+valx.ilosc+','+valx.cena+','+valx.vat+','+valx.upust+'=>';
				total +=  valx.subcena;
							
				});

				read_products_html+="<div class='py-5 text-center'>";
				read_products_html+="";
				read_products_html+="<h2>Twoje zamowienie</h2>";
				read_products_html+="<p class='lead'>Wprowadź dane potrzebne do realizacji zamówienia.</p>";
				read_products_html+="</div>";

				read_products_html+="<div class='row justify-content-center'>";
					
				read_products_html+="<div class='col-md-7 px-col-3 order-md-1'>";
				read_products_html+="<h4 class='mb-3'></h4>";
				read_products_html+="<form action='#' class='needs-validation' name='koszyk' id='koszyk' novalidate>";
				read_products_html+="<div class='row'>";
                read_products_html+="<div class='col-md-6 mb-3'>";
                read_products_html+="<label for='firstName'>Imię</label>";
                read_products_html+="<input type='text' class='form-control' name='imie' id='firstName' placeholder='' value='' required />";
                read_products_html+="<div class='invalid-feedback'> Imię jest wymagane";
                read_products_html+="</div>";
				read_products_html+="</div>";
				read_products_html+="<div class='col-md-6 mb-3'>";
                read_products_html+="<label for='lastName'>Nazwisko</label>";
                read_products_html+="<input type='text' class='form-control' id='nazwisko' name='nazwisko' placeholder='' value='' required />";
                read_products_html+="<div class='invalid-feedback'> Nazwisko jest wymagane";
				read_products_html+="</div>";
				read_products_html+="</div>";
				read_products_html+="</div>";

									
				read_products_html+="<div class='mb-3'>";
				read_products_html+="<label for='email'>Email <span class='text-muted'></span></label>";
				read_products_html+="<input type='email' class='form-control' id='email' name='email' placeholder='you@example.com'>";
				read_products_html+="<div class='invalid-feedback'> Podaj adres email";
           		read_products_html+="</div>";
				read_products_html+="</div>";
				
				read_products_html+="<div class='mb-3'>";
				read_products_html+="<label for='telefon'>Telefon <span class='text-muted'></span></label>";
				read_products_html+="<input type='text' class='form-control' id='telefon' name='telefon' >";
				read_products_html+="<div class='invalid-feedback'> Podaj adres email";
              	read_products_html+="</div>";
				read_products_html+="</div>";

				read_products_html+="<div class='mb-3'>";
				read_products_html+="<label for='miasto'>Miasto dostawy</label>";
				read_products_html+="<input type='text' class='form-control' id='address' name='miasto' placeholder='' required>";
				read_products_html+="<div class='invalid-feedback'> Miasto dostawy";
            	read_products_html+="</div>";
				read_products_html+="</div>";
				
				read_products_html+="<div class='mb-3'>";
				read_products_html+="<label for='adres'>Adres</label>";
				read_products_html+="<input type='text' class='form-control' id='address2' name='adres' placeholder='' required>";
				read_products_html+="<div class='invalid-feedback'> Adres dostawy";
            	read_products_html+="</div>";
				read_products_html+="</div>";
				
				read_products_html+="<div class='row'>";
				read_products_html+="<div class='col-md-5 mb-3'>";
                read_products_html+="<label for='kraj'>Kraj</label>";
                read_products_html+="<select class='custom-select d-block w-100' id='country' name='kraj' required>";
                read_products_html+="<option value=''>Wybierz...</option>";
                read_products_html+="<option>Polska</option>";
                read_products_html+="</select>";
                read_products_html+="<div class='invalid-feedback'> Wybier kraj";
                read_products_html+="</div>";
				read_products_html+="</div>";
				
				read_products_html+="<div class='col-md-4 mb-3'>";
                read_products_html+="<label for='wojewodztwo'>Województwo</label>";
                read_products_html+="<select class='custom-select d-block w-100' id='state' name='wojewodztwo' required>";
                read_products_html+="<option value=''>Wybierz...</option>";
                read_products_html+="<option>pomorskie</option>";
                read_products_html+="</select>";
                read_products_html+="<div class='invalid-feedback'> wojewodztwo";
                read_products_html+="</div>";
				read_products_html+="</div>";
				
				read_products_html+="<div class='col-md-3 mb-3'>";
                read_products_html+="<label for='kod'>Kod</label>";
                read_products_html+="<input type='text' class='form-control' id='zip' name='kod' placeholder='' required>";
                read_products_html+="<div class='invalid-feedback'> Kod pocztwowy";
               read_products_html+="</div>";
				read_products_html+="</div>";
				read_products_html+="</div>";
				
		       
				read_products_html+="<hr class='mb-4'>";
 
				read_products_html+="<div class='form-group'>";
                read_products_html+="<label for='datadostawy' class='col-form-label'>Data dostarczenia</label>";
                read_products_html+="<input type='date' class='form-control'  name='datadostawy' id='datadostawy' required=''>";
                read_products_html+="</div>";
				read_products_html+="<div class='panel-body'><input type='hidden' name='produkty' value='"+produkty+"'></div>";
				read_products_html+="<div class='panel-body'><input type='hidden' name='cena' value='"+total+"'></div>";
				
                         
       
				read_products_html+="<hr class='mb-4'>";
				read_products_html+="<input type='submit' id='realizu' name='realizuj' class='col-lg-4 btn btn-primary btn-lg btn-block' value=' Realizuj'>";
				read_products_html+="</form>";
				read_products_html+="</div>";
				read_products_html+="</div>";

				}

				$(".load").html('');				
				$('.zamowienia').html(read_products_html);
						
			}
		});

}		
</script>