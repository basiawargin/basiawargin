		<div class="container">
			<div class="row  justify-content-center">
				<div class="col-md-4 col-md-offset-4">
					<?php if(Yii::app()->user->hasFlash('loginMessage')): ?>
					<div class="success">
						<?php echo Yii::app()->user->getFlash('loginMessage'); ?>
					</div>
					<?php endif; ?>
					<div class="alert"><?php echo CHtml::errorSummary($model); ?></div>
					<div class="form-signin">
						
						<h1 class="h3 mb-3 font-weight-normal">Zaloguj się</h1>
						
						<div class="panel-body">
									
						<form action="#" method="post">
						<fieldset>
						<?php echo CHtml::beginForm(); ?>
				
						<div class="form-group">
						<?php echo CHtml::activeLabelEx($model,'nick',array('class'=>'sr-only')); ?>
						<?php echo CHtml::activeTextField($model,'username',array('class'=>'form-control','placeholder'=>"nick"));?>
						</div>

						<div class="form-group">
						<?php echo CHtml::activeLabelEx($model,'password',array('class'=>'sr-only')); ?>
						<?php echo CHtml::activePasswordField($model,'password',array('class'=>'form-control','placeholder'=>"hasło"))?>
						</div>

						<div class="form-group">
						<p class="hint">
						<?php echo CHtml::link(UserModule::t("Zarejstruj się"),Yii::app()->getModule('user')->registrationUrl); ?>
						 | <?php echo CHtml::link(UserModule::t("Zapomniałeś hasło?"),Yii::app()->getModule('user')->recoveryUrl); ?>
						</p>
						</div>
						<div class="form-group">
						<?php echo CHtml::submitButton(UserModule::t("Loguj"), array('class'=>'btn btn-lg btn-primary btn-block')); ?>
						</div>
	
						<?php echo CHtml::endForm(); ?>
						<?php
							$form = new CForm ( array (
							'elements' => array (
							'username' => array (
							'type' => 'text',
							'maxlength' => 32 
							),
							'password' => array (
							'type' => 'password',
							'maxlength' => 32 
							),
							'rememberMe' => array (
							'type' => 'checkbox' 
							) 
							),
		
							'buttons' => array (
								'login' => array (
								'type' => 'submit',
								'label' => 'Login' 
							) 
							) 
							), $model );
				?>
					</fieldset>
					</form>
                    </div>
                </div>
            </div>
        </div>
		</div>

		
		
		