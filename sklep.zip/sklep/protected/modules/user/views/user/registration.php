
	<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4 col-md-offset-4">
				<div class="alert"></div>
						<?php if(Yii::app()->user->hasFlash('registration')): ?>
						<div class="success">
							<?php echo Yii::app()->user->getFlash('registration'); ?>
						</div>
						<?php else: ?>
						<div class="form-signin">
						
						<h1 class="h3 mb-3 font-weight-normal">Zarejestruj się</h1>
							<div class="login-panel panel panel-default">
								<div class="panel-body">	
									<div class="form">
			<?php
	
			$form = $this->beginWidget ( 'UActiveForm', array (
			'id' => 'registration-form',
			'enableAjaxValidation' => true,
			'disableAjaxValidationAttributes' => array (
					'RegistrationForm_verifyCode' 
			),
			'htmlOptions' => array (
					'enctype' => 'multipart/form-data' 
			) 
			) );
			?>

			<p class="note"><?php echo UserModule::t('Wszystkie pola <span class="required"></span> są wymagane.'); ?></p>
	
			<?php echo $form->errorSummary(array($model,$profile)); ?>
	
			<div class="form-group">
			<?php echo $form->labelEx($model,'nick',array('class'=>'sr-only')); ?>
			<?php echo $form->textField($model,'username',array('class'=>'form-control','placeholder'=>"nick")); ?>
			<?php echo $form->error($model,'username'); ?>
			</div>

			<div class="form-group">
			<?php echo $form->labelEx($model,'hasło',array('class'=>'sr-only')); ?>
			<?php echo $form->passwordField($model,'password',array('class'=>'form-control','placeholder'=>"hasło")); ?>
			<?php echo $form->error($model,'password'); ?>
			<p class="hint">
			<?php echo UserModule::t("Hasło składa się z minimum 4 znaków."); ?>
			</p>
			</div>

			<div class="form-group">
			<?php echo $form->labelEx($model,'powtorz haslo',array('class'=>'sr-only')); ?>
			<?php echo $form->passwordField($model,'verifyPassword',array('class'=>'form-control','placeholder'=>"powtorz hasło")); ?>
			<?php echo $form->error($model,'verifyPassword'); ?>
			</div>

			<div class="form-group">
			<?php echo $form->labelEx($model,'email',array('class'=>'sr-only')); ?>
			<?php echo $form->textField($model,'email',array('class'=>'form-control','placeholder'=>"email")); ?>
			<?php echo $form->error($model,'email'); ?>
			</div>
	
			<?php
			$profileFields = $profile->getFields ();
			if ($profileFields) {
				foreach ( $profileFields as $field ) {
				?>
				<div class="form-group">
				<?php echo $form->labelEx($profile,$field->varname); ?>
				<?php
				if ($field->widgetEdit ( $profile )) {
				echo $field->widgetEdit ( $profile );
				} elseif ($field->range) {
				echo $form->dropDownList ( $profile, $field->varname, Profile::range ( $field->range ) );
				} elseif ($field->field_type == "TEXT") {
				echo $form->textArea ( $profile, $field->varname, array (
						'rows' => 6,
						'cols' => 50 
					) );
				} else {
				echo $form->textField ( $profile, $field->varname, array (
						'size' => 60,
						'maxlength' => (($field->field_size) ? $field->field_size : 255) 
				) );
				}
				?>
				<?php echo $form->error($profile,$field->varname); ?>
				</div>	
				<?php
				}
			}
			?>
			<?php if (UserModule::doCaptcha('registration')): ?>
			<div class="form-group">
	
			<?php echo $form->labelEx($model,'kod weryfikujący'); ?>
			</div>
		
			<div class="user-captcha captcha">
			<?php $this->widget('CCaptcha', 
                    array(
                            'captchaAction' =>'/site/captcha',
                            'buttonOptions' => array('class'=>'test','style' => 'display:block'),
                            'buttonLabel'   => 'Odśwież obraz'
                         )
              );  ?>
			</div>
			<?php echo $form->textField($model,'verifyCode'); ?>
			<div class="form-group"><?php echo UserModule::t("Przepisz kod z obrazka."); ?>
			<br /><?php echo UserModule::t(""); ?>
			</div>
			<?php endif; ?>
	
			<div class="form-group">
			<?php echo CHtml::submitButton(UserModule::t("Rejestracja", array('class'=>'btn btn-lg btn-primary btn-block'))); ?>
			</div>

			<?php $this->endWidget(); ?>
										</div>
									</div>
								</div>
							</div>
			<?php endif; ?>
			<div class="form-group">
						<p class="hint">
						<?php echo CHtml::link(UserModule::t("Zaloguj się"),Yii::app()->getModule('user')->loginUrl); ?>
						 | <?php echo CHtml::link(UserModule::t("Zapomniałeś hasło?"),Yii::app()->getModule('user')->recoveryUrl); ?>
						</p>
			</div>
		</div>
		<div class="col-md-6 col-md-offset-4 align-self-center">
			Klikając przycisk Rejestracja, akceptuję Regulamin.

			Przyjmuję do wiadomości, że zakupydoreki.pl wykorzystuje moje dane osobowe zgodnie z Polityką prywatności oraz Polityką dotyczącą plików cookie i podobnych technologii.
			Zakupydoreki.pl wykorzystuje zautomatyzowane systemy i partnerów do analizowania, w jaki sposób korzystam z usług w celu zapewnienia odpowiedniej funkcjonalności produktu, treści, 
			dostosowanych i opartych na zainteresowaniach reklam, jak również ochrony przed spamem, złośliwym oprogramowaniem i nieuprawnionym korzystaniem z naszych usług.
			</div>
	</div>
</div>
				
		




