<div class="container">
     <div class="row justify-content-center">
        <div class="col-md-4 col-md-offset-4">
			<div class="alert"></div>
				<div class="success">
						<?php echo CHtml::errorSummary($form); ?>	
				</div>
				<div class="form-signin">
					<h1 class="h3 mb-3 font-weight-normal">Zmień hasło</h1>
					<div class="panel-body">		
						
<div class="form">
<fieldset>
<?php echo CHtml::beginForm(); ?>
	<?php echo CHtml::errorSummary($form); ?>
	
	<div class="form-group">
	<?php echo CHtml::activeLabelEx($form,'password',array('class'=>'sr-only')); ?>
	<?php echo CHtml::activePasswordField($form,'password',array('class'=>'form-control','placeholder'=>"hasło")); ?>
	<?php echo UserModule::t("Hasło miniumum 6 znaki."); ?>
	</div>

	<div class="form-group">
	<?php echo CHtml::activeLabelEx($form,'verifyPassword',array('class'=>'sr-only')); ?>
	<?php echo CHtml::activePasswordField($form,'verifyPassword'); ?>
	</div>


	<div class="form-group">
	<?php echo CHtml::submitButton(UserModule::t("Zapisz hasło"), array('class'=>'btn btn-lg btn-primary btn-block')); ?>
	</div>

<?php echo CHtml::endForm(); ?>
	</fieldset>
</div>
<!-- form -->
				
				
				</div>
             </div>	
		</div>
    </div>
</div>


		
	



