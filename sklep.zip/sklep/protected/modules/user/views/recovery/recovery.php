<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 col-md-offset-4">
			<div class="alert"></div>
			<?php if(Yii::app()->user->hasFlash('recoveryMessage')): ?>
			<div class="success">
							<?php echo Yii::app()->user->getFlash('recoveryMessage'); ?>
			</div>
					<?php else: ?>
			<div class="form-signin">
						
				<h1 class="h3 mb-3 font-weight-normal">Przypomnij hasło</h1>
				<div class="login-panel panel panel-default">
					<div class="panel-body">
						
						<form action="#" method="post">
						<fieldset>
						<?php echo CHtml::beginForm(); ?>
						<?php echo CHtml::errorSummary($form); ?>
	
						<div class="form-group">
						<?php echo CHtml::activeLabel($form,'login_or_email',array('class'=>'sr-only')); ?>
						<?php echo CHtml::activeTextField($form,'login_or_email',array('class'=>'form-control','placeholder'=>"login lub email"))?>
						</div>

						<div class="form-group">
						<?php echo CHtml::submitButton(UserModule::t("Wyślij dane"), array('class'=>'btn btn-lg btn-primary btn-block')); ?>
						</div>

						<?php echo CHtml::endForm(); ?>
						</fieldset>
						</form>
					</div>
				</div>
			</div>						
			<?php endif; ?>	
		</div>
	</div>
</div>



		
	


