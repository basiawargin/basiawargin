
<?php
/**
 * RegistrationForm class.
 * RegistrationForm is the data structure for keeping
 * user registration form data. It is used by the 'registration' action of 'UserController'.
 */
class RegistrationForm extends User {
	public $verifyPassword;
	public $verifyCode;
	
	public function rules() {
		$rules = array(
			array('username, password, verifyPassword, email', 'required'),
			array('username', 'length', 'max'=>20, 'min' => 8,'message' => UserModule::t("Nieprawidlowy nick (min 6 znaków, max 20 znaków).")),
			array('password', 'length', 'max'=>128, 'min' => 6,'message' => UserModule::t("Nieprawidlowe hasło (min 6 znaków).")),
			array('email', 'email'),
			array('username', 'unique', 'message' => UserModule::t("Nick już istnieje.")),
			array('email', 'unique', 'message' => UserModule::t("Taki adres email już istnieje.")),
			array('verifyPassword', 'compare', 'compareAttribute'=>'password', 'message' => UserModule::t("Haslo jest niespójne.")),
			array('verifyCode', 'captcha', 'captchaAction'=>'site/captcha', 'message'=>'Captcha nieprawidlowy!', 'allowEmpty'=>!CCaptcha::checkRequirements())
		);


		
		return $rules;
	}
	
}