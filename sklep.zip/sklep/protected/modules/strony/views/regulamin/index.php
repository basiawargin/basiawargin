
<ul class="nav" id="side-menu">
                        
                        <li>
                          <a href="/index.php/strony/regulamin/specyfikacja">Specyfikacja usługi</a></li>
						<li>
						<li>
                          <a href="/index.php/strony/cennik">Cennik</a></li>
						<li>
						<li>
                          <a href="/index.php/strony/cookie">Cookie</a></li>
						<li>
</ul>

<h2>Regulamin systemu rezerwacji potraw i stolików</h2>
<ul><li><h3>Postanowienia ogólne</h3></li>
	<ul>
	<li>Regulamin świadczenia usług określa zasady na jakich świadczone są usługi na rzecz Klienta przez OWP OKO Małgorzata Wątor z siedzibą w Słupsku, ul. Szczecińska 57 zwanym w dalszej części towynajme.pl.</li>
	<li>Klientem jest to podmiot, zawierający umowę z towynajme.pl o świadczenie usług, wykupujący użytkowanie systemu rezerwacji dla dowolnej liczby własnych punktów sprzedaży.</li>
	<li>Regulamin  oznacza  Regulamin  systemu rezerwacji potraw i stolków oraz  dokumenty,  do  których  odsyła  ten Regulamin,  tj.  Cennik,  Specyfikacja  usługi.</li>
	<li>Usługa rezerwacji potraw i stolików  to  usługa, która  polega  na udostępnieniu Klientowi możliwości korzystania  z  Panelu Administracyjnego Klienta znajdującego się na stronie towynajme.pl  pozwalającego  na  możliwość działania programu do rezerwacji stolików i potraw na stronie domowej Klienta. Opłata  tytułem  świadczenia  Usługi jest  określona w umowie lub w Cenniku na stronie internetowej.  </li>
	<li>Usługa rezerwacji potraw i stolików świadczona  jest  zgodnie z parametrami bezpieczeństwa na wszystkich poziomach.</li>
	<li>System rezerwacji potraw i stolików umożliwia rezerwację potraw i stolików na miejscu w restauracji lub rezerwację potraw na wynos.</li>
	<li>Dostępność Usługi to prawidłowe funkcjonowanie systemu rezerwacji na stronie domowej Klienta. W czas Dostępności Usługi wliczane są przerwy związane z obsługą i konserwacją systemu leżące po stronach serwisów towynajme.pl i firmy hostingowej, z której usłgug towynajme.pl korzysta. Firma hostingowa udostępnia towynajme.pl miejsce  na swoim serwerze oraz uruchamia usługi wyspecyfikowane na swoich stronach.</li>
	<li>Okres Abonamentowy - to okres czasu na który Usługa udostępniana jest Klientowi, przy czym nie dłuższy niż określony w cenniku i umowie przesłanej drogą elektroniczną. Okres Abonamentowy to maksymalny okres czasu na wykorzystanie parametrów Usługi, jeżeli takie parametry dla danej Usługi zostały określone.</li>
	<li>Klient wyraża zgodę na otrzymywanie faktur w formie elektronicznej.</li>
	<li>Aktywacja konta - jest to założenie konta Klientowi w Panelu Administraycyjnym Klienta i przyznaniu mu wszyskich uprawnień wynikających z Umowy o świadcznie usług.</li>
	<li>Zawieszenie usług - jest to brak możliwości zalogowania się do konta Klienta i brak możliwości logowania dla wszystkich uprawnionych przez niego Użytkowników z powodu nie odnotowania wpłaty na koncie towynajme.pl z tytułu świadczenia usług.  Admnistrator danych nie usuwa zbiory danych Klienta dotyczące jego punktów sprzedazy, rezerwacji, katalogi ze zdjęciami. Administrator danych przywraca aktywność w Panelu Admnistracyjnym Klienta w ciągu 3 dni od odnotownia wpłaty na koncie.</li>
	<li>Dezaktywacja konta - jest to brak możliwości zalogowania się do konta Klienta i brak możliwości logowania dla wszystkich upoważnionych przez niego Użytkowników z powodu rezygnacji z usług przez Klienta. Admnistrator danych usuwa wszelkie zbiory danych Klienta dotyczące jego punktów sprzedazy, rezerwacji, katalogi ze zdjęciami. Administrator danych nie ma mozliwości przywrócenia tych danych w systemie.</li>
	</ul>
</ul>
<ul>
	<li><h3>Przetwarzanie danych osobowych i ochrona danych osobowych</h3></li>
	Serwis towynajme.pl realizuje postanowienia Rozporządzenia Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. ustanawiającym przepisy o ochronie osób fizycznych w związku z przetwarzaniem danych osobowych oraz przepisy o swobodnym przepływie takich danych osobowych. Rozporządzenie chroni podstawowe prawa i wolnośći osób fizycznych w szczególności ich prawo do ochrony danych osobowych.
	<ul><li><h4>Współadministratorami danych osobowych są:</h4></li>
		<ul>
		<li>Małgorzata Wątor OWP OKO przy ul. Szczecińskiej 57A w Słupsku - dane kontaktowe +48 605 888 456, email: biuro@towynajme.pl </li>
		<li></li>
		</ul>
		<li><h4>Podmiotem przetwarzającym dane osobowe jest:</h4></li>
		<ul><li></li></ul>
	</ul>
	<ul>
	<li><h4>Przetwarzanie danych osobowych, cele, odbiorcy oraz podstawa prawna</h4></li>
		<ul>
		
			<li>Firma OWP OKO Małgorzata Wątor zawierając z Klientem umowę na świadczenie usług w momencie wypełnienia elektronicznej umowy wymaga podania następujących danych Klienta: nazwa firmy, nip, adres firmy, adres korespondencyny firmy, telefon kontaktowy, adres email, imię, nazwisko, pesel, seria dowodu osobistego Klienta.
			Umowa zawierana jest w formie umowy wysyłanej elektronicznie. Podstawą prawną przetwarzania danych jest Rozporządzenie Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. Art.6 ust b. Podanie tych danych jest warunkiem zawarcia umowy. 
			Odbiorcą tych danych osobowych są jedynie Administratorzy danych oraz działający w ich imieniu Podmioty przetwarzające wymienieni w niniejszym Regulaminie w celach prowadzenia rozliczeń finansowych. Dane te są poufne i nie są udostępnianie innym osobom, podmiotom gospodarczych do dalszego przekształcania.
			Każdy Klient może dobrowlnie zmienić te dane w trakcie trwania umowy w Panelu Administracyjnym Klienta.
			Administratorzy danych i działający w jego imieniu Podmioty przetwarzające prowadzą rozliczenia finansowe z Klientem polegające na informowaniu Klienta o ewentualnych zaległościach, nadpłacie na koncie itp. Kontakt z Klientem ma formę elektroniczną bądź telefoniczną (w tym SMS) korzystając z danych podanych przy zawarciu umowy.
			</li>
			<li>Klient w ramach zawartej umowy samodzielnie wprowadza w Panelu Administracyjnym Klienta następujące informacje:
			<ul>
			<li> dane umożliwiające realiazację płatności internetowych działające w systemach przelewy24, paypal, payU</li>
			<li> zdjęcia logo,kategorii, potraw w formie jpg, gif </li>
			<li> dane swoich punktów sprzedaży takie jak: nazwa punktu, adres, email kontaktowy, telefon, godziny pracy punktu, godziny prowadzenia rezerwacji na wynos, kategorie potraw, potrawy, liczba stolików, dni niepracujące, ceny potraw oraz dane do realizacji płatności internetowych</li>
			Wprowadzenie tych danych warunkuje prawidłowe prowadzenie rezerwacji na stronie domowej Klienta a ich podanie jest dobrowolne. Dane te (poza danymi do realizacji płatności internetowych) są udostępniane na stronie domowej Klienta co jest celem umowy oraz są widoczne w Panelu Admnistracyjnym Klienta na stronie towynajme.pl. Dane do realizacji płatności internetowych widoczne są tylko tym użytkownikom, których Klient upoważnił do prowadzenia punktu sprzedaży w Panelu Administracyjnym Klienta.</li>
			</ul>
			Podstawą prawną przetwarzania tych danych jest Rozporządzenie Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. Art.6 ust a - przetwarzanie danych osobowych będace realizacją celu umowy. Wyrażenie zgody na podanie i przetwarzanie tych danych jest warunkiem umownym.

			</li>
			<li>
			Administratorzy danych i działający w jego imieniu Podmioty przetwarzające wykonują działania marketnigowe wobec Klientów, którzy wyrazili na to zgodę w trakcie zawarcia umowy lub poprzez wybór opcji w Panelu Admnistracyjnym Klienta. Działania marketingowe to inaczej informowanie Klienta o ewentualnych zmianach w sytemie rezerwacji, propozycje przedłużenia i korzystania z dodatkowych usług. Działania te mają na celu rozszerzenie oferty serwisu i wzmocnienia pozycji firmy (reklama, promocja, badanie rynku). Podstawą prawną tego typu działań jest Rozporządzenie Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. Art.6 ust a. Wyrażenie zgody na tego rodzaju działania ze strony Klienta jest dobrowolne i nie uniemożliwia świadczenia usług.
			</li>
		</ul>
	</li>
	</ul>
	<ul>
	<li><h4>Usuwanie danych osobowych z systemu </h4></li>
		<ul>
		<li>Dane firmowe Klienta podawane w momencie zawarcia umowy oraz informacje o rozliczeniach finasowych ze wszystkich okresów rozliczeniowych z Klientem przechowywane są przez cały okres zawartej umowy oraz przez okres kolejnych 5 lat po rozwiązaniu umowy w sposób zgodny z warunkami umowy (bez nierozwiązanych roszczeń spornych). W przypadku nierozwiązanych roszczeń spornych po okresie 5 lat decyzję o usunięciu danych podejmują Admnistratorzy danych.</li>
		<li>Dane punktów sprzedaży, kategorii produktów, potraw, rezerwacji, zdjęcia są usuwane całkowicie po 30 dniach od rozwiązania umowy. </li>
		<li>Klient w trakcie trwania umowy może samodzielnie w Panelu Administracyjnym Klienta do odwołania wyłączyć wyświetlanie się poszczególnych punktów sprzedaży na stronie domowej Klienta. </li>
		<li>Podmiot przetwarzający po zakończeniu przetwarzania zwraca Administratorowi danych wszelkie dane osobowe oraz usuwa wszelkie ich istniejące elektroniczne kopie umowy. Wszelkie informacje elektroniczne lub pisemne dotyczące Klienta usuwa.</li>
		</ul>
	</li>
	</ul>
	<ul><h4>Prawa Klienta </h4></li>
	<li>Klientowi przysługuje prawo do wystawienia żądań lub sprzeciwu przeciwko przetwarzaniu danych osobowych zgodnie z Rozporządzeniem Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. Art. 16, 17, 18, 19, 21. </li>
	<li>Klient w każdym momencie trwania umowy może poprzez Panel Administracyjny Klienta wyłączyć prezentację danych poszczególnych punktów sprzedaży co będzie skutkowało wyłaczeniem wyświetlania się danych na stronie firmowej Klienta. Wyłaczenie prezentacji danych nie pozostaje na wysokość opłaty za Usłgę.
	</li>
	<li>Klient w każdym momencie trwania umowy może cofnąć zgodę na działania marketingowe podejmowane przez Administratorów danych bądź Podmiotów przetwarzających serwisu towynajme.pl. Dokonuje to samodzielnie w Panelu Administracyjnym Klienta.
	</li>
	<li>Klient ma prawo wnieść skargę do Organu Nadzorczego w Polsce w przypadku naruszenia poufności jedo danych osobowych.
	</li>
	<li>Klient ma możliwość w Panelu Administracyjnym Klienta do modyfikacji danych firmowych, danych punktu sprzedaży, cofniecia zgody na przetwarzanie danych w celach marketingowych, usunięciu danych punktów sprzedaży, danych o rezerwacjach, usunięciu zdjęć i logo firmy.</li> 
	<li>Uprawnienia poszczególnych Użytkowników wprowadzonych przez Klienta bądź przez Super Użytkownika upoważnionego przez Klienta opisane są w Specyfikacji usługi.</li>
	<li>Klient ma prawo do rezygnacji z Usługi rezerwacji stolików i potraw w trakcie trwania umowy (poprzez link Kontakt). W ciągu 30 dni od zgłoszenia rezygnacji z Usługi Admnistratorzy danych usuwają dane punktów sprzedaży, dane rezerwacji, zdjęcia. W Panelu Admnistracyjnym Klienta konto Klienta i upoważnionych jego Użytowników są nieaktywne. Dane firmowe Klienta pozostają w bazie danych przez okres 5 lat od dezaktywacji konta. 
	<li>Klient ma prawo do żadania od Admnistratora danych ograniczenia przetwarzania w przypadkach:
	<ul><li>
	gdy Klient kwestionuje prawidłowość danych osobowych na okres czasu pozwalający Admnistratorowi danych sprawdzić prawidłowość tych danych</li>
	<li>gdy przetwarzanie jest niezgodne z prawem, a osoba, której dane dotyczą, sprzeciwia się usunięciu danych osobowych</li>
	<li>gdy Administrator danych nie potrzebuje już danych osobowych do celów przetwarzania, ale są one potrzebne Klientowi, którego dane dotyczą, do ustalenia, dochodzenia lub innych roszczeń </li>
	</ul>
	<li>Admnistrator danych informuje Klienta o sprostowaniu danych osobowych wykonanych przez towynajme.pl, usunięciu danych, ograniczeniu przetwarzania, których dokonał zgodnie z Rozporządzeniem Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. z Art. 16, Art. 17 Ust 1, Art.18.</li>
	</ul>
	<ul><h4>Pozostałe informacje </h4></li>
	<li>Dane Klienta nie są profilowane przez Administratorów danych.</li>
	<li>Administratorzy danych nie zamierzają przetwarzać danych dostarczonych przez Klienta w żadnym innym celu.</li>
	</ul>
</ul>

<ul>
<li><h3>Zamawianie usługi</h3></li>
	<ul>
	<li>Zamówienie Usługi  polega  na  wypełnieniu  przez  Klienta  elektronicznego  formularza wysyłanego elektronicznie na adres biuro@towynajme.pl (Link Kontakt).</li>
	<li>Złożenie zamówienia usługi drogą elektroniczną nie jest równoznaczne z zawarciem umowy między towynajme.pl a Klientem. Towynajme.pl po przeanalizowaniu potrzeb klienta, strony domowej klienta, omówieniu z Klientem spraw technicznych podejmuje decyzję o realizacji wniosku. Klient otrzymuje drogą elektroniczną od towynajme.pl wzór Umowy o świadczeniu usługi.</li> 
	<li>Zawarcie umowy z Klientem jest w momencie przesłania na adres biura prawidłowo wypełnionionej Umowy o świadczeniu usługi z firmą towynajme.pl (przesłanie drogą elektroniczną bądź pocztą).</li>
	<li>Usługa  aktywowana  jest  na  okres czasu wskazany w Umowie o świadczeniu usługi. Czas abonamentowy liczony  jest od  daty  aktywowania  Usługi na stronie domowej Klienta. </li>
	<li>Towynajme.pl zastrzega sobie czas na przygotowanie skryptów pracujących na stronie domowej Klienta, który jest uzgadniany z Klientem po wstępnym przeanalizowaniu stanu strony.</li>
	<li>Po przygotowaniu skryptów działających po stronie Klienta i zainstalowaniu ich na stronie domowej Klienta towynajme.pl wysyła fakturę proformę drogą elektroniczną.</li>
	<li>Towynajme.pl zobowiązuje  się  do  aktywowania  Usługi  na  warunkach  określonych  w prawidłowo złożonej  Umowie o świadczenie  usług  w ciągu 7 dni od opłacenia przez Klienta proformy.</li> 
	<li>Zawierając  umowę  na  podstawie  zapisów  Regulaminu  (tj.  w  zależności  od  okoliczności: zamawiając  Usługę,  dokonując  wpłaty  lub
	przystępując  do  korzystania  z  Usługi  opłaconej  za pośrednictwem   osoby   trzeciej)   Klient   oświadcza,   iż   zapoznał   się   i  akceptuje   w   całości 
	Regulamin.</li>
	<li>Klient otrzymuje login i hasło umożliwiające logowanie do Panelu Administracyjnego Klienta, w którym Klient wprowadza dowolną liczbę własnych punktów sprzedaży, dowolną liczbę użytkowników, menu itp. (szczegóły w Specyfikacji usługi).</li>
	</ul>
</ul>
<ul>
<li><h3>Dostępność  Usługi</h3></li>
<ul>
<li> Towynajme.pl  gwarantuje  dostępność Usługi  w  trakcie  trwania okresu Abonamentowego  na poziomie określonym w Regulaminie. </li>
<li> Towynajme.pl zastrzega sobie prawo do wykonania aktualizacji Panelu Admnistracyjnego Klienta w okresach najmniejszego obciążenia systemu o których Klient zostanie poinformowany.</li>
<li> Towynajme.pl w związku z tym, że korzysta z usług hostingowych informuje swoich Klientów o możliwości wystąpienia przerw technicznych wynikających z prac konserwacyjnych leżacych po stronie firmy hostingowej udostępniającej towynajme.pl miejsce na serwerze. </li>
<li> W przypadku, gdy czas dostępności serwisu towynajme.pl będzie niższy niż 99,9% w skali zawartej umowy serwis towynajme.pl zobowiązuje się przedłuzyć umowę o kolejne 3 dni za kążde rozpoczęte 24h łącznego czasu trwania przerwy.</li>
</ul>
</ul>

<ul>
	<li><h3>Przedłużanie Okresu Abonamentowego</h3></li>
		<ul>
			<li>Przed  końcem  bieżącego  Okresu  Abonamentowego  towynajme.pl  poinformuje  Klienta  za  pomocą  poczty elektronicznej  o upływie  Okresu  Abonamentowego  oraz  o wysokości opłat za przedłużenie okresu świadczenia usługi na kolejny Okres Abonamentowy przesyłając jednocześnie proformę tytułem przedłużenia.</li>
			<li>Klient  dokonuje  przedłużenia  Okresu  Abonamentowego  poprzez  dokonanie  wpłaty  na  rachunek bankowy wskazany  przez  towynajme.pl,  na  podstawie  przesłanej  proformy,  tytułem  świadczenia usługi,  na kolejny  Okres Abonamentowy. </li>
			<li>Klient zobowiązany jest do dokonania wpłaty tytułem utrzymania Usługi na kolejny Okres Abonamentowy przed upływem terminu wskazanego w proformie a w przypadku jego braku nie później niż 7 dni przed upływem Okresu Abonamentowego.</li> 
			<li>Klient  dokonując  wpłaty  tytułem  utrzymania  Usługi  na  kolejny  Okres  Abonamentowy,  zaś  w  przypadku dokonania  wpłaty  przez  osobę  trzecią,  przystępując  do  korzystania  z Usługi,  oświadcza,  że  zapoznał  się  i akceptuje warunki aktualnego Regulaminu świadczenia tej usługi, Cennika oraz jeżeli są przewidziane dla danej usługi dodatkowe specyfikacje, o których mowa w Regulaminie i dołączonych dokumentach będących załącznikami do umowy - tym samym przedłużana jest umowa o świadczenie usługi w kolejnym Okresie Abonamentowym.</li>
			<li>Po odnotowaniu wpłaty na rachunku bankowym towynajme.pl, tytułem świadczenia Usługi w kolejnym Okresie Abonamentowym, okres świadczenia usługi zostanie przedłużony o kolejny Okres Abonamentowy liczony od daty zakończenia poprzedniego Okresu Abonamentowego.</li>
			<li>Brak  wpłaty  na  rachunku  bankowym  towynajme.pl  tytułem  świadczenia  Usługi  w  kolejnym  Okresie Abonamentowym do ostatniego dnia bieżącego Okresu Abonamentowego Usługi oznaczać będzie zablokowanie dostępu do usługi (Zawieszenie usług) począwszy od następnego dnia po zakończeniu bieżącego Okresu Abonamentowego.  Klient wyraża  zgodę  na  przechowanie  danych  zgromadzonych  w  ramach  usługi  i usług  dodatkowych  przez  okres kolejnych 30 dni.</li>
			<li>Jeżeli  w terminie 30  dni od  daty  zakończenia  poprzedniego  Okresu  Abonamentowego  towynajme.pl  odnotuje wpłatę na rachunku bankowym tytułem świadczenia Usługi  w kolejnym Okresie Abonamentowym, dostęp do usługi zostanie odblokowany, a czas utrzymania Usługi przedłużony o kolejny Okres Abonamentowy liczony  od daty zakończenia poprzedniego Okresu Abonamentowego.</li>
		</ul>
</ul>
<ul>
	<li><h3>Płatności</h3></li>
		<ul>
			<li>Opłata  tytułem  świadczenia  Usługi  ustalana  jest  zgodnie  z Cennikiem  znajdującym  się  na  stronie internetowej  towynajme.pl,  obowiązującym  w  chwili  zamówienia usługi. Wnoszona opłata  jest  niepodzielna  i  rozliczana    w  Okresie  Abonamentowym  chyba,  że co  innego  wynika  z  oferty świadczenia danej usługi.</li>
			<li>Towynajme.pl  zastrzega sobie  prawo do zmiany cen usług, przy czym taka zmiana nie ma wpływu na ceny usług zamówionych przed zmianą.</li>
			<li>Klient zobowiązany jest do dokonania wpłaty tytułem opłacenia Usługi na wskazany przez towynajme.pl rachunek bankowy.  W  przypadku  dokonywania  wpłaty  przez osoby  trzecie,  na  wskazany  przez  towynajme.pl rachunek bankowy, opłata zostanie zaliczona na poczet usługi pod warunkiem wskazania jednoznacznego  identyfikatora usługi lub numeru opłacanej proformy. W takim przypadku Klient potwierdza wolę zawarcia umowy, wyrażoną za pośrednictwem osoby trzeciej, która dokonała wpłaty.</li>
			<li>Faktura  tytułem  świadczenia  Usługi  wystawiana  jest  na  dane  Klienta  podane  w  Panelu  Klienta.  Faktura wystawiana  jest  w terminie  do  7  dni  od daty odnotowania wpłaty na  koncie towynajme.pl.</li>
			<li>W przypadku dokonywania płatności za Usługi w towynajme.pl koszty bankowe transakcji pokrywa Klient. </li>
			<li>Zwroty wpłat będą przekazywane do nadpłat w Panelu Klienta. </li>
			<li>Datą zapłaty jest datą zaksięgowania wpłaty na rachunku bankowym towynajme.pl.</li>
		</ul>
</ul>
<ul>
	<li><h3>Okres obowiązywania umowy i jej rozwiązanie </h3></li>
		<ul>
			<li>Umowa  o  świadczenie  usługi  zawierana  jest  na  czas  określony  równy  Okresowi Abonamentowemu.  Umowa  o  świadczenie  usługi ulega  rozwiązaniu  na  skutek  nieprzedłużenia  Okresu Abonamentowego zgodnie z postanowieniami Regulaminu.</li>
			<li>Towynajme.pl  uprawnione  będzie  do  rozwiązania  Umowy  o  świadczenie  usługi  w  przypadku  gdy  Klient naruszy postanowienia Regulaminu.</li>
			<li>Towynajme.pl ma ponadto prawo niezwłocznie zaprzestać świadczenia usługi danemu Klientowi i rozwiązać umowę, jeżeli:
				<ul>
				<li>Klient będzie korzystał z usługi niezgodnie z parametrami lub przeznaczeniem określonym w Regulaminie</li>
				<li>Klient będzie działał na szkodę towynajme.pl, innych klientów towynajme.pl lub użytkowników sieci Internet.</li></ul>
			<li>Przed zaprzestaniem świadczenia usług, towynajme.pl wezwie Klienta za pomocą poczty elektronicznej do zaprzestania naruszeń wyznaczając odpowiedni termin, nie krótszy niż 24 godziny. </li>
			<li>Rozwiązanie  umowy  wymaga  zachowania  formy  pisemnej  pod  rygorem nieważności. </li>
		</ul>
</ul>
<ul>
	<li><h3>Reklamacje </h3></li>
		<ul>
			<li>Reklamacja  Klienta  w  związku  z niewykonaniem  lub  nienależytym  wykonaniem  usług  powinna  zostać  przesłana do towynajme.pl w formie pisemnej. Należy określić:
			<ul>
			<li>Dane  Klienta  umożliwiające  nawiązanie  z  nim  kontaktu,  w  tym  dane  umożliwiające  identyfikację osoby składającej reklamację jako Klienta;
			<li>Usługę, której reklamacja dotyczy</li>
			<li>Zarzuty Klienta co do wskazanej usługi</li>
			<li>Okoliczności uzasadniające reklamację</li>
			<li>Ewentualne żądanie Klienta związane ze złożoną reklamacją</li>
			<li>Reklamacja powinna zostać podpisana przez Klienta lub osobę należycie umocowaną do reprezentowania Klienta. Do reklamacji należy dołączyć dokument z którego wynika umocowanie. </li>
			</ul>
			<li>Towynajme.pl  obowiązane  jest  udzielić  pisemnej  odpowiedzi  na  reklamację,  w terminie  14  dni  od  daty  jej otrzymania, wskazując, czy uznaje reklamację oraz w jaki sposób zamierza ją rozpatrzyć lub informując o braku podstaw   do   uznania   reklamacji   wraz   z uzasadnieniem   swojego   stanowiska.  W   przypadku konieczności wyjaśnienia dodatkowych  okoliczności  związanych  z  usługami świadczonymi  na  rzecz  towynajme.pl  przez  osoby trzecie, towynajme.pl przesyła w terminie 7 dni informację o potrzebie wyjaśnienia tych okoliczności.</li>
		</ul>
</ul>
<ul>
	<li><h3>Postanowienia końcowe</h3></li>
		<ul>
			<li>Towynajme.pl zastrzega  sobie prawo  zmiany  Rgulaminu  z  ważnych  przyczyn, w szczególności takich jak zmiana przepisów prawa, zmiana warunków technicznych świadczenia Usługi, zmiany warunków świadczonych przez osoby trzecie usług na rzecz towynajme.pl niezbędnych do świadczenia usług, zmiany w  zakresie  oferty  świadczonych  usług,  zmian  organizacyjnych  lub przekształceń  prawnych.   O zmianach   towynajme.pl  poinformuje  Klienta  drogą 
				elektroniczną  na  kontaktowy  adres  poczty elektronicznej. Termin ten dla Klienta wynosi 7 dni. </li>
			<li>Klient  wyraża  zgodę  na  umieszczenie  na  stronie internetowej usługi  oznaczenia  „Copyright  © [bieżący  rok] towynajme.pl”  lub innego oznaczenia  wskazującego  na usługodawcę,  jego  ofertę lub usługę. </li>
			<li>Regulamin z dnia 01.06.2018 wersja 1.</li>
		</ul>
</ul>
