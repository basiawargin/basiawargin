<ul class="nav" id="side-menu">
  <li>
    <a href="/index.php/strony/regulamin/specyfikacja">Specyfikacja usługi</a></li>
	<li>
</ul>
<p>1.<b> Administrator danych</b><br>Administratorami danych jest Barbara Wargin, ul.Mikołajska 2/16 76-200 Słupsk.  Ochrona danych odbywa się zgodnie z wymogami powszechnie obowiązujących przepisów prawa, a ich przechowywanie ma miejsce na zabezpieczonych serwerach należących do HBB SA mającej siedzibę przy ulicy Franklina Roosevelta 22 w Poznaniu.
Serwis towynajme.pl realizuje postanowienia Rozporządzenia Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016 r. ustanawiającym przepisy o ochronie osób fizycznych w związku z przetwarzaniem danych osobowych oraz przepisy o swobodnym przepływie takich danych osobowych. Rozporządzenie chroni podstawowe prawa i wolnośći osób fizycznych w szczególności ich prawo do ochrony danych osobowych.
Każdy kto korzysta z usług firmy towynajme.pl otrzymuje dane takie jak hasło i login, dzięki którym logują się do Panelu Admninistracyjnego Klienta. Dane te są dostępne dla użytkownikom po uprzednim jednoznacznym potwierdzeniu swojej tożsamości.
</p>

<p>2. <b>Pliki COOKIE i zastosowanie</b><br>
Ciasteczka (ang. cookies) to niewielkie pliki, zapisywane i przechowywane na twoim komputerze, tablecie lub smartphonie podczas gdy odwiedzasz różne strony w internecie. Ciasteczko zazwyczaj zawiera nazwę strony internetowej, z której pochodzi, „długość życia” ciasteczka (to znaczy czas jego istnienia), oraz przypadkowo wygenerowany unikalny numer służący do identyfikacji przeglądarki, z jakiej następuje połączenie ze stroną internetową.
<br />
<br />Pilki Cookies są wykorzystywane celem:
<ul>
<li>a. dostosowania zawartości stron serwisu internetowego do preferencji użytkownika oraz optymalizacji korzystania ze stron internetowych; w szczególności pliki te pozwalają rozpoznać urządzenie użytkownika serwisu internetowego i odpowiednio wyświetlić stronę internetową, dostosowaną do jego indywidualnych potrzeb,</li>
<li>b. tworzenia statystyk, które pomagają zrozumieć, w jaki sposób użytkownicy serwisu korzystają ze stron internetowych, co umożliwia ulepszanie ich struktury i zawartości,</li>
<li>c. utrzymania sesji użytkownika serwisu internetowego (po zalogowaniu), dzięki której użytkownik nie musi na każdej podstronie serwisu ponownie wpisywać loginu i hasła,</li>
<li>d.dostarczania użytkownikom treści reklamowych bardziej dostosowanych do ich zainteresowań.</li>
</ul>
</p>
<p>3. <b>Zastosowanie plików cookie w witrynie towynajme.pl</b><br>
Cookies własne
<ul>
<li>a. „niezbędne” pliki cookies, umożliwiające korzystanie z usług dostępnych w ramach serwisu internetowego, np. uwierzytelniające pliki cookies wykorzystywane do usług wymagających uwierzytelniania w ramach serwisu,</li>
<li>b. pliki cookies służące do zapewnienia bezpieczeństwa, np. wykorzystywane do wykrywania nadużyć w zakresie uwierzytelniania w ramach serwisu,</li>
</li>
<li>c. pliki cookies, umożliwiające zbieranie informacji o sposobie korzystania ze stron internetowych serwisu,</li>
<li>d. „funkcjonalne” pliki cookies, umożliwiające „zapamiętanie” wybranych przez użytkownika ustawień i personalizację interfejsu użytkownika, np. w zakresie regionu, z którego pochodzi użytkownik, rozmiaru czcionki, wyglądu strony internetowej itp.,</li>
</ul>
<span class="text-center">Cookies zewnętrzne</span>
<ul>
	<li> a) zbierania ogólnych i anonimowych danych statycznych za pośrednictwem narzędzi analitycznych Google Analytics (administrator cookies zewnętrznego: Google Inc z siedzibą w USA); </li>
	<li> b) popularyzacji serwisu za pomocą serwisu społecznościowego facebook.com (administrator cookies zewnętrznego: Facebook Inc z siedzibą w USA lub Facebook Ireland z siedzibą w Irlandii).</li>
	<li> c) popularyzacji Serwisu za pomocą serwisu społecznościowego plus.google.com (administrator cookies zewnętrznego: Google Inc z siedzibą w USA) </li>
	<li> d) prezentowania treści multimedialnych na stronach internetowych Serwisu, które są pobierane z zewnętrznego serwisu internetowego www.youtube.com (administrator cookies zewnętrznego: Google Inc z siedzibą w USA)</li>
	<li> e) ułatwienia komunikacji za pośrednictwem Strony Internetowej Serwisu za pośrednictwem chatu (administrator cookies zewnętrznego: LiveChat Inc. z siedzibą w USA).</li>
</ul>

</p>

<p>4. <b>Zarządzanie plikami cookies</b><br>
Wyłączenie stosowania cookies może spowodować utrudnienia z korzystanie niektórych usług w ramach naszego serwisu, w szczególności wymagających logowania.
Wyłączenie opcji przyjmowania cookies nie powoduje natomiast braku możliwości czytania lub oglądania treści zamieszczanych w serwisie internetowym z zastrzeżeniem tych, do których dostęp wymaga logowania.
Użytkownik w  każdej chwili ma możliwość wyłączenia lub przywrócenia opcji gromadzenia cookies poprzez zmianę ustawień w przeglądarce internetowej.
Instrukcja zarządzania plikami cookies jest dostępna na stronie http://www.allaboutcookies.org/manage-cookies/ . 
Dane osobowe, jak adres e-mail, telefony, dane ofert zbierane są jedynie w miejscach, w których Użytkownik wypełniając formularz wyraźnie wyraził na to zgodę. Powyższe dane zachowujemy i wykorzystujemy tylko  do potrzeb niezbędnych do wykonania danej funkcji.</p>

<p>5. <b>Postanowienia końcowe</b><br>
Powyższy dokument obowiązuje jedynie na witrynie www.towynajme.pl. Nie ponosimy odpowiedzialności za zasady zachowania prywatności na innych stronach, łącznie z witrynami, do których kierujących odnośniki zawarte na stronie www.towynajme.pl. W przypadku korzystania z innych witryn prosimy o zapoznanie się z Polityką prywatności i polityką plików cookies,  ustaloną przez przeglądaną witrynę. Zastrzegamy sobie prawo do wprowadzania zmian w Polityce Prywatności przez odpowiednią modyfikację do powyższego zapisu. Wszelkie zmiany nie będą jednak naruszały zasady bezpieczeństwa i ochrony danych Użytkowników.</p>

</div></div></div>
