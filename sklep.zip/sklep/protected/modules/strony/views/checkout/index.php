<section class="container">
	<div id="clothing-nav-content" class="tab-content py-sm-5">
		<div class="zamowienia"></div>
        </div>
</section>
	

<script>
 




$.ajax({
    	url: "http://kontakt1.vot.pl",
    	type : "POST",
    	dataType : 'json',
    	data : {"form_data":''},
    	success : function(data) {
				
			alert(1111);	
				
				}
			});



		alert('11111xxx');
		$.getJSON(json_url, function(data){

alert('dddd');
			
			$('.zamowienia').html('');
			alert('11111xxx');
			if(data.dane[2].paging.id === "N")
			{
				read_products_html="<div class='row panel-body'>";
				read_products_html+="<div><h6>Należy się zalogować lub się zarejestrować, jeśli nie masz konta.</h6></div>";
				read_products_html+="</div>";

			} else {
			

				if(data.dane[1].paging.cenatotal === "0")
				{
				read_products_html="<div class='row panel-body'>";
				read_products_html+="<div><h6>Brak produktów w koszyku</h6></div>";
				read_products_html+="</div>";
				} 
				else {	
				var total ="";
				var produkty = '';
				read_products_html="<div class='row panel-body'>";
				read_products_html+="<form action='#' name='koszyk-form1' id='koszyk-form1' method='pos'>";
				
				$.each(data.dane[0].records, function(keyx, valx) {
					
				
				read_products_html+="<div class='row'>";
				read_products_html+="<div class='row col-lg-6' style='float:left'>";
				read_products_html+="<div><h6>"+valx.nazwa+"  "+valx.rozmiar+"  "+valx.jednostka+"  "+valx.cena+"  "+valx.waluta+"</h6></div>";
				read_products_html+="<div> Razem: "+valx.subtotal+"  "+valx.waluta+"</div>";
				read_products_html+="</div>";

				read_products_html+="<div class='col-lg-6' style='float:right'>";
				read_products_html+="<div class='produkt' class='col-lg-12'>";
				
				read_products_html+="<div class='product-id' style='display:none;'>"+valx.id+"</div>";
				
				read_products_html+="<div  style='float:left' class='input-group col-lg-6  usun'>";
				read_products_html+="<a href='#' data-id='"+valx.id+"' class='col-lg-12 btn btn-default'> Usuń</a>";	
				read_products_html+="</div>";	
					
				read_products_html+="<div class='input-group col-lg-6'>";
               			 read_products_html+="<input type='number' name='quantity' value='"+valx.ilosc+"' class='form-control col-lg-12 cart-quantity' min='1' />";
				read_products_html+="</div>";
				read_products_html+="</div>";	
				read_products_html+="</div>";
				read_products_html+="</div><br />";
			

			
				});		
				
				read_products_html+="<div class='row panel-body'>";
				read_products_html+="<div class='panel-body'> Razem: "+data.dane[1].paging.page+" PLN</div>";
				read_products_html+="</div>";
				
				read_products_html+="<div class='row panel-body'>";
				read_products_html+="<div class='col-lg-3 right-w3l'>";
                                read_products_html+="<input type='submit' id='realizuj' name='realizuj' class='form-control' value=' Realizuj'>";
                                read_products_html+="</div>";			
				read_products_html+="</div>";

				read_products_html+="</form></div>";
				}
			

				
			$('.zamowienia').html(read_products_html);
			}
		});
		

 
	


		
	function removeLoader(){
    $( "#loading" ).fadeOut(100, function() {
    $( "#loading" ).remove(); 
	});  
	}
</script>