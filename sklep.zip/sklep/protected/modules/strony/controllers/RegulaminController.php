<?php

class RegulaminController extends Controller
{
	public function accessRules() {
		return array (
				array (
						'allow', // allow all users to perform 'index' and 'view' actions
						'actions' => array (
								'index','specyfikacja'
						),
						'users' => array (
								'@' 
						) 
				) 
		);
	}

	public function actionIndex()
	{
		$this->layout = 'user.views.layout.mainadmin'; 
		
		$this->render('index');
	}
	
	public function actionSpecyfikacja()
	{
		$this->layout = 'user.views.layout.mainadmin'; 
		
		$this->render('specyfikacja');
	}
	
	
	
}